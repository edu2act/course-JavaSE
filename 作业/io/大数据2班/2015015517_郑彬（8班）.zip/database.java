import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

class fail{
	public void out(String st) throws Exception{
		BufferedReader br = new BufferedReader(new FileReader(st));
		String line = null;
		String s[] = new String[5];
		System.out.println("����������У�");
		while((line=br.readLine())!=null){
			s = line.split(",");
			if(Integer.parseInt(s[2])<60|Integer.parseInt(s[3])<60|Integer.parseInt(s[4])<60){
				System.out.print(s[1]+" ");
			}
		}
		System.out.println("\n");
	}
	public void out2(String st)throws Exception{
		BufferedReader br = new BufferedReader(new FileReader(st));
		String line = null;
		String s[] = new String[5];
		System.out.println("���п�Ŀ90�����ϵ����У�");
		while((line=br.readLine())!=null){
			s = line.split(",");
			if(Integer.parseInt(s[2])>=90&Integer.parseInt(s[3])>=90&Integer.parseInt(s[4])>=90){
				System.out.print(s[1]+" ");
			}
		}
		System.out.println("\n");
	}
	public void out3(String st)throws Exception{
		BufferedReader br = new BufferedReader(new FileReader(st));
		String line = null;
		String s[] = new String[5];
		int score = 0;
		int num = 0;
		System.out.println("��ѧƽ���֣�");
		while((line=br.readLine())!=null){
			s = line.split(",");
			score+=Integer.parseInt(s[2]);
			num++;
		}
		System.out.println(score/num+"��");
	}
}

public class database {
	public static void main(String[] args) throws Exception {
		String st = "D:\\a.txt";
		new fail().out(st); //���������
		new fail().out2(st); //���п�Ŀ90�����ϵ���
		new fail().out3(st); //��ѧƽ����
	}
}
