package score;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class Scores{

	public static HashMap<Integer, Integer> avgClassMathScore() {
		BufferedReader br = null;
		HashMap<Integer, Integer> hm = new HashMap<Integer, Integer>();
		try {
			br = new BufferedReader(new FileReader("student.txt"));
			String line = br.readLine();
			int count1 = 0;
			int sum1 = 0;
			int count2 = 0;
			int sum2 = 0;
			int count3 = 0;
			int sum3 = 0;
			int count4 = 0;
			int sum4 = 0;
			while (line != null) {
				String[] s = line.split(",");
				if (Integer.parseInt(s[1]) == 1) {
					count1++;
					sum1 += Integer.parseInt(s[3]);
					hm.put(1, sum1 / count1);
				} else if (Integer.parseInt(s[1]) == 2) {
					count2++;
					sum2 += Integer.parseInt(s[3]);
					hm.put(2, sum2 / count2);
				} else if (Integer.parseInt(s[1]) == 3) {
					count3++;
					sum3 += Integer.parseInt(s[3]);
					hm.put(3, sum3 / count3);
				} else if (Integer.parseInt(s[1]) == 4) {
					count4++;
					sum4 += Integer.parseInt(s[3]);
					hm.put(4, sum4 / count4);
				}
				line = br.readLine();
			}
			return hm;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			if (br != null)
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}

}
