package sumwenjianjiadeshuzihe;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class Find {
	// ���ļ�
	// ��ÿһ��
	// ��Ŀ¼
	// ���ļ�
	// ��ÿһ��
/*
 * �ַ����ıȽ� ��equals ���ҿ�ֵ��""
 */
	public static void main(String[] args) {
		File file = null;
		file = new File("E:\\eclipse-installer\\yanpu\\workspace\\text_1");
		// workspace�µ�Ŀ¼��
		File[] ml = file.listFiles();
		HashMap map = new HashMap();
		for(int i=0;i<ml.length;i++){
			map.put(ml[i], Find.countProtectNum(ml[i]));
		}
		System.out.println(map);
		
//		Set key=map.keySet();
//		Iterator i=key.iterator();
//		
//		while(i.hasNext()){
//			Object k=i.next();
//			System.out.println(k+":"+map.get(k));
//		}
	}

	private static long countProtectNum(File ml) {
		long sum=0;
		// TODO Auto-generated method stub
			if(ml.isDirectory()){
				sum+=countDirNum(ml.listFiles());
			}else if(ml.isFile()){
				if(ml.getName().endsWith(".java")){
				 sum+=countFileNum(ml);
				}
			}
		return sum;
	}


	private static long countDirNum(File[] listFiles) {
		// TODO Auto-generated method stub
		long sum=0;
		for(int i=0;i<listFiles.length;i++){
			if(listFiles[i].isDirectory()){
				sum+=countProtectNum(listFiles[i]);
			}else if(listFiles[i].isFile()){
				if(listFiles[i].getName().endsWith(".java")){
				sum+=countFileNum(listFiles[i]);}
			}
		}
		return sum;
	}

	private static long countFileNum(File file) {
		// TODO Auto-generated method stub
		FileReader lfile=null;
		long sum=0;
		try {
			lfile=new FileReader(file);
			BufferedReader bfile=new BufferedReader(lfile);
			try {
				String line=bfile.readLine();
				String []s=null;
				while(line!=null){
					s=line.replaceAll("[^0-9]", ",").split(",");
					for(int i=0;i<s.length;i++){
						if(!s[i].equals("")){
							sum+=Integer.parseInt(s[i]);
						}
					}
					
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				try {
					bfile.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				lfile.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return sum;
	}

}
