package Score;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;


public class ScoreUtil {
	//���ݵ��������޸�ɾ��
	public static void addNew(String a) {
		FileWriter f = null;
		try {
			f = new FileWriter("c:/����/a.txt", true);
			f.write("\r\n");
			f.write(a);
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			if (f != null) {
				try {
					f.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	//��ѯ�����в������Ŀ��ѧ������
	public static ArrayList<String> failStu() {
		BufferedReader r=null;
		try {
			r = new BufferedReader(new FileReader("c:/����/name.txt"));
			String line = r.readLine();
			ArrayList<String> list = new ArrayList<String>();
			while(line != null) {
				String[] s = line.split(",");
				if(Integer.parseInt(s[3])<60 || Integer.parseInt(s[4])<60 || Integer.parseInt(s[5])<60) {
					list.add(s[2]);
				}
				line=r.readLine();
			}
			return list;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			if(r!=null)
				try {
					r.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
	
	//��ѯ����90������ѧ������
	public static ArrayList<String> excellentStu() {
		BufferedReader r=null;
		try {
			r = new BufferedReader(new FileReader("c:/����/name.txt"));
			String line = r.readLine();
			ArrayList<String> list = new ArrayList<String>();
			while(line != null) {
				String[] s = line.split(",");
				if(Integer.parseInt(s[3])>=90 || Integer.parseInt(s[4])>=90 || Integer.parseInt(s[5])>=90) {
					list.add(s[2]);
				}
				line=r.readLine();
			}
			return list;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			if(r!=null)
				try {
					r.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
	
	//��ѯ������ѧƽ����
	public static HashMap<Integer,Integer> avgClassMathScore() {
		BufferedReader r=null;
		HashMap<Integer,Integer> hm=new HashMap<Integer,Integer>();
		try {
			r = new BufferedReader(new FileReader("c:/����/name.txt"));
			String line=r.readLine();
			int count1 = 0;
			int sum1 = 0;
			int count2 = 0;
			int sum2 = 0;
			int count3 = 0;
			int sum3 = 0;
			int count4 = 0;
			int sum4 = 0;
			while(line != null) {
				String[] s=line.split(",");
				if(Integer.parseInt(s[1]) == 1) {
					count1++;
					sum1 += Integer.parseInt(s[3]);
					hm.put(1, sum1/count1);
				}else if(Integer.parseInt(s[1]) == 2) {
					count2++;
					sum2 += Integer.parseInt(s[3]);
					hm.put(2, sum2/count2);
				}else if(Integer.parseInt(s[1]) == 3) {
					count3++;
					sum3 += Integer.parseInt(s[3]);
					hm.put(3, sum3/count3);
				}else if(Integer.parseInt(s[1]) == 4) {
					count4++;
					sum4 += Integer.parseInt(s[3]);
					hm.put(4, sum4/count4);
				}
				line = r.readLine();
			}
			return hm;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}finally{
			if(r!=null)
				try {
					r.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
	
	//��������ѧ����ƽ���ɼ�
	public static HashMap<Integer,Integer> avgStudentsScore(){
		BufferedReader r=null;
		HashMap<Integer,Integer> hm=new HashMap<Integer,Integer>();
		int avg=-1;
		try{
			r = new BufferedReader(new FileReader("c:/����/name.txt"));
			String line=r.readLine();
			while(line != null) {
				String[] s=line.split(",");
				avg=(Integer.parseInt(s[3])+Integer.parseInt(s[4])+Integer.parseInt(s[5]))/3;
				hm.put(Integer.parseInt(s[0]), avg);
				line=r.readLine();
			}
			return hm;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			if(r!=null)
				try {
					r.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
	
	//����ĳͬѧ3��ƽ����
	public static int avgStudentScore(int id){
		BufferedReader r=null;
		int avg=-1;
		try{
			r=new BufferedReader(new FileReader("c:/����/name.txt"));
			String line=r.readLine();
			while(line!=null){
				String[] s=line.split(",");
				if(id==Integer.parseInt(s[0])){
					avg=(Integer.parseInt(s[3])+Integer.parseInt(s[4])+Integer.parseInt(s[5]))/3;
					break;
				}
				line=r.readLine();
			}
			return avg;
		}catch(Exception e){
			e.printStackTrace();
			return -1;
		}finally{
			if(r!=null)
				try {
					r.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
	
	//��������ѧ������ѧƽ����
	public static int avgMathScore(){
		BufferedReader r=null;
		int sum=0;
		int count=0;
		try{
			r=new BufferedReader(new FileReader("c:/����/name.txt"));
			String line=r.readLine();
			while(line!=null){
				String[] s=line.split(",");
				sum+=Integer.parseInt(s[3]);
				count++;
				line=r.readLine();
			}
			return sum/count;
		}catch(Exception e){
			e.printStackTrace();
			return -1;
		}finally{
			if(r!=null)
				try {
					r.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
	
	public static void readFile(){
		try{
			FileReader fr=new FileReader("c:/����/name.txt");
			BufferedReader r=new BufferedReader(fr);
			String line=r.readLine();
			while(line != null){
				System.out.println(line);
				line=r.readLine();
			}
			r.close();
			fr.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void writeFile(){
		try{
			BufferedWriter bw=new BufferedWriter(new FileWriter("c:/����/name.txt"));
			bw.write("helloworld");
			bw.newLine();
			bw.write("hi");
			bw.write("sayhi");
			bw.flush();
			bw.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
}
