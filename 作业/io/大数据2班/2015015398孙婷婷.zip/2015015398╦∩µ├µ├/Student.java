/**
 * @data 2017年4月25日
 * @author
 * 
 */
package demo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

public class Student {

	/**
	 * 查询所有有不及格科目的学生姓名 用LinkedList记录学生姓名
	 * 
	 * @return LinedList<String> 姓名集合
	 */
	public static LinkedList<String> searchFailStudent() {
		LinkedList list = new LinkedList();
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader("d:/Student.txt"));
			String line = br.readLine();
			while (line != null) {
				String[] s = line.split(",");
				for (int i = 2; i < 5; i++) {
					if (Integer.parseInt(s[i]) < 60) {
						list.add(s[1]);
						break;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return list;
	}

	/**
	 * 查询所有90分以上的学生姓名 用String数组存学生姓名
	 * @return String数组
	 */
	public static String[] searchAllNintyStudent() {
		String[] str = new String[10];
		int i = 0;
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader("d:/Student.txt"));
			String line = br.readLine();
			while (line != null) {
				String[] s = line.split(",");
				for (int m = 2; m < 5; m++) {
					if (Integer.parseInt(s[i]) > 90) {
						str[i] = s[1];
						break;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return str;
	}
	/**
	 * 查询各班数学平均分
	 * @return  
	 */
	public static HashMap<Integer,Integer> searchMathAvgScore(){
		BufferedReader br = null;
		HashMap<Integer,Integer> hm = new HashMap<Integer,Integer>();
		try {
			br = new BufferedReader(new FileReader("d:/Student.txt"));
			String line = br.readLine();
			while(line != null){
				String[] s = line.split(",");
				
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}   
		return null;
	}       
	        
	public static void main(String[] args) {
		LinkedList<String> list = new  LinkedList<String>();
		list = searchFailStudent();
		int size = list.size();  
		for (int i=0; i<size; i++) {  
		    list.get(i);          
		} 
	}

}
