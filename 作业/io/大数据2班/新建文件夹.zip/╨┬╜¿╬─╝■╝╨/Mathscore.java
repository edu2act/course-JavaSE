package sorce;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Scanner;

public class Mathscore {
	@SuppressWarnings("resource")
	public static int avgMathScore(int n){
		BufferedReader br =null;
		int sum =0;
		int count =0;
		try{
			br=new BufferedReader(new FileReader("E:/a.txt"));
			String line=br.readLine();
			while(line!=null){
				String[] s=line.split("��");
				if(n==Integer.parseInt(s[5])){
					 sum+=Integer.parseInt(s[2]);
					 count ++;
				}
			    line=br.readLine();
			    }
			return sum/count;
		}catch(Exception e){
			e.printStackTrace();
			return -1;
		}
		
	}
	
	public static void main(String[] args) {
		System.out.println("����༶��");
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		int i = scan.nextInt();
		int avg=Mathscore.avgMathScore(i);
		System.out.println(avg);

	}

}
