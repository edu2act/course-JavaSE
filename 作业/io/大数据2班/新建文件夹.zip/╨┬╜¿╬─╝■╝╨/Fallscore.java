package sorce;

import java.io.BufferedReader;
import java.io.FileReader;

public class Fallscore {

	public static void Fall(){
		int count =0;
		BufferedReader br =null;
		
		try{
			br=new BufferedReader(new FileReader("E:/a.txt"));
			String line=br.readLine();
			System.out.println("���Ĳ�������У�");
			while(line!=null){
				String[] s=line.split("��");
				if(Integer.parseInt(s[2])<60){
					System.out.println(s[1]);
					count++;
				}
			    line=br.readLine();
			    }
			if(count==0){
				System.out.println("û�в�������ˡ�");
			}
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("�˴����쳣��");
		}
		
		try{
			br=new BufferedReader(new FileReader("E:/a.txt"));
			String line=br.readLine();
			System.out.println("��ѧ��������У�");
			while(line!=null){
				String[] s=line.split("��");
				if(Integer.parseInt(s[3])<60){
					System.out.println(s[1]);
					count++;
				}
			    line=br.readLine();
			    }
			if(count==0){
				System.out.println("û�в�������ˡ�");
			}
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("�˴����쳣��");
		}
		
		try{
			br=new BufferedReader(new FileReader("E:/a.txt"));
			String line=br.readLine();
			System.out.println("Ӣ�ﲻ������У�");
			while(line!=null){
				String[] s=line.split("��");
				if(Integer.parseInt(s[4])<60){
					System.out.println(s[1]);
					count++;
				}
			    line=br.readLine();
			    }
			if(count==0){
				System.out.println("û�в�������ˡ�");
			}
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("�˴����쳣��");
		}
		
	}
	
	public static void main(String[] args) {
		
		Fallscore.Fall();
		

	}

}
