﻿package demo;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import week1.Work5.Student;


public class Demo1 {
	public static int avgMathScore(){
		BufferedReader br=null;
		int sum=0;
		int count=0;
		try{
			br=new BufferedReader(new FileReader("d:/Java/student.txt"));
			String line=br.readLine();
			while(line!=null){
				String[] s=line.split(",");
				sum+=Integer.parseInt(s[3]);
				count++;
				line=br.readLine();
			}
			return sum/count;
		}catch(Exception e){
			e.printStackTrace();
			return -1;
		}finally{
			if(br!=null)
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
	public static void readFile(){
		try{
			FileReader fr=new FileReader("d:/Java/student.txt");
			BufferedReader br=new BufferedReader(fr);
			String line=br.readLine();
			while(line!=null){
				System.out.println(line);
				line=br.readLine();
			}
			br.close();
			fr.close();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			
		}
	}
	public static void writeFile(){
		try{
			BufferedWriter bw=new BufferedWriter(new FileWriter("d:/Java/student.txt"));
			bw.write("1,张三,100,90,80");
			bw.newLine();
			bw.write("2,李四,70,85,50");
			bw.newLine();
			bw.write("3,王五,80,100,60");
			bw.newLine();
			bw.write("4,李明,70,80,90");
			bw.newLine();
			bw.write("5,李大,66,58,90");
			bw.newLine();
			bw.write("6,李二,90,100,59");
			bw.newLine();
			bw.flush();
			bw.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void selectStudent(){//筛选成绩不合格的学生
		BufferedReader br=null;
		try{
			br=new BufferedReader(new FileReader("d:/Java/student.txt"));
			String line=br.readLine();
			while(line!=null){
				String[] s=line.split(",");
				for(int i=2;i<s.length;i++){
					if(Integer.parseInt(s[i])<60){
						System.out.println(s[1]);
						break;
					}
				}
				line=br.readLine();
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			if(br!=null)
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
	public static void selectStudent1(){//筛选成绩大于90的学生
		BufferedReader br=null;
		try{
			br=new BufferedReader(new FileReader("d:/Java/student.txt"));
			String line=br.readLine();
			while(line!=null){
				String[] s=line.split(",");
				for(int i=2;i<s.length;i++){
					if(Integer.parseInt(s[i])>=90){
						System.out.println(s[1]);
						break;
					}
				}
				line=br.readLine();
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			if(br!=null)
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
	public static void main(String[] args) {
		Work2.readFile();
		Work2.writeFile();
		int avg=Work2.avgMathScore();
		System.out.print("数学平均成绩：");
		System.out.println(avg);
		System.out.println("成绩不合格学生：");
		selectStudent();
		System.out.println("90分以上学生姓名");
		selectStudent1();
		}

	}
