import java.io.*;
public class test {
	public static void main(String[] args){
		File read=null;
		 read =new File("F://1.txt");
		try{
			if(read.exists()){
				BufferedReader br=new BufferedReader(new FileReader(read));
				String str=br.readLine();
				while (str!=null){
					
					String []strArray=str.split(" ");
					if(Integer.valueOf(strArray[2])<60  ||  Integer.valueOf(strArray[3])<60  ||  Integer.valueOf(strArray[4])<60){
						System.out.print("�������ѧ���ǣ�   ");
						System.out.println(strArray[1]);
						if(Integer.valueOf(strArray[2])<60){
							System.out.print("���Ĳ�����  �ɼ�Ϊ��");
							System.out.println(Integer.valueOf(strArray[2]));
						}
						if(Integer.valueOf(strArray[3])<60){
							System.out.print("��ѧ������  �ɼ�Ϊ��");
							System.out.println(Integer.valueOf(strArray[3]));
						}
						if(Integer.valueOf(strArray[4])<60){
							System.out.print("Ӣ�ﲻ����  �ɼ�Ϊ��");
							System.out.println(Integer.valueOf(strArray[4]));
						}
					}
					str=br.readLine();
					
					
					
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		finally{
			
		}
		
		
	}
}
