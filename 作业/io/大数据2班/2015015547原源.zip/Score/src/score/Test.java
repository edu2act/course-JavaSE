package score;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class Test {

	public static void main(String[] args) {
  	//	ScoreUtil.writeFile();
		
		int avg=ScoreUtil.avgMathScore();
		System.out.println(avg);
		
		System.out.println(ScoreUtil.avgStudentScore(1));
		
		HashMap<Integer,Integer> hm=ScoreUtil.avgStudentsScore();
		Set<Integer> set=hm.keySet();
		Iterator<Integer> i=set.iterator();
		while(i.hasNext()){
			Integer key=(Integer)i.next();
			Integer value=hm.get(key);
			System.out.println("ѧ��"+key+"ƽ������"+value);
		}
		
		ArrayList<String> l = ScoreUtil.failStu();
		System.out.println("�����п�Ŀ�������ͬѧΪ"+l);
		
		ArrayList<String> l1 = ScoreUtil.excellentStu();
		System.out.println("90�����ϵ�ͬѧΪ"+l1);
		
		HashMap<Integer,Integer> hm1=ScoreUtil.avgClassMathScore();
		Set<Integer> set1=hm1.keySet();
		Iterator<Integer> i1=set1.iterator();
		while(i1.hasNext()){
			Integer key1 = (Integer)i1.next();
			Integer value1 = hm1.get(key1);
			System.out.println("�༶"+key1+"����ѧƽ������"+value1);
		}
		
		ScoreUtil.addNew("9,1,saisai,43,65,78");

	}

}
