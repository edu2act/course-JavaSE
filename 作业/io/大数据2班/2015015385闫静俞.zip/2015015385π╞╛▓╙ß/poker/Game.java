package poker;

import java.util.LinkedList;
import java.util.Random;

public class Game {

	public static void main(String[] args) {
		LinkedList list = new LinkedList();
		
		Player player1 = new Player();
		Player player2 = new Player();
		Player player3 = new Player();
		//新建一副牌
		newCard(list);
		
		//显示新建的牌
		showCard(list);
		System.out.println();
		//随机洗牌
		shuffleCard(list);
		//显示洗完的牌
		showCard(list);
		System.out.println(list.size());
		System.out.println("玩家1的手牌");
		showCard(player1.dealCard(list));
		System.out.println("玩家2的手牌");
		showCard(player1.dealCard(list));
		System.out.println("玩家3的手牌");
		showCard(player1.dealCard(list));
		
	}

	public static LinkedList newCard(LinkedList list) {

		for (int i = 0; i < 52; i++) {
			Poker poker = new Poker();
			poker.setNumber(i % 13 + 1);
			switch (i % 4) {
			case 0:
				poker.setColor("spade");
				break;
			case 1:
				poker.setColor("club");
				break;
			case 2:
				poker.setColor("heart");
				break;
			case 3:
				poker.setColor("diamond");
				break;
			}
			list.add(poker);
		}
		Poker poker1 = new Poker();
		poker1.setColor("red joker");
		poker1.setNumber(14);
		list.add(poker1);
		Poker poker2 = new Poker();
		poker2.setColor("black joker");
		poker2.setNumber(14);
		list.add(poker2);
		return list;
	}

	public static LinkedList shuffleCard(LinkedList list) {
		Random r = new Random();
		for (int i = 0; i < 100; i++) {
			int n=r.nextInt(list.size());
			int m=r.nextInt(list.size());
			Poker poker1=(Poker)list.get(n);
			Poker poker2=(Poker)list.get(m);
			list.set(n, poker2);
			list.set(m, poker1);
		}

		return list;

	}

	public static void showCard(LinkedList list){
		for(int i = 0; i<list.size();i++){
			System.out.println(list.get(i));
			
		}
	}
}
