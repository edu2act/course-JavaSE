package wenjiancaozuo;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class SerivalPerson {

	public static void unSerival(){ 
		try{
			ObjectInputStream oos=new ObjectInputStream(new FileInputStream("d:/b.txt"));
			Person p=(Person)oos.readObject();
			oos.close();
			System.out.println(p.getName());
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void seriavl(){
		Person p=new Person();
		p.setId(1);
		p.setName("zhangsan");
		
		try{
			ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream("d:/b.txt"));
			oos.writeObject(p);
			oos.flush();
			oos.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
