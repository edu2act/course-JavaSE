package DS;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Scanner;

public class ScoreUtil {
	
	/**
	 * @author SZH
	 * @function ����һ��ѧ����Ϣ
	 */
	public static void addNew() {
		FileWriter fw = null;
		Scanner scan = new Scanner(System.in);
		try {
			fw = new FileWriter("E://a.txt", true);
			fw.write("\r\n");
			fw.write(scan.nextLine());
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			if (fw != null) {
				try {
					fw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	/**
	 * @author SZH
	 * @function ��ѯ����90������ѧ������
	 */
	public static String overNinety() {
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader("E://a.txt"));
			String line;
			line = br.readLine();
			while (line != null) {
				String[] s = line.split(",");
				for (int j = 2; j < 5; j++) {
					if ((Integer.parseInt(s[j]) > 90) && j < 5) {
						System.out.println(s[1]);
					}
				}
				line = br.readLine();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return null;
	}

	/**
	 * @author SZH
	 * @function ��ѯ�����в������Ŀ��ѧ������
	 */
	public static String notPass() {
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader("E://a.txt"));
			String line;
			line = br.readLine();
			while (line != null) {
				String[] s = line.split(",");
				for (int j = 2; j < 8; j++) {
					if ((Integer.parseInt(s[j]) <= 60) && j < 8) {
						System.out.println(s[1]);
					}
				}
				line = br.readLine();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return null;
	}

	/**
	 * @author SZH
	 * @function �����ѧƽ����
	 */
	public static HashMap<Integer,Integer> avgMathScore() {
		BufferedReader br=null;
		HashMap<Integer,Integer> hm=new HashMap<Integer,Integer>();
		try {
			br = new BufferedReader(new FileReader("E://a.txt"));
			String line=br.readLine();
			int count1 = 0;
			int sum1 = 0;
			int count2 = 0;
			int sum2 = 0;
			int count3 = 0;
			int sum3 = 0;
			int count4 = 0;
			int sum4 = 0;
			while(line != null) {
				String[] s=line.split(",");
				if(Integer.parseInt(s[1]) == 1) {
					count1++;
					sum1 += Integer.parseInt(s[3]);
					hm.put(1, sum1/count1);
				}else if(Integer.parseInt(s[1]) == 2) {
					count2++;
					sum2 += Integer.parseInt(s[3]);
					hm.put(2, sum2/count2);
				}else if(Integer.parseInt(s[1]) == 3) {
					count3++;
					sum3 += Integer.parseInt(s[3]);
					hm.put(3, sum3/count3);
				}else if(Integer.parseInt(s[1]) == 4) {
					count4++;
					sum4 += Integer.parseInt(s[3]);
					hm.put(4, sum4/count4);
				}
				line = br.readLine();
			}
			return hm;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}finally{
			if(br!=null)
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}

}
