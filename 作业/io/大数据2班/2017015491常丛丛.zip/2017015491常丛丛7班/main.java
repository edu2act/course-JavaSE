package job;


public class main {
	public static void main(String[] args) {
		try{		
			System.out.println("考试成绩单为：");
			find.readFile();
			System.out.println("");
			find.avgMathScore();
			System.out.println("");
			find.avgOneScore();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
