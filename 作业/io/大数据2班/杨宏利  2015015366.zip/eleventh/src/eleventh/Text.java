package eleventh;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class Text {

	public static int downScore(){
			BufferedReader br=null;
			int count=0;
			try{
				br=new BufferedReader(new FileReader("d:/a.txt"));
				String line=br.readLine();
				while(line!=null){
					String[] s=line.split(",");
					if(Integer.parseInt(s[2])<60||Integer.parseInt(s[3])<60||Integer.parseInt(s[4])<60){
						count++;
					}
					line=br.readLine();
				}
				return count;
			}catch(Exception e){
				e.printStackTrace();
				return -1;
			}finally{
				if(br!=null)
					try {
						br.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
			}
		}

	
	public static int topScore(){
		BufferedReader br=null; 
		int count=0;
		try{
			br=new BufferedReader(new FileReader("d:/a.txt"));
			String line=br.readLine();
			while(line!=null){
				String[] s=line.split(",");
				if(Integer.parseInt(s[2])>90||Integer.parseInt(s[3])>90||Integer.parseInt(s[4])>90){
					count++;
				}
				line=br.readLine();
			}
			return count;
		}catch(Exception e){
			e.printStackTrace();
			return -1;
		}finally{
			if(br!=null)
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
	

	public static int avgMathClass(int classno){
		BufferedReader br= null;
		HashMap<Integer,Integer> hm=new HashMap<Integer,Integer>();
		int avg=-1;
		int count=0;
		int sum=0;
		try{
			br=new BufferedReader(new FileReader("d:/a.txt"));
			String line=br.readLine();
			while(line!=null){
			String[] s=line.split(",");
			if(Integer.parseInt(s[5])==classno){
				sum+=Integer.parseInt(s[2]);
				count++;
				}
			line=br.readLine();
			}
			return sum/count;
		}catch(Exception e){
			e.printStackTrace();
			return -1;
		}finally{
			if(br!=null)
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
	

	public static HashMap<Integer,Integer> avgStudentsScore(){
		BufferedReader br=null;
		HashMap<Integer,Integer> hm=new HashMap<Integer,Integer>();
		int avg=-1;
		try{
			br=new BufferedReader(new FileReader("d:/a.txt"));
			String line=br.readLine();
			while(line!=null){
				String[] s=line.split(",");
				avg=(Integer.parseInt(s[2])+Integer.parseInt(s[3])+Integer.parseInt(s[4]))/3;
				hm.put(Integer.parseInt(s[0]), avg);
				line=br.readLine();
			}
			return hm;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			if(br!=null)
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
	

	public static int avgStudentScore(int id){
		BufferedReader br=null;
		int avg=-1;
		try{
			br=new BufferedReader(new FileReader("d:/a.txt"));
			String line=br.readLine();
			while(line!=null){
				String[] s=line.split(",");
				if(id==Integer.parseInt(s[0])){
					avg=(Integer.parseInt(s[2])+Integer.parseInt(s[3])+Integer.parseInt(s[4]))/3;
					break;
				}
				line=br.readLine();
			}
			return avg;
		}catch(Exception e){
			e.printStackTrace();
			return -1;
		}finally{
			if(br!=null)
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
	

	public static int avgMathScore(){
		BufferedReader br=null;
		int sum=0;
		int count=0;
		try{
			br=new BufferedReader(new FileReader("d:/a.txt"));
			String line=br.readLine();
			while(line!=null){
				String[] s=line.split(",");
				sum+=Integer.parseInt(s[2]);
				count++;
				line=br.readLine();
			}
			return sum/count;
		}catch(Exception e){
			e.printStackTrace();
			return -1;
		}finally{
			if(br!=null)
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
	
	public static void readFile(){
		try{
			FileReader fr=new FileReader("d:/a.txt");
			BufferedReader br=new BufferedReader(fr);
			String line=br.readLine();
			while(line!=null){
				System.out.println(line);
				line=br.readLine();
			}
			br.close();
			fr.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	public static void main(String[] args) {

		int avg=Text.avgMathScore();
		System.out.println(avg);
		System.out.println(Text.avgStudentScore(1));
		System.out.println(Text.topScore());
		System.out.println(Text.avgMathClass(3)); 
		HashMap<Integer,Integer> hm=Text.avgStudentsScore();
		Set<Integer> set=hm.keySet();
		Iterator i=set.iterator();
		while(i.hasNext()){
			Integer key=(Integer)i.next();
			Integer value=hm.get(key);
			System.out.println(""+key+""+value);
		}
	}

}

