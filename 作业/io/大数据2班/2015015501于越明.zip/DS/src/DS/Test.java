package DS;

public class Test {
	public static void main(String[] args) {
		// int avg = ScoreUtil.avgMathScore();
		// System.out.println(avg);
		// ScoreUtil.notPass();
		// ScoreUtil.overNinety();
		// ScoreUtil.addNew();
	}
}
