package score;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;


public class ScoreUtil {
	
	
	//查询所有有不及格科目的学生姓名
	public static ArrayList<String> failStu() {
		BufferedReader br=null;
		try {
			br = new BufferedReader(new FileReader("f:/java/workspace/a.txt"));
			String line = br.readLine();//按行读取
			ArrayList<String> list = new ArrayList<String>();//arraylist存储
			while(line != null) {
				String[] s = line.split(",");//用，分割，化为字符数组
				if(Integer.parseInt(s[3])<60 || Integer.parseInt(s[4])<60 || Integer.parseInt(s[5])<60) {
					list.add(s[2]);
				}
				line=br.readLine();
			}
			return list;//list存储学生姓名
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			if(br!=null)
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
	
	//查询所有90分以上学生姓名  同上
	public static ArrayList<String> excellentStu() {
		BufferedReader br=null;
		try {
			br = new BufferedReader(new FileReader("f:/java/workspace/a.txt"));
			String line = br.readLine();
			ArrayList<String> list = new ArrayList<String>();
			while(line != null) {
				String[] s = line.split(",");
				if(Integer.parseInt(s[3])>=90 || Integer.parseInt(s[4])>=90 || Integer.parseInt(s[5])>=90) {
					list.add(s[2]);
				}
				line=br.readLine();
			}
			return list;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			if(br!=null)
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
	
	//个班数学平均分   数组第二列为班级
	public static HashMap<Integer,Integer> avgClassMathScore() {
		BufferedReader br=null;
		HashMap<Integer,Integer> hm=new HashMap<Integer,Integer>();
		try {
			br = new BufferedReader(new FileReader("f:/java/workspace/a.txt"));
			String line=br.readLine();
			int count1 = 0;//班级人数
			int sum1 = 0;//数学总分数
			int count2 = 0;
			int sum2 = 0;
			int count3 = 0;
			int sum3 = 0;
			int count4 = 0;
			int sum4 = 0;
			while(line != null) {
				String[] s=line.split(",");
				if(Integer.parseInt(s[1]) == 1) {
					count1++;
					sum1 += Integer.parseInt(s[3]);
					hm.put(1, sum1/count1);
				}else if(Integer.parseInt(s[1]) == 2) {
					count2++;
					sum2 += Integer.parseInt(s[3]);
					hm.put(2, sum2/count2);
				}else if(Integer.parseInt(s[1]) == 3) {
					count3++;
					sum3 += Integer.parseInt(s[3]);
					hm.put(3, sum3/count3);
				}else if(Integer.parseInt(s[1]) == 4) {
					count4++;
					sum4 += Integer.parseInt(s[3]);
					hm.put(4, sum4/count4);
				}
				line = br.readLine();
			}
			return hm;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}finally{
			if(br!=null)
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
	
	
	
}
