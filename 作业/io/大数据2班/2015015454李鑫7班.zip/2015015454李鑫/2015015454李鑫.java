package bianli;
import java.io.ObjectInputStream.GetField;
import java.util.Calendar;
import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.util.Scanner;

public class Bianli {
	private static int flag;
	public static void main(String[] args)  {
		Scanner scanner = new Scanner(System.in);
		int count = 0;
		float sum = 0;
		System.out.println("�������" + 0 + "��ѧ���ĳɼ�");
		float temp = scanner.nextFloat();
		sum = temp;
		for (int i = 1; i < 10; i++) {
		System.out.println("�������" + i + "��ѧ���ĳɼ�");
		float s = scanner.nextFloat();
		sum += s;
		if ((temp - s) > 0) {
		temp = s;
		count = i;
		} else {
		}
		}
		float aver = (sum / 10 );
		System.out.println("��" + count + "��ͬѧ�ĳɼ���С��Ϊ��" + temp);
		System.out.println("ƽ���ɼ���" + aver);
        
         
    }
}
