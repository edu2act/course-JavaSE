package Score;

import java.io.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class Score {
	/**
	 * 
	 * ����һ��ѧ����Ϣ
	 */
	public static void addNew() {
		FileWriter f = null;
		Scanner scan = new Scanner(System.in);
		try {
			f = new FileWriter("d:/a.txt");
			f.write("\r\n");
			f.write(scan.nextLine());
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (f != null) {
				try {
					f.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	// ��ѯ�����в������Ŀ��ѧ��������
	public static String Failure() {
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader("d:/a.txt"));
			String line = br.readLine();
			while (line != null) {
				String[] s = line.split(",");
				for (int j = 3; j < 6; j++) {
					if (Integer.parseInt(s[j]) < 60) {
						System.out.println(s[1]);
					}
				}
				line = br.readLine();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (br != null)
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
		return null;
	}

	// ��ѯ����90������ѧ��������
	public static String overScore() {
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader("d:/a.txt"));
			String line = br.readLine();
			while (line != null) {
				String[] s = line.split(",");
				for (int j = 3; j < 6; j++) {
					if (Integer.parseInt(s[j]) > 90) {
						System.out.println(s[1]);
					}

				}
				line = br.readLine();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (br != null)
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
		return null;
	}

	// ��ѯ������ѧƽ����
	public static void avgMathScore() {
		BufferedReader br = null;
		int a = 1, b = 2, c = 3;
		int classno;
		double avg1 = 0, avg2 = 0, avg3 = 0;
		double count1 = 0, count2 = 0, count3 = 0;
		try {
			br = new BufferedReader(new FileReader("d:/a.txt"));
			String line = br.readLine();
			while (line != null) {
				String[] s = line.split(",");

				classno = Integer.parseInt(s[2]);
				if (a == classno) {
					avg1 += (Integer.parseInt(s[3]));
					count1++;
				} else if (b == classno) {
					avg2 += (Integer.parseInt(s[3]));
					count2++;
				} else if (c == classno) {
					avg3 += (Integer.parseInt(s[3]));
					count3++;
				}
				line = br.readLine();
			}
			System.out.println("�༶��" + a + "��ѧƽ���ɼ�" + avg1 / count1);
			System.out.println("�༶��" + b + "��ѧƽ���ɼ�" + avg2 / count2);
			System.out.println("�༶��" + c + "��ѧƽ���ɼ�" + avg3 / count3);
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			if (br != null)
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

		}
	}

	public static void main(String[] args) {
		Score.overScore();
		Score.Failure();
		avgMathScore();

	}
}
