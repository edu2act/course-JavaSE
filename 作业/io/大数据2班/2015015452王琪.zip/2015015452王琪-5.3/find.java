package finddata;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
 

public class find {
	public static void readFile(){
		try{
			FileReader fr = new FileReader(new File("C://DIGDATA//A.txt"));
			BufferedReader  br = new BufferedReader(fr);
				String line = br.readLine();

				while(null!=line){
					System.out.println(""+line);
					line = br.readLine();
				}
				br.close();
				fr.close();
			}catch(Exception e){
				e.printStackTrace();
			}

	}

public static int avgMathScore(){
	
		try{
			FileReader fr = new FileReader(new File("C://DIGDATA//A.txt"));
			BufferedReader  br = new BufferedReader(fr);
			int sum = 0,sum1 = 0,sum2 = 0;
			int count = 0;
			br = new BufferedReader(fr);
			String line  = br.readLine();
			while(null!=line){
				String[] s = line.split(",");
				sum+=Integer.parseInt(s[2]);
				sum1+=Integer.parseInt(s[3]);
				sum2+=Integer.parseInt(s[4]);
				count++;
				line = br.readLine();
			}
			System.out.println("数学科目的平均分是："+sum/count);
			System.out.println("语文科目的平均分是："+sum1/count);
			System.out.println("英语科目的平均分是："+sum2/count);

			br.close();
			fr.close();
			
			return 0;
		}catch(Exception e){
			e.printStackTrace();
			return -1;
		}
	}

public static int avgOneScore(){
		try{
			FileReader fr = new FileReader(new File("C://DIGDATA//A.txt"));
			BufferedReader  br = new BufferedReader(fr);
			String line  = br.readLine();
			while(null!=line){
				int sum = 0;
				String[] s = line.split(",");
				sum=Integer.parseInt(s[2])+Integer.parseInt(s[3])+Integer.parseInt(s[4]);
				System.out.println(s[1]+"学生的各科平均分为："+sum/3);			
				line = br.readLine();
			}
			
			br.close();
			fr.close();
			
			return 0;
		}catch(Exception e){
			e.printStackTrace();
			return -1;
		}
	}
		
}
