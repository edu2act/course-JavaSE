package com.myqq.util;

import java.net.InetAddress;
/**
 * 2015级3班张壮壮
 * 
 */
public class IpUtil {
	public static String getLocalHostAddress(){
		String hostName;
		try{
			InetAddress addr = InetAddress.getLocalHost();
			hostName = addr.getHostAddress();
		}catch(Exception ex){
			hostName = "";
		}
		return hostName;
	}
}
