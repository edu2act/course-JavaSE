package com.myqq.entity;



import java.util.Date;
/**
 * 2015级3班张壮壮
 * 用户的信息声明
 */
public class User {
	private	int qqNum;
	private String passWord;
	private String nickName;
	private Date registTime;
	private String gender;
	private String inttroduce;
	private String ip;
	

	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public int getQqNum() {
		return qqNum;
	}
	public void setQqNum(int qqNum) {
		this.qqNum = qqNum;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public Date getRegistTime() {
		return registTime;
	}
	public void setRegistTime(Date registTime) {
		this.registTime = registTime;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getInttroduce() {
		return inttroduce;
	}
	public void setInttroduce(String inttroduce) {
		this.inttroduce = inttroduce;
	}
	
	
}

