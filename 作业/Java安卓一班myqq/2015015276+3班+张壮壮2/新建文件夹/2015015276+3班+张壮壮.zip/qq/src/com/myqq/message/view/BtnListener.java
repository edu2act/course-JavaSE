package com.myqq.message.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

import com.myqq.entity.Message;
import com.myqq.message.service.ClientThread;
import com.myqq.message.service.MessageServiceImpl;
/**
 * 2015级3班张壮壮
 * 
 */
public class BtnListener implements ActionListener{
	
	ChatFrame chatFrame;
	public BtnListener(ChatFrame chatFrame){
		this.chatFrame = chatFrame;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		String msg = chatFrame.txtMsg.getText();
		Message message = new Message();
		message.setContent(msg);
		message.setSender(chatFrame.myself.getQqNum());
		message.setReceiver(chatFrame.another.getQqNum());
		message.setSendTime(new Date());
		message.setState(1);
		
		MessageServiceImpl messageServiceImpl = new MessageServiceImpl();
		int key = messageServiceImpl.sendMessage(message);
		message.setId(key);
		
		new Thread(new ClientThread(message,chatFrame.another.getIp())).start();
		chatFrame.txtMsg.setText("");
		// TODO Auto-generated method stub
		
	}
}
