package com.myqq.message.dao;

import com.myqq.entity.Message;
import com.myqq.util.ConnectionUtil;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

public class MessageDaoImpl {
	
	public int saveMessage(Message message){
		Connection con = null;
		PreparedStatement pstm = null;
		try{
			con = (Connection) ConnectionUtil.getCon();
			pstm=(PreparedStatement) con.prepareStatement("value",Statement.RETURN_GENERATED_KEYS);
			pstm.setInt(1, message.getId());
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

}
