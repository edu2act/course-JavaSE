package com.myqq.entity;

import java.util.Date;

public class User {// 实体bin

	private int qqNum;// QQ号码
	private String nickName;// 昵称
	private String passWord;// 密码
	private Date registTime;// 注册时间
	private String gender;// 性别
	private String introduce;// 个人介绍
	private String ip;

	public int getQqNum() {
		return qqNum;
	}

	public void setQqNum(int qqNum) {
		this.qqNum = qqNum;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public String getPassWord() {
		return passWord;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

	public Date getRegistTime() {
		return registTime;
	}

	public void setRegistTime(Date registTime) {
		this.registTime = registTime;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getIntroduce() {
		return introduce;
	}

	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		ip = ip;
	}

}
