package com.myqq.entity;

import java.io.Serializable;
import java.util.Date;

public class Message implements Serializable{//实体bin
	
	private int id;//作为主键
	private String content;//内容
	
	private int sender;//发送者
	private int receiver;//接收者
	private Date sendtime;//发送时间
	private Date receiverTime;//接受时间
	private int state;//状态
	private int type;//类型
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getSender() {
		return sender;
	}
	public void setSender(int sender) {
		this.sender = sender;
	}
	public int getReceiver() {
		return receiver;
	}
	public void setReceiver(int receiver) {
		this.receiver = receiver;
	}
	public Date getSendtime() {
		return sendtime;
	}
	public void setSendtime(Date sendtime) {
		this.sendtime = sendtime;
	}
	public Date getReceiverTime() {
		return receiverTime;
	}
	public void setReceiverTime(Date receiverTime) {
		this.receiverTime = receiverTime;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
}

