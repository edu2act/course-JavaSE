package com.myqq.user.view;

import java.sql.Date;

import com.myqq.entity.User;
import com.myqq.user.service.UserServiceImpl;

public class Test {

	public static void main(String[] args) {
		User u = new User();
		UserServiceImpl userServiceImpl = new UserServiceImpl();
		userServiceImpl.login(5, "123");
		System.out.println(u.getNickName());
		
		
		u.setNickName("hero");
		u.setPassWord("123");
		u.setIntroduce("456");
		u.setIp("127.0.0.1");
		
		UserServiceImpl userServiceImpl1 = new UserServiceImpl();
		boolean b = userServiceImpl1.regist(u);

	}

}
