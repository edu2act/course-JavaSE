package com.myqq.user.service;

import java.util.List;

import com.myqq.entity.User;
import com.myqq.user.dao.UserDaoImpl;
import com.myqq.util.IpUtil;

/**
 * @author 薛薛薛日天
	用户行为如下
		登录：获得文本框中的两个字符串  
			将其作为参数调用findByQqNumAndPassword（）
			获得返回值为一个User对象 
			在调用getLocalHostAddress()将返回值ip给User对象
			最后返回该User
 */
public class UserServiceImpl {
    //添加用户
	public boolean regist(User u){
		UserDaoImpl userDaoImpl=new UserDaoImpl();
		return userDaoImpl.saveUser(u);
	}
	//登录
	public User login(int qqNum, String password){
		UserDaoImpl userDaoImpl=new UserDaoImpl();
		User u=userDaoImpl.findByQqNumAndPassword(qqNum, password);
		if(u!=null){
			String ip=IpUtil.getLocalHostAddress();
			userDaoImpl.updateIp(qqNum, ip);
			u.setIp(ip);
			return u;
		}else{
			return null;
		}
	}
	//将数据库中的用户加到列表  调用findFriendByQqNum()
	public List<User> listFriends(int qqNum){
		UserDaoImpl userDaoImpl=new UserDaoImpl();
		return userDaoImpl.findFriendByQqNum(qqNum);
	}
	
	public User listByQqNum(int qqNum){
		UserDaoImpl userDaoImpl=new UserDaoImpl();
		return userDaoImpl.getUser(qqNum);
	}
	
}
