package com.myqq.entity;

import java.io.Serializable;
import java.util.Date;
/*
*学号:2015015515
*班级:2015级软件8班
*姓名:刘飞扬
*创建时间：2017年6月23日下午12:14:10
*类说明
*/
public class Message implements Serializable{

	private int id;//消息的ID
	private String content;//消息内容
	private int sender;//发送者
	private int receiver;//接受者
	private Date sendTime;//发送时间
	private Date receiveTime;//接受时间
	private int state;//说明
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getSender() {
		return sender;
	}
	public void setSender(int sender) {
		this.sender = sender;
	}
	public int getReceiver() {
		return receiver;
	}
	public void setReceiver(int receiver) {
		this.receiver = receiver;
	}
	public Date getSendTime() {
		return sendTime;
	}
	public void setSendTime(Date sendTime) {
		this.sendTime = sendTime;
	}
	public Date getReceiveTime() {
		return receiveTime;
	}
	public void setReceiveTime(Date receiveTime) {
		this.receiveTime = receiveTime;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
}
