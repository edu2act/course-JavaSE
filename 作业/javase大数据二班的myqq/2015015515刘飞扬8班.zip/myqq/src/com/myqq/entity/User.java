package com.myqq.entity;

import java.util.Date;
/*
*学号:2015015515
*班级:2015级软件8班
*姓名:刘飞扬
*创建时间：2017年6月23日下午12:14:19
*类说明
*/
public class User {
	private int qqnum;//qq号
	private String nickName;//qq昵称
	private String password;//qq密码
	private Date registTime;//注册时间
	private String gender;//性别
	private String introduce;//个人介绍
	private String ip;//ip地址
	
	public int getQqnum() {
		return qqnum;
	}
	public void setQqnum(int qqnum) {
		this.qqnum = qqnum;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Date getRegistTime() {
		return registTime;
	}
	public void setRegistTime(Date registTime) {
		this.registTime = registTime;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getIntroduce() {
		return introduce;
	}
	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	
}
