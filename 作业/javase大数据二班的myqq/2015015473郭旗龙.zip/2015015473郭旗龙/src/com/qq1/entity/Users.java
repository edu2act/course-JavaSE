package com.qq1.entity;

import java.io.Serializable;
import java.util.Date;

public class Users implements Serializable {
	private int qqNum;
	private String nickName;
	private String password;
	private Date registTime;
	private String gender;
	private String introduction;
	private String ip;
	
	//toString��������JTree
	public String toString(){
		return this.nickName+" "+qqNum;
	}
	
	
	//һ��get��set����
	public int getQqNum() {
		return qqNum;
	}
	public void setQqNum(int qqNum) {
		this.qqNum = qqNum;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Date getRegistTime() {
		return registTime;
	}
	public void setRegistTime(Date registTime) {
		this.registTime = registTime;
	}
	public String getIntroduction() {
		return introduction;
	}
	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	
}
