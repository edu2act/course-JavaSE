package com.qq1.message.service;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.qq1.entity.Message;
import com.qq1.entity.Users;
import com.qq1.message.dao.MessageDaoImpl;
import com.qq1.message.util.MessageFormater;
import com.qq1.message.view.Btn2Listener;
import com.qq1.message.view.ChatFrame;
import com.qq1.util.SerializableUtil;

public class ServerChat implements Runnable{
	Users u;        //��ǰ�û�  
	Users u2;		    //��Ϣ������
	List<Users> us;              //���û��ĺ����б�
	List<String> chatLog=new ArrayList<>();      //�����¼
	ChatFrame chatFrame;
	Message message;                             //��һ����Ϣ
	Socket socket;
	
	
	public ServerChat(Users u,Socket socket,List<Users> us) {
		super();
		this.u = u;
		this.socket=socket;
		this.us=us;
	}


	public void run(){
		Message message=messageReceived(socket);
		
		message.setReceiveTime(new Date());
		//���뵽���ݿ��message����
		try {
			MessageDaoImpl.saveMessage(message);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Users u2=null;
		for(Users uu:us){
			if(uu.getQqNum()==message.getSender()){
				u2=uu; break;
			}
		}
		ChatFrame chatFrame=new ChatFrame(u,u2);
		chatFrame.txtChat.setText(MessageFormater.MessageFormat(message,u2.getNickName()));
		//Ϊ�µ�chatFrame�Ӽ�����
		chatFrame.btnCommit.addActionListener(new Btn2Listener(chatFrame,u,u2,socket,us));
		
		while(true){
			Message message2=messageReceived(socket);
			message2.setReceiveTime(new Date());
			//���뵽���ݿ��message����
			try {
				MessageDaoImpl.saveMessage(message2);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			chatFrame.txtChat.setText(chatFrame.txtChat.getText()+MessageFormater.MessageFormat(message2, u2.getNickName()));
		}
	}
		/*
		if(chatFrame.isClosed()){
			try {
				socket.close();
			} catch (Exception e) {
				// TODO Auto-generated catch 9block
				e.printStackTrace();
			}
		}*/
	
	
	public Message messageReceived(Socket socket){
		Message message=null;
		try{
			InputStream is=socket.getInputStream();
			while(is.available()<=0){}   //��ѭ�����ȴ���Ϣ
			
			System.out.println("Sever�յ��ģ�"+is.available());
			byte[] cache=new byte[is.available()];
			is.read(cache);
			message=SerializableUtil.byteArrayToMessage(cache);      //����Message
			//����message�е���Ϣ���ҵ���Ϣ�����߶���
			for(Users uu:us){
				if(uu.getQqNum()==message.getReceiver()){
					u=uu; break;
				}
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return message;
	}
}
