package com.qq1.message.util;

import com.qq1.entity.Message;
import com.qq1.util.SerializableUtil;

import java.io.IOException;
import java.io.OutputStream;
import java.net.*;

public class messageSender implements Runnable{
	String ip;
	Message msg;
	
	public messageSender(Message msg, String ip){
		this.msg=msg;
		this.ip=ip;
	}

	public void run() {
		try {
			Socket socket=new Socket(ip, 8888);
			OutputStream os=socket.getOutputStream();
			os.write(SerializableUtil.messageToByteArray(msg));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	
}
