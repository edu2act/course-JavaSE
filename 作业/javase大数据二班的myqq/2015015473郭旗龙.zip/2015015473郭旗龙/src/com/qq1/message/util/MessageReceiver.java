package com.qq1.message.util;

import com.qq1.entity.Message;
import com.qq1.util.SerializableUtil;

import java.io.IOException;
import java.io.InputStream;
import java.net.*;

public class MessageReceiver implements Runnable{
	public void run(){
		try {
			ServerSocket ss=new ServerSocket(8888);
			Socket s=ss.accept();
			InputStream ins=s.getInputStream();
			byte[] b=new byte[ins.available()];
			String str=new String(b);
			System.out.println(str);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
