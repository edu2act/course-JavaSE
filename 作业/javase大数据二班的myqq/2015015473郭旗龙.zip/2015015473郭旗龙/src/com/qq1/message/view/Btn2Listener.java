package com.qq1.message.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Date;
import java.util.List;

import com.qq1.entity.Message;
import com.qq1.entity.Users;
import com.qq1.message.service.Server2Thread;
import com.qq1.message.util.MessageFormater;
import com.qq1.util.SerializableUtil;

public class Btn2Listener implements ActionListener{
	ChatFrame chatFrame;
	Users u;             //������
	Users u2;            //������
	Socket socket;
	List<Users> us;              //���û��ĺ����б�

	public Btn2Listener(ChatFrame chatFrame, Users u, Users u2,Socket socket,List<Users> us) {
		super();
		this.chatFrame = chatFrame;
		this.u=u;
		this.u2=u2;
		this.socket=socket;
		this.us=us;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		try{
			Message message=new Message();
			message.setContent(chatFrame.txtMessage.getText());
			message.setReceiver(u2.getQqNum());
			message.setSender(u.getQqNum());
			message.setSendTime(new Date());
			message.setState(1);          //SENDING
			message.setType(1);           //type��������
			
			OutputStream os=socket.getOutputStream();
			byte[] a=SerializableUtil.messageToByteArray(message);
			System.out.println(a.length);
			os.write(a);
			
			chatFrame.txtChat.setText(chatFrame.txtChat.getText()+MessageFormater.MessageFormat(message, u.getNickName()));
			chatFrame.txtMessage.setText("");
		}catch(Exception eee){
			eee.printStackTrace();
		}
	}
	
}
