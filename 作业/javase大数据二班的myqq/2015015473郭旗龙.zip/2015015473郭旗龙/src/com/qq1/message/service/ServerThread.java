package com.qq1.message.service;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import com.qq1.entity.Message;
import com.qq1.entity.Users;
import com.qq1.message.util.MessageFormater;
import com.qq1.message.view.ChatFrame;
import com.qq1.util.SerializableUtil;

public class ServerThread implements Runnable{
	
	Users u;        //��ǰ�û�  ,��Ϣ������
	List<Users> us;              //���û��ĺ����б�
	List<String> chatLog=new ArrayList<>();      //�����¼
	
	public ServerThread(Users u, List<Users> us){
		this.u=u;
		this.us=us;
	}
	
	public void run(){
		try{
			ServerSocket serverSocket=new ServerSocket(8888);
			//ÿ���յ�һ�����ӣ���Ҫ��һ��ChatFrame
			while(true){
				Socket socket=serverSocket.accept();       //�ùرղ���
				
				new Thread(new ServerChat(u,socket,us)).start();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
