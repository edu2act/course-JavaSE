package com.qq1.message.util;

import com.qq1.entity.Message;

public class MessageFormater {
	public static String MessageFormat(Message message,String name){
		return message.getSendTime().toLocaleString()+"\n"+name+" :\n"+message.getContent()+"\n\n";
	}
}
