package com.qq1.message.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.qq1.entity.Message;
import com.qq1.user.service.UserServiceUtil;

public class MessageDaoImpl {
	public static boolean saveMessage(Message message) throws ClassNotFoundException{ //�����û�ע�Ṧ��
		//������Ƽ�������������
		new UserServiceUtil();
		//�������� ������һ��SQL���
		try(Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/qq_db", "root", "");
				PreparedStatement pstm=con.prepareStatement("insert into message(sender,receiver,sendTime,"
						+ "receiveTime,state,type,content) values(?,?,?,?,?,?,?)");){
			//���ռλ��,ע������Ǵ�1��ʼ
			pstm.setInt(1, message.getSender());
			pstm.setInt(2, message.getReceiver());
			pstm.setString(3, message.getSendTime().toLocaleString());
			pstm.setString(4, message.getReceiveTime().toLocaleString());
			pstm.setInt(5, message.getState());
			pstm.setInt(6, message.getType());
			pstm.setString(7, message.getContent());
			//ִ��SQL���,��ȡӰ������
			int count=pstm.executeUpdate();
			if(count>0)	return true;
			else return false;
			//AutoClosable
		}catch(SQLException e){
			for(Throwable a:e){
				a.printStackTrace();
			}
		}
		return false;
	}
}
