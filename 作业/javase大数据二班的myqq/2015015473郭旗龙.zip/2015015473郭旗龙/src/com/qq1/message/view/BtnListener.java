package com.qq1.message.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.OutputStream;
import java.net.Socket;
import java.text.ParseException;
import java.util.Date;

import javax.swing.JFrame;

import com.qq1.entity.Message;
import com.qq1.entity.Users;
import com.qq1.message.util.MessageFormater;
import com.qq1.user.service.UserServiceImpl;
import com.qq1.util.SerializableUtil;

public class BtnListener implements ActionListener{
	ChatFrame chatFrame;
	//������ȥ�о����Ұ�
	Users u;             //������
	Users u2;            //������
	Socket socket;

	public BtnListener(ChatFrame chatFrame, Users u, Users u2,Socket socket) {
		super();
		this.chatFrame = chatFrame;
		this.u=u;
		this.u2=u2;
		this.socket=socket;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		try{
			Message message=new Message();
			message.setContent(chatFrame.txtMessage.getText());
			message.setReceiver(u2.getQqNum());
			message.setSender(u.getQqNum());
			message.setSendTime(new Date());
			message.setState(1);          //SENDING
			message.setType(1);           //type��������
			
			OutputStream os=socket.getOutputStream();
			byte[] a=SerializableUtil.messageToByteArray(message);
			System.out.println(a.length);
			os.write(a);
			
			chatFrame.txtChat.setText(chatFrame.txtChat.getText()+MessageFormater.MessageFormat(message, u.getNickName()));
			chatFrame.txtMessage.setText("");
		}catch(Exception eee){
			eee.printStackTrace();
		}
	}
	
}
