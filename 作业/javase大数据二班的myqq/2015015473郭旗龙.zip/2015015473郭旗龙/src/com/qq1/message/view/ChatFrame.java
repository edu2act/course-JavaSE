package com.qq1.message.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.qq1.entity.Users;

public class ChatFrame extends JFrame{
	public JTextField txtMessage;      //�����ı��� 
	public JButton btnCommit;			//���Ͱ�ť
	public JTextArea txtChat;			//�����¼��
	WindowListening wl=new WindowListening();
	
	Users u;           //��ǰ�û�
	Users u2;		   //�û�Ҫ����Ķ���
	
	public ChatFrame(Users u, Users u2){
		this.u=u;
		this.u2=u2;
		
		txtMessage=new JTextField();
		btnCommit=new JButton("send");
		txtChat= new JTextArea();
		//��Ҫ���ò���Ϊ��
		this.getContentPane().setLayout(null);
		
		txtChat.setLineWrap(true);
		JScrollPane scroll = new JScrollPane(txtChat);
		this.getContentPane().add(scroll);
		scroll.setBounds(3, 3, 400, 350);
		
		this.getContentPane().add(txtMessage);
		txtMessage.setBounds(3, 356, 300, 30);
		
		this.getContentPane().add(btnCommit);
		btnCommit.setBounds(306, 356, 80, 30);
		
		
		this.setTitle(u2.getNickName()+"("+u2.getQqNum()+")");
		this.setSize(406, 440);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.addWindowListener(wl);
		this.setVisible(true);
	}
	public boolean isClosed(){
		return wl.c;
	}
}

class WindowListening implements WindowListener{
	boolean c=false;
	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
	//Ҫʵ�ֵ��������������
	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub
		c=true;
		System.out.println("ChatFrame was closed!");
	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}
