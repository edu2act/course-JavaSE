package com.qq1.user.view;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginFrame extends JFrame{
	JLabel lblQQNum;
	JLabel lblPassword;
	JTextField txtQQNum;
	JPasswordField txtPassword;
	JButton btnLogin;
	JButton btnCancel;
	JButton btnRegist;
	
	
	public LoginFrame(){
		//�ؼ�
		lblQQNum=new JLabel("QQ�ţ�");
		lblPassword=new JLabel("QQ���룺");
		txtQQNum=new JTextField();
		txtPassword=new JPasswordField();
		btnLogin=new JButton("��½");
		btnCancel=new JButton("ȡ��");
		btnRegist=new JButton("����ע��");
		//��Ҫ���ò���Ϊ��
		this.getContentPane().setLayout(null);
		//��ǩ
		this.getContentPane().add(lblQQNum);
		lblQQNum.setBounds(20,20,160,25);
		
		this.getContentPane().add(lblPassword);
		lblPassword.setBounds(20,65,160,25);
		//�ı���
		this.getContentPane().add(txtQQNum);
		txtQQNum.setBounds(100,20,160,25);

		this.getContentPane().add(txtPassword);
		txtPassword.setBounds(100,65,160,25);
		//��ť
		this.getContentPane().add(btnRegist);
		btnRegist.setBounds(40,120,200,25);
		
		this.getContentPane().add(btnLogin);
		btnLogin.setBounds(40,160,80,25);

		this.getContentPane().add(btnCancel);
		btnCancel.setBounds(160,160,80,25);
		
		this.setTitle("QQ��½");
		this.setSize(300, 240);
		this.setVisible(true);
		
		//ע�ᰴť�¼�
		btnRegist.addActionListener(new Btn3Listener());
		//��¼��ť�¼�
		btnLogin.addActionListener(new BtnListener(this));
		//ȡ����ť�¼�
		btnCancel.addActionListener(new Btn2Listener(this));
		
	}
	
	
}
