package com.qq1.user.service;

import java.sql.SQLException;
import java.text.ParseException;

import com.qq1.entity.Users;
import com.qq1.user.dao.UserDaoImpl;

public class UserServiceImpl {
	public boolean regist(Users u){//ע�Ṧ��
		UserDaoImpl UserDaoImpl1=new UserDaoImpl();
		try {
			return UserDaoImpl1.saveUser(u);
		} catch (ClassNotFoundException e){
			e.printStackTrace();
		}
		return false;
	}
	
	public static Users login(int qqNum, String password) throws ParseException{//���������ûд�꣬���񻹵õ���foundfriends��
		//����Ҫ����IP
		UserDaoImpl UserDaoImpl1=new UserDaoImpl();
		Users u=null;
		try {
			u=UserDaoImpl1.foundByQQNumAndPassword(qqNum, password);
		} catch (ClassNotFoundException e){
			e.printStackTrace();
		}
		//����IP
		if(u!=null){
			String ip=null;
			try {
				UserDaoImpl.updateIP(qqNum, ip);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			u.setIp(ip);
		}
		return u;
	}
}
