package com.qq1.user.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Btn3Listener implements ActionListener{
	@Override
	public void actionPerformed(ActionEvent e) {
		RegistFrame a=new RegistFrame();
		a.setDefaultCloseOperation(a.DISPOSE_ON_CLOSE);
	}
}
