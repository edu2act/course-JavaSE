package com.qq1.user.view;

import java.util.Date;

import com.qq1.entity.Users;
import com.qq1.user.service.UserServiceImpl;



public class Test {
	public static void main(String... args){
		Users u=new Users();
		u.setNickName("Lis");
		u.setGender("female");
		u.setIntroduction("Hello, my name is Lisa!");
		u.setIp("127.0.0.1");
		u.setPassword("123");
		u.setRegistTime(new Date());
		
		UserServiceImpl userServiceImpl=new UserServiceImpl();
		if(userServiceImpl.regist(u)){
			System.out.println("ע��ɹ���");
		}else{
			System.out.println("ע��ʧ�ܣ�");
		}
		
	}
}
