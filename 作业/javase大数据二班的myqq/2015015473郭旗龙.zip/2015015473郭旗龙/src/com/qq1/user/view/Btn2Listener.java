package com.qq1.user.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Btn2Listener implements ActionListener{
	LoginFrame loginFrame;
	
	public Btn2Listener(LoginFrame loginFrame){
		this.loginFrame=loginFrame;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		this.loginFrame.setDefaultCloseOperation(this.loginFrame.EXIT_ON_CLOSE);
		this.loginFrame.dispose();
		this.loginFrame=null;
	}
	
}
