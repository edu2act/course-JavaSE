package com.qq1.util;

import com.qq1.entity.Message;
import java.io.*;

//��message����תΪ�ֽ�����
public class SerializableUtil {
	public static byte[] messageToByteArray(Message message) throws IOException{
		ByteArrayOutputStream a=null;
		ObjectOutputStream b=null;
		byte[] c=null;
		try{
			a=new ByteArrayOutputStream();
			b=new ObjectOutputStream(a);
			b.writeObject(message);
			c=a.toByteArray();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(b!=null)	b.close();
		if(a!=null)	a.close();
		return c;
	}
	
	public static Message byteArrayToMessage(byte[] c) throws IOException{
		ByteArrayInputStream a=null;
		ObjectInputStream b=null;
		Message message=null;
		try{
			a=new ByteArrayInputStream(c);
			b=new ObjectInputStream(a);
			message=(Message)b.readObject();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(b!=null)	b.close();
		if(a!=null)	a.close();
		return message;
	}
}
