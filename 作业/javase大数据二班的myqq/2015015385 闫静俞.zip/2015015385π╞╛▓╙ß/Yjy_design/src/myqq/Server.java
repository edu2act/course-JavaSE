/**
 * 说明：TCP聊天
 * 姓名：闫静俞
 * 学号：2015015385
 * 班级：5班
 * 日期：2017年6月20日
 */
package myqq;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	public static void main(String[] args) {
		ServerSocket server;
		try {
			server = new ServerSocket(8888);
			System.out.println("server listener:");
			while (true) {
				Socket client = server.accept();
				new Thread(new RespouseRunnable(client)).start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}