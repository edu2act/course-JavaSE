/**
 * 说明：TCP聊天
 * 姓名：闫静俞
 * 学号：2015015385
 * 班级：5班
 * 日期：2017年6月20日
 */
package myqq;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class ReadMsgRunnable implements Runnable {
	private Socket client;
	private BufferedReader bufr;
	
	public ReadMsgRunnable(Socket client) {
		super();
		this.client = client;
		try {
			bufr = new BufferedReader(new InputStreamReader(client.getInputStream()));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void run() {
		try {
			String temp = null;

			while (true) {
				temp = bufr.readLine();
				System.out.println(temp.trim());
				if (temp.startsWith("end")) {
					break;
				}
			}
			bufr.close();
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			try {
				client.close();
				System.exit(0);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}