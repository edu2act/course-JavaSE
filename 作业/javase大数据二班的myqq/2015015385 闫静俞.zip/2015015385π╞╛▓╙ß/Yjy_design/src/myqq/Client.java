/**
 * 说明：TCP聊天
 * 姓名：闫静俞
 * 学号：2015015385
 * 班级：5班
 * 日期：2017年6月20日
 */
package myqq;

import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
	public static void main(String[] args) {
		Socket client = null;
		try {
			client = new Socket("127.0.0.1", 8888);

			new Thread(new ReadMsgRunnable(client)).start();
			
			OutputStream os = client.getOutputStream();

			while(true){
				byte[] input = new byte[1024];
				System.in.read(input);
				os.write(input);
				os.flush();
				String inputstr = new String(input);
				if (inputstr.startsWith("end")) {
					break;
				}
			}
			os.close();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			try {
				client.close();
				System.exit(0);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}