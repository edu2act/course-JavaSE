package myqqUDP;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class Server {

	public Server() {
	}
	public static void main(String[] args) {
		
		try {
			@SuppressWarnings("resource")
			DatagramSocket server = new DatagramSocket(8888);

			// 准备空缓冲区
			byte[] buf = new byte[1024];

			// 循环等待客户端请求
		     while (true) {
				// 创建DatagramPacket对象
	 			DatagramPacket request = new DatagramPacket(buf, buf.length);
				server.receive(request);
				String a=new String(buf);
			    System.out.println("server收到!"+a.trim());//回复收到给客户端
				byte[] resBuf = "from server: ".getBytes();
				DatagramPacket response = new DatagramPacket(resBuf, resBuf.length, request.getAddress(), request.getPort());
				server.send(response);
				}
		} catch (SocketException e) {
		   System.out.println("程序发生异常！！！");
		}
		catch (IOException e) {
			System.out.println("程序发生异常！！！");
		}
		
	}

}