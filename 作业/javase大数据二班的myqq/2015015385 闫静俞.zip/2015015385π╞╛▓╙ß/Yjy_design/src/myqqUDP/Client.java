package myqqUDP;

/*
 * 姓名：闫静俞
 * 学号：2015015385
 * 班级：5班
 * 功能：用UDP协议实现聊天程序
 * 时间：6月20号
 * */

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

public class Client {

	public Client() {
		
	}
	public static void main(String[] args) {
		DatagramSocket client = null;
		try {
			client = new DatagramSocket();
			byte[] buf = "I'm client!".getBytes();
			InetAddress address = null;
			address = InetAddress.getLocalHost();
			DatagramPacket request =new DatagramPacket(buf, buf.length, address , 8888);
			client.send(request);
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			System.out.println("发生异常！");
		}
		 catch (UnknownHostException e) {
			System.out.println("发生异常！");
		}
		 catch (IOException e) {
			System.out.println("发生异常！");
		}
	}
}