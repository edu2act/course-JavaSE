package com.myqq.user.view;

public class Sever {
		public static void main(String args[]){
			LoginFrame loginFrame = new LoginFrame();
		}
}
