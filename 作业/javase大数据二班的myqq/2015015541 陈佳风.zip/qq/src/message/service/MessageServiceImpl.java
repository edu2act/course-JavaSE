package message.service;

import entity.Message;
import message.dao.MessageDaoImpl;

public class MessageServiceImpl {
	
	public int sendMessage(Message message){
		
		MessageDaoImpl messageDaoImpl=new MessageDaoImpl();
		
		return messageDaoImpl.saveMessage(message);
	}
}