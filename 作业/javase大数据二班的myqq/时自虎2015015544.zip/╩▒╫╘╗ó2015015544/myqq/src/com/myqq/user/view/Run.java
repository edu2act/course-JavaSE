package com.myqq.user.view;

public class Run {

	public static void main(String[] args) {
		LoginFrame loginFrame=new LoginFrame();

	}

}
