
package dougangFoxmail.com;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket; 
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Server extends JPanel implements ActionListener{
	
	public static void main(String[] args) {
        new Server();
    }
	
	//�������
    JFrame jframe;
    JTextField SendJTF;
    JButton SendJB;
    JButton CancleJB;
    JTextArea jta=null;
    JScrollPane jsp=null;
    PrintWriter pw;
    public Server(){
    	this.setLayout(null);
    	//�������
    	jta=new JTextArea();
    	jsp=new JScrollPane(jta);
        jsp.setBounds(8,70,380,550);
        this.add(jsp);
            
        SendJTF=new JTextField(15);
        SendJTF.addActionListener(this);
        SendJTF.setBackground(Color.white);
        SendJTF.setBounds(8,665,380,33);
        this.add(SendJTF);
        
        //���Ͱ�ť
        SendJB=new JButton("����");
        SendJB.setBounds(300,628,80,25);
        SendJB.addActionListener(this);
        this.add(SendJB);
         
        //ȡ����ť
        CancleJB=new JButton("ȡ��");
        CancleJB.setBounds(10,628,80,25);
        CancleJB.addActionListener(this);
        this.add(CancleJB);
         
        jframe=new JFrame("QQ���촰��  ������");
        jframe.setBounds(0, 0,400, 800);
        jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jframe.add(this);
        jframe.setVisible(true);
        jframe.setResizable(false);
      
        //��������
        try {
        	
        	//����8888�˿�
            ServerSocket server=new ServerSocket(8888);
            
            //�ȴ��ͻ�������
            Socket s=server.accept();
            
            // �������� ���ܴӿͻ��˷�������Ϣ
            InputStreamReader in=new InputStreamReader(s.getInputStream());
            
            //�ø߼������������������������Ϣ
            BufferedReader reader=new BufferedReader(in);
            
            //����׼��
            pw=new PrintWriter(s.getOutputStream(),true);
            while(true){
            	//����ӿͻ��˷�������Ϣ
                String infoClient=reader.readLine();
                jta.append("�ͻ���:"+infoClient+"\n");
            }
            
        } catch (Exception e) {
        	e.printStackTrace();
        }
     }
    
    //���ñ���
    protected void paintComponent(Graphics g){
    	try {
    		BufferedImage  Background=ImageIO.read(new File("D://1.PNG"));
            g.drawImage(Background, 0, 0,400, 750,null);
        } catch (IOException e) {
        	e.printStackTrace();
        }
    } 
    //�¼�������������
    public void actionPerformed(ActionEvent e) {
    	//���Ͱ�ť
        if(e.getSource()==SendJB){
        	String info=SendJTF.getText();
            pw.println(info);
            SendJTF.setText("");
            jta.append("���ͣ�"+info+"\n");
        }
    }
}
