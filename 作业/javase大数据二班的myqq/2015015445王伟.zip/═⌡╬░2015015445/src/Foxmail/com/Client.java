
package dougangFoxmail.com;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Client  extends JPanel implements ActionListener{
	
	public static void main(String[] args) throws UnknownHostException {
		new Client();    
    }
	
    //�������
    JFrame jf;
    JTextField SendJTF;
    JButton SendJB;
    JButton CancleJB;
    JTextArea jta=null;
    JScrollPane jsp=null;
    PrintWriter pw;
    
    public Client() throws UnknownHostException{
        this.setLayout(null);
        //�������
        jta=new JTextArea();
        jsp=new JScrollPane(jta);
        jsp.setBounds(8,70,380,550);
        this.add(jsp);
         
        //�������  
        SendJTF=new JTextField(15);
        SendJTF.addActionListener(this);
        SendJTF.setBackground(Color.white);
        SendJTF.setBounds(8,665,380,33);
        this.add(SendJTF);
          
        //���Ͱ�ť
        SendJB=new JButton("����");
        SendJB.setBounds(300,628,80,25);
        SendJB.addActionListener(this);
        this.add(SendJB);
        
        //ȡ����ť
        CancleJB=new JButton("ȡ��");
        CancleJB.setBounds(10,628,80,25);
        CancleJB.addActionListener(this);
        this.add(CancleJB);
       
         //��������
	     jf=new JFrame("QQ���촰��  �ͻ���");
	     jf.setBounds(0, 0,400, 800);
	     jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	     jf.add(this);
	     jf.setVisible(true);
	     jf.setResizable(false);
	      
         //���ӷ�����
         try {
        	 
        	 //��ȡ����ip��ַ������8888�˿�
             InetAddress ip=InetAddress.getLocalHost();
             Socket socket=new Socket(ip,8888 );
             
             //���������ܴӷ�������������Ϣ
             InputStreamReader in=new  InputStreamReader(socket.getInputStream());
             
             //�߼�����ȡ�ܵ���Ϣ
             BufferedReader reader=new BufferedReader(in);
             
             //����׼��
             pw=new PrintWriter(socket.getOutputStream(),true);
             while(true){
            	 //���շ���������Ϣ
                 String infoServer=reader.readLine();
                 jta.append("������:"+infoServer+"\n");
             }
         } catch (Exception e) {
        	 e.printStackTrace();
         }
     }
 
     //���ñ���
     protected void paintComponent(Graphics g){
    	 try {
    		 BufferedImage  Background=ImageIO.read(new File("D://1.PNG"));
             g.drawImage(Background, 0, 0,400, 750,null);
         } catch (IOException e) {
        	 // TODO Auto-generated catch block
             e.printStackTrace();
         }
     }
     
     //�¼�������������
     public void actionPerformed(ActionEvent e) {
    	 if(e.getSource()==SendJB){
	         String info=SendJTF.getText();
	         pw.println(info);
	         SendJTF.setText("");
	         jta.append("���ͣ�"+info+"\n");
         }
     }
}