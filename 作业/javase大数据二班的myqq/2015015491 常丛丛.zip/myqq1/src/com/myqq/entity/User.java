/*
package com.myqq.entity;

import java.io.Serializable;
import java.sql.Date;

public class Users implements Serializable{
	private static final long serialVersionUID = 7736606016903567469L;
	private int qqnum;
	private char[] nickname;
	private char[] password;
	private Date regitstTime;
	private char[] gender;
	private char[] introduce;
	public int getQqnum() {
		return qqnum;
	}
	public void setQqnum(int qqnum) {
		this.qqnum = qqnum;
	}
	public char[] getNickname() {
		return nickname;
	}
	public void setNickname(char[] nickname) {
		this.nickname = nickname;
	}
	public char[] getPassword() {
		return password;
	}
	public void setPassword(char[] password) {
		this.password = password;
	}
	public Date getRegitstTime() {
		return regitstTime;
	}
	public void setRegitstTime(Date regitstTime) {
		this.regitstTime = regitstTime;
	}
	public char[] getGender() {
		return gender;
	}
	public void setGender(char[] gender) {
		this.gender = gender;
	}
	public char[] getIntroduce() {
		return introduce;
	}
	public void setIntroduce(char[] introduce) {
		this.introduce = introduce;
	}

 
}*/
package com.myqq.entity;

import java.util.Date;

public class User {
	private int qqnum;
	private String nickName;
	private String password;
	private Date registTime;
	private String gender;
	private String introduce;
	private String ip;
	
	public int getQqnum() {
		return qqnum;
	}
	public void setQqnum(int qqnum) {
		this.qqnum = qqnum;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Date getRegistTime() {
		return registTime;
	}
	public void setRegistTime(Date registTime) {
		this.registTime = registTime;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getIntroduce() {
		return introduce;
	}
	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	
}

