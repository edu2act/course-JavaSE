package homework;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
 
public class socket extends JPanel implements ActionListener{
public static void main(String[] args) {
        new socket();
         
    }  
   //�������
    JFrame jf;
    JTextField SendJTF;
    JButton SendJB;
    JTextArea jta=null;
    JScrollPane jsp=null;
    PrintWriter pw;
     public socket(){
          
         this.setLayout(null);
      //�������
        jta=new  JTextArea();
        jsp=new  JScrollPane(jta);
        jsp.setBounds(0,50,650,210);
        this.add(jsp);
            
         SendJTF=new JTextField(15);
         SendJTF.addActionListener(this);
         SendJTF.setBounds(0,250,650,120);
         this.add(SendJTF);
          
        //���Ͱ�ť
         SendJB=new JButton("����");
         SendJB.setBounds(536,378,100,25);
         SendJB.addActionListener(this);
         this.add(SendJB);
      jf=new JFrame("QQ�������� �ͻ���");
      jf.setBounds(400, 100, 660, 445);
      jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      jf.add(this);
      jf.setVisible(true);
      jf.setResizable(false);
       
         //���ӷ�����
            try {
                Socket s=new Socket("127.0.0.1",8888 );
                 //���ܴӷ�������������Ϣ
                InputStreamReader isr=new  InputStreamReader(s.getInputStream());
                BufferedReader br=new BufferedReader(isr);
                //����׼��
                pw=new PrintWriter(s.getOutputStream(),true);
                while(true){
                    //���շ���������Ϣ
                    String infoServer=br.readLine();
                    jta.append("������:"+infoServer+"\n");
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
     }
        //�¼�������������
        public void actionPerformed(ActionEvent e) {
            if(e.getSource()==SendJB){
                String info=SendJTF.getText();
                pw.println(info);
                SendJTF.setText("");
                jta.append("���ͣ�"+info+"\n");
                 
            }
        }
}