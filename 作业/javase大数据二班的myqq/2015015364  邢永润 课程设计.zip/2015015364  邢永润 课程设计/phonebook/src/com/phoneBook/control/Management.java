package com.phoneBook.control;

import com.phoneBook.model.Person;
import com.phoneBook.model.PhoneBook;
import java.util.LinkedList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;

public class Management {

	Lock lock = new ReentrantLock();
	PhoneBook book = new PhoneBook();
	Person p;

	/**
	 * 添加联系人信息
	 * 
	 * @param p
	 * @return 是否添加成功（重名会导致添加失败）
	 */
	public boolean addPerson(Person p) {
		boolean result = false;
		try {
			result = book.addPerson(p);
		} catch (Exception ex) {
			Logger.getLogger(Management.class.getName()).log(Level.SEVERE, null, ex);
		}
		return result;
	}

	/**
	 * 该联系人是否已存在
	 * 
	 * @param name
	 * @return 该联系人是否已存在
	 */
	public boolean hasPerson(String name) {
		try {
			p = book.seekPerson(name);
		} catch (Exception ex) {
			Logger.getLogger(Management.class.getName()).log(Level.SEVERE, null, ex);
		}
		return p.getName().equals("") ? false : true;
	}

	/**
	 * 查询该联系人头像
	 * 
	 * @param name
	 * @return 该联系人头像所在目录
	 */
	public String photo(String name) {
		try {
			p = book.seekPerson(name);
		} catch (Exception ex) {
			Logger.getLogger(Management.class.getName()).log(Level.SEVERE, null, ex);
		}
		return p.getPhoto();
	}

	/**
	 * 查询联系人
	 * 
	 * @param name
	 * @return Person
	 */
	public Person seekPerson(String name) {
		try {
			p = book.seekPerson(name);
		} catch (Exception ex) {
			Logger.getLogger(Management.class.getName()).log(Level.SEVERE, null, ex);
		}
		return p;
	}

	/**
	 * 编辑联系人信息
	 * 
	 * @param p
	 * @return 是否编辑成功
	 */
	public boolean edit(Person p) {
		boolean result = false;
		try {
			result = book.edit(p);
		} catch (Exception ex) {
			Logger.getLogger(Management.class.getName()).log(Level.SEVERE, null, ex);
		}
		return result;
	}

	/**
	 * 删除联系人
	 * 
	 * @param name
	 * @return boolean
	 */
	public boolean remove(String name) {
		boolean result = false;
		try {
			result = book.remove(name);
		} catch (Exception ex) {
			Logger.getLogger(Management.class.getName()).log(Level.SEVERE, null, ex);
		}
		return result;
	}

	/**
	 * 初始化树状列表
	 * 
	 * @param root
	 * @return void
	 */
	public void initTree(JTree jTree, DefaultMutableTreeNode root) {
		lock.lock();
		try {
			LinkedList<String> gruopList = new LinkedList<String>();
			LinkedList<String> memberList = new LinkedList<String>();
			try {
				gruopList = book.seekGroup();
			} catch (Exception ex) {
				Logger.getLogger(Management.class.getName()).log(Level.SEVERE, null, ex);
			}
			for (int i = 0; i < gruopList.size(); i++) {
				DefaultMutableTreeNode groupNode = new DefaultMutableTreeNode((String) gruopList.get(i));
				root.add(groupNode);
				try {
					memberList = book.seekMember(gruopList.get(i));
				} catch (Exception ex) {
					Logger.getLogger(Management.class.getName()).log(Level.SEVERE, null, ex);
				}
				for (int j = 0; j < memberList.size(); j++) {
					DefaultMutableTreeNode memberNode = new DefaultMutableTreeNode((String) memberList.get(j));
					groupNode.add(memberNode);
				}
			}
		} finally {
			lock.unlock();
		}
	}
}
