package com.phoneBook.model;

public interface IPhoneBook {
    
    /**
     * 添加
     * @param p
     * @return 是否添加成功
     */
    public boolean addPerson(Person p) throws Exception;

    /**
     * 查询
     * @param name
     * @return 查询到的person
     */
    public Person seekPerson(String name) throws Exception;

    /**
     * 编辑
     * @param p
     * @return 是否编辑成功
     */
    public boolean edit(Person p) throws Exception;

    /**
     * 删除
     * @param name
     * @return 是否删除成功
     */
    public boolean remove(String name) throws Exception;
}
