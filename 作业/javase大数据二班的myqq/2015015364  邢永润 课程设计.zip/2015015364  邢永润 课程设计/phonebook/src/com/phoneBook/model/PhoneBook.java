package com.phoneBook.model;

import java.io.FileOutputStream;
import java.util.LinkedList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import javax.xml.parsers.*;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

public class PhoneBook implements IPhoneBook {

    Lock lock = new ReentrantLock();
    Person p;

    @Override
    public boolean addPerson(Person p) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.parse("C://Users//yy//Documents//NetBeansProjects//U1Project02//PhoneBook.xml");
        NodeList personList = doc.getElementsByTagName("person");
        for (int i = 0; i < personList.getLength(); i++) {
            Node person = personList.item(i);
            Element element = (Element) person;
            String attrValue = element.getAttribute("name");
            if (attrValue.equals(p.getName())) {
                return false;
            }
        }
        Element personElement = doc.createElement("person");
        personElement.setAttribute("name", p.getName());
        personElement.setAttribute("sex", p.getSex());
        personElement.setAttribute("birthday", p.getBirthday());
        personElement.setAttribute("group", p.getGroup());
        personElement.setAttribute("tele", p.getTele());
        personElement.setAttribute("cell", p.getCell());
        personElement.setAttribute("email", p.getEmail());
        personElement.setAttribute("photo", p.getPhoto());
        Element phoneElement = (Element) doc.getElementsByTagName("PhoneBook").item(0);
        phoneElement.appendChild(personElement);
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer t = tf.newTransformer();
        DOMSource ds = new DOMSource(doc);
        t.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        StreamResult sr = new StreamResult(new FileOutputStream("C://Users//yy//Documents//NetBeansProjects//U1Project02//PhoneBook.xml"));
        t.transform(ds, sr);
        return true;
    }

    @Override
    public Person seekPerson(String name) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.parse("C://Users//yy//Documents//NetBeansProjects//U1Project02//PhoneBook.xml");
        NodeList personList = doc.getElementsByTagName("person");
        for (int i = 0; i < personList.getLength(); i++) {
            Node person = personList.item(i);
            Element element = (Element) person;
            String attrValue = element.getAttribute("name");
            if (attrValue.equals(name)) {
                p = new Person(attrValue, element.getAttribute("sex"), element.getAttribute("birthday"),
                        element.getAttribute("group"), element.getAttribute("tele"), element.getAttribute("cell"),
                        element.getAttribute("email"), element.getAttribute("photo"));
                return p;
            }
        }
        return new Person();
    }

    //edit与remove方法用Lock锁后都会报错，并返回false，但确实对xml文件做出了更改。
    @Override
    public boolean edit(Person p) throws Exception {
        lock.lock();
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse("C://Users//yy//Documents//NetBeansProjects//U1Project02//PhoneBook.xml");
            NodeList personList = doc.getElementsByTagName("person");
            for (int i = 0; i < personList.getLength(); i++) {
                Node person = personList.item(i);
                Element element = (Element) person;
                String attrValue = element.getAttribute("name");
                if (attrValue.equals(p.getName())) {
                    element.setAttribute("sex", p.getSex());
                    element.setAttribute("birthday", p.getBirthday());
                    element.setAttribute("group", p.getGroup());
                    element.setAttribute("tele", p.getTele());
                    element.setAttribute("cell", p.getCell());
                    element.setAttribute("email", p.getEmail());
                    element.setAttribute("photo", p.getPhoto());
                    TransformerFactory tf = TransformerFactory.newInstance();
                    Transformer t = tf.newTransformer();
                    DOMSource ds = new DOMSource(doc);
                    t.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
                    StreamResult sr = new StreamResult(new FileOutputStream("C://Users//yy//Documents//NetBeansProjects//U1Project02//PhoneBook.xml"));
                    t.transform(ds, sr);
                    return true;
                }
            }
        } finally {
            lock.unlock();
        }
        return false;
    }

    @Override
    public boolean remove(String name) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.parse("C://Users//yy//Documents//NetBeansProjects//U1Project02//PhoneBook.xml");
        NodeList personList = doc.getElementsByTagName("person");
        for (int i = 0; i < personList.getLength(); i++) {
            Node person = personList.item(i);
            Element element = (Element) person;
            String attrValue = element.getAttribute("name");
            if (attrValue.equals(name)) {
                element.getParentNode().removeChild(person);
                TransformerFactory tf = TransformerFactory.newInstance();
                Transformer t = tf.newTransformer();
                DOMSource ds = new DOMSource(doc);
                t.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
                StreamResult sr = new StreamResult(new FileOutputStream("C://Users//yy//Documents//NetBeansProjects//U1Project02//PhoneBook.xml"));
                t.transform(ds, sr);
                return true;
            }
        }
        return false;
    }

    /**
     * 寻组
     * @param void
     * @return LinkedList
     */
    public LinkedList<String> seekGroup() throws Exception {
        boolean flag = false;
        LinkedList<String> list = new LinkedList<String>();
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.parse("C://Users//yy//Documents//NetBeansProjects//U1Project02//PhoneBook.xml");
        NodeList personList = doc.getElementsByTagName("person");
        for (int i = 0; i < personList.getLength(); i++) {
            Node person = personList.item(i);
            Element element = (Element) person;
            String attrValue = element.getAttribute("group");
            if (flag == false) {
                list.add(attrValue);
                flag = true;
            }
            for (int j = 0; j < list.size(); j++) {
                if (attrValue.equals((String) list.get(j))) {
                    break;
                } else if (j == list.size() - 1) {
                    list.addLast(attrValue);
                }
            }
        }
        return list;
    }

    /**
     * 寻组员
     * @param group
     * @return LinkedList
     */
    public LinkedList<String> seekMember(String group) throws Exception {
        LinkedList<String> list = new LinkedList<String>();
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.parse("C://Users//yy//Documents//NetBeansProjects//U1Project02//PhoneBook.xml");
        NodeList personList = doc.getElementsByTagName("person");
        for (int i = 0; i < personList.getLength(); i++) {
            Node person = personList.item(i);
            Element element = (Element) person;
            String attrValue = element.getAttribute("group");
            if (attrValue.equals(group)) {
                list.add(element.getAttribute("name"));
            }
        }
        return list;
    }
}
