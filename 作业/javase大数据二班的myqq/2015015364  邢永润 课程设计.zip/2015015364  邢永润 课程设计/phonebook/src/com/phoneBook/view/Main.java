package com.phoneBook.view;

import com.phoneBook.control.Management;
import com.phoneBook.model.Person;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.UIManager;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

public class Main extends javax.swing.JFrame implements ActionListener {

    private String mainName = "您好";
    private String temp = "";
    Person p;
    Management manage = new Management();
    JPopupMenu menu = new JPopupMenu();
    JMenuItem talk = new JMenuItem("聊天");
    JMenuItem info = new JMenuItem("资料");
    JMenuItem edit = new JMenuItem("编辑");
    JMenuItem dele = new JMenuItem("删除");

    public Main() {
        initComponents();
    }

    public Main(String mainName) {
        this.mainName = mainName;
        initComponents();
        this.setTitle("主界面");
        this.setResizable(false);
        this.setVisible(true);
        this.setBounds(400, 150, 296, 513);
        menu.add(talk);
        menu.add(info);
        menu.add(edit);
        menu.add(dele);
        talk.addActionListener(this);
        info.addActionListener(this);
        edit.addActionListener(this);
        dele.addActionListener(this);
    }


    @SuppressWarnings("unchecked")
    private void initComponents() {

        jpNorth = new javax.swing.JPanel();
        jlPhoto = new javax.swing.JLabel();
        jlWelcome = new javax.swing.JLabel();
        jlVersion1 = new javax.swing.JLabel();
        jlTitle = new javax.swing.JLabel();
        jpSouth = new javax.swing.JPanel();
        jlVersion2 = new javax.swing.JLabel();
        jbAdd = new javax.swing.JButton();
        jbFound = new javax.swing.JButton();
        jpCenter = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTree = new javax.swing.JTree();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jpNorth.setBackground(new java.awt.Color(51, 153, 255));
        jpNorth.setPreferredSize(new java.awt.Dimension(280, 120));

        jlPhoto.setText(null);
        jlPhoto.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jlPhoto.setIcon(new ImageIcon(manage.photo(mainName)));

        jlWelcome.setFont(new java.awt.Font("微软雅黑", 0, 14));
        jlWelcome.setForeground(new java.awt.Color(255, 255, 255));
        jlWelcome.setText(this.mainName + "，欢迎登录！");
        jlWelcome.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Welcome", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("微软雅黑", 0, 10), java.awt.Color.white)); // NOI18N

        jlVersion1.setFont(new java.awt.Font("微软雅黑", 0, 12));
        jlVersion1.setForeground(new java.awt.Color(255, 255, 255));
        jlVersion1.setText("Version 2.0");

        jlTitle.setFont(new java.awt.Font("微软雅黑", 0, 24));
        jlTitle.setForeground(new java.awt.Color(255, 255, 255));
        jlTitle.setText("QQ 2012");

        javax.swing.GroupLayout jpNorthLayout = new javax.swing.GroupLayout(jpNorth);
        jpNorth.setLayout(jpNorthLayout);
        jpNorthLayout.setHorizontalGroup(
            jpNorthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpNorthLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlPhoto, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpNorthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpNorthLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jpNorthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jlWelcome, javax.swing.GroupLayout.DEFAULT_SIZE, 147, Short.MAX_VALUE)
                            .addComponent(jlTitle)))
                    .addGroup(jpNorthLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 82, Short.MAX_VALUE)
                        .addComponent(jlVersion1)))
                .addContainerGap())
        );
        jpNorthLayout.setVerticalGroup(
            jpNorthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpNorthLayout.createSequentialGroup()
                .addGroup(jpNorthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jpNorthLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jlPhoto, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE))
                    .addGroup(jpNorthLayout.createSequentialGroup()
                        .addComponent(jlVersion1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jlTitle)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jlWelcome)))
                .addContainerGap())
        );

        getContentPane().add(jpNorth, java.awt.BorderLayout.PAGE_START);

        jpSouth.setBackground(new java.awt.Color(204, 204, 255));
        jpSouth.setPreferredSize(new java.awt.Dimension(280, 25));

        jlVersion2.setFont(new java.awt.Font("微软雅黑", 1, 14));
        jlVersion2.setForeground(new java.awt.Color(255, 255, 255));
        jlVersion2.setText("Version 2.0");

        jbAdd.setBackground(new java.awt.Color(204, 204, 204));
        jbAdd.setFont(new java.awt.Font("微软雅黑", 0, 12));
        jbAdd.setText("添 加");
        jbAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbAddActionPerformed(evt);
            }
        });

        jbFound.setBackground(new java.awt.Color(204, 204, 204));
        jbFound.setFont(new java.awt.Font("微软雅黑", 0, 12));
        jbFound.setText("查 询");
        jbFound.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbFoundActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jpSouthLayout = new javax.swing.GroupLayout(jpSouth);
        jpSouth.setLayout(jpSouthLayout);
        jpSouthLayout.setHorizontalGroup(
            jpSouthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpSouthLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jbAdd)
                .addGap(10, 10, 10)
                .addComponent(jbFound)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
                .addComponent(jlVersion2)
                .addContainerGap())
        );
        jpSouthLayout.setVerticalGroup(
            jpSouthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpSouthLayout.createSequentialGroup()
                .addGroup(jpSouthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbFound)
                    .addComponent(jbAdd)
                    .addComponent(jlVersion2))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jpSouth, java.awt.BorderLayout.PAGE_END);

        jpCenter.setBackground(new java.awt.Color(255, 255, 255));
        jpCenter.setPreferredSize(new java.awt.Dimension(280, 330));

        javax.swing.tree.DefaultMutableTreeNode treeNode1 = new javax.swing.tree.DefaultMutableTreeNode("联系人");
        jTree.setModel(new javax.swing.tree.DefaultTreeModel(treeNode1));
        manage.initTree(jTree, treeNode1);
    jTree.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            jTreeMouseClicked(evt);
        }
    });
    jScrollPane1.setViewportView(jTree);

    javax.swing.GroupLayout jpCenterLayout = new javax.swing.GroupLayout(jpCenter);
    jpCenter.setLayout(jpCenterLayout);
    jpCenterLayout.setHorizontalGroup(
        jpCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 277, Short.MAX_VALUE)
    );
    jpCenterLayout.setVerticalGroup(
        jpCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 340, Short.MAX_VALUE)
    );

    getContentPane().add(jpCenter, java.awt.BorderLayout.CENTER);

    pack();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String item = e.getActionCommand();
        if (item.equals("聊天")) {
            Talk talk1 = new Talk(mainName, temp);
        } else if (item.equals("资料")) {
            Info info1 = new Info(manage.seekPerson(temp), false);
        } else if (item.equals("编辑")) {
            Info info1 = new Info(manage.seekPerson(temp), true);
        } else if (item.equals("删除")) {
            int select = JOptionPane.showConfirmDialog(rootPane, "确认删除该联系人？");
            if (select == 0) {
                boolean result = manage.remove(temp);
                if (result) {
                    JOptionPane.showMessageDialog(rootPane, "删除成功！");
                    Main main = new Main(mainName);
                    this.dispose();
                } else {
                    JOptionPane.showMessageDialog(rootPane, "抱歉，该联系人未成功删除！", "错误", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
    
    private void jbAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbAddActionPerformed
        Info info2 = new Info(this, mainName);
    }

    private void jbFoundActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbFoundActionPerformed
        String name = JOptionPane.showInputDialog(rootPane, "请输入要查询的联系人姓名：");
        p = manage.seekPerson(name);
        if (p.getName().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "抱歉，您查找的联系人不存在！", "错误", JOptionPane.ERROR_MESSAGE);
        } else {
            Info info3 = new Info(p, false);
        }
    }

    private void jTreeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTreeMouseClicked
        int x = evt.getX();
        int y = evt.getY();
        int selRow = jTree.getRowForLocation(x, y);
        TreePath tp = jTree.getSelectionPath();
        if (selRow != -1) {
            if (evt.getButton() == 3 && evt.getClickCount() == 1) {
                DefaultMutableTreeNode perNode1 = (DefaultMutableTreeNode) tp.getLastPathComponent();
                temp = perNode1.toString();
                if (!manage.photo(temp).equals("")) {
                    menu.show(jTree, x, y);
                }
            } else if (evt.getButton() == 1 && evt.getClickCount() == 2) {
                DefaultMutableTreeNode perNode2 = (DefaultMutableTreeNode) tp.getLastPathComponent();
                temp = perNode2.toString();
                if (!manage.photo(temp).equals("")) {
                    Talk talk2 = new Talk(mainName, temp);
                }
            }
        }

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception e) {
        }

        java.awt.EventQueue.invokeLater(new Runnable() {

            @Override
            public void run() {
                new Main().setVisible(true);
            }
        });
    }
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTree jTree;
    private javax.swing.JButton jbAdd;
    private javax.swing.JButton jbFound;
    private javax.swing.JLabel jlPhoto;
    private javax.swing.JLabel jlTitle;
    private javax.swing.JLabel jlVersion1;
    private javax.swing.JLabel jlVersion2;
    private javax.swing.JLabel jlWelcome;
    private javax.swing.JPanel jpCenter;
    private javax.swing.JPanel jpNorth;
    private javax.swing.JPanel jpSouth;
}