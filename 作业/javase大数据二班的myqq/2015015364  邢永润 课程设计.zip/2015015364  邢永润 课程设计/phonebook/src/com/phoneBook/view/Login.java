package com.phoneBook.view;

import com.phoneBook.control.Management;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;


public class Login extends javax.swing.JFrame {

    JFileChooser jfcPic = new JFileChooser("D://U1Project");
    Management manage = new Management();
    
    public Login() {
        initComponents();
        this.setTitle("登录");
        this.setResizable(false);
        this.setVisible(true);
        this.setBounds(400, 150, 406, 313);
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        jpNorth = new javax.swing.JPanel();
        jlTitle = new javax.swing.JLabel();
        jlVersion1 = new javax.swing.JLabel();
        jpSouth = new javax.swing.JPanel();
        jlVersion2 = new javax.swing.JLabel();
        jbLogin = new javax.swing.JButton();
        jbSet = new javax.swing.JButton();
        jpCenter = new javax.swing.JPanel();
        jlPicture = new javax.swing.JLabel();
        jlName = new javax.swing.JLabel();
        jlPassword = new javax.swing.JLabel();
        jtfName = new javax.swing.JTextField();
        jlRegister = new javax.swing.JLabel();
        jlSetpwd = new javax.swing.JLabel();
        jpfPassword = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jpNorth.setBackground(new java.awt.Color(51, 153, 255));
        jpNorth.setPreferredSize(new java.awt.Dimension(390, 130));

        jlTitle.setFont(new java.awt.Font("微软雅黑", 1, 36));
        jlTitle.setForeground(new java.awt.Color(255, 255, 255));
        jlTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlTitle.setText("QQ  2012");

        jlVersion1.setFont(new java.awt.Font("微软雅黑", 1, 14));
        jlVersion1.setForeground(new java.awt.Color(255, 255, 255));
        jlVersion1.setText("Version 2.0");

        javax.swing.GroupLayout jpNorthLayout = new javax.swing.GroupLayout(jpNorth);
        jpNorth.setLayout(jpNorthLayout);
        jpNorthLayout.setHorizontalGroup(
            jpNorthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpNorthLayout.createSequentialGroup()
                .addGroup(jpNorthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpNorthLayout.createSequentialGroup()
                        .addGap(108, 108, 108)
                        .addComponent(jlTitle))
                    .addComponent(jlVersion1))
                .addContainerGap(110, Short.MAX_VALUE))
        );
        jpNorthLayout.setVerticalGroup(
            jpNorthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpNorthLayout.createSequentialGroup()
                .addComponent(jlVersion1)
                .addGap(16, 16, 16)
                .addComponent(jlTitle)
                .addContainerGap(46, Short.MAX_VALUE))
        );

        getContentPane().add(jpNorth, java.awt.BorderLayout.PAGE_START);

        jpSouth.setBackground(new java.awt.Color(204, 204, 255));
        jpSouth.setPreferredSize(new java.awt.Dimension(390, 25));

        jlVersion2.setFont(new java.awt.Font("微软雅黑", 1, 14));
        jlVersion2.setForeground(new java.awt.Color(255, 255, 255));
        jlVersion2.setText("Version 2.0");

        jbLogin.setBackground(new java.awt.Color(204, 204, 204));
        jbLogin.setFont(new java.awt.Font("微软雅黑", 0, 12));
        jbLogin.setText("登 录");
        jbLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbLoginActionPerformed(evt);
            }
        });

        jbSet.setBackground(new java.awt.Color(204, 204, 204));
        jbSet.setFont(new java.awt.Font("微软雅黑", 0, 12));
        jbSet.setText("设 置");
        jbSet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbSetActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jpSouthLayout = new javax.swing.GroupLayout(jpSouth);
        jpSouth.setLayout(jpSouthLayout);
        jpSouthLayout.setHorizontalGroup(
            jpSouthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpSouthLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jbLogin)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jbSet)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 155, Short.MAX_VALUE)
                .addComponent(jlVersion2)
                .addContainerGap())
        );
        jpSouthLayout.setVerticalGroup(
            jpSouthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpSouthLayout.createSequentialGroup()
                .addGroup(jpSouthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlVersion2)
                    .addComponent(jbLogin)
                    .addComponent(jbSet))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jpSouth, java.awt.BorderLayout.PAGE_END);

        jpCenter.setBackground(new java.awt.Color(255, 255, 255));
        jpCenter.setPreferredSize(new java.awt.Dimension(390, 120));

        jlPicture.setText(null);
        jlPicture.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlPicture.setIcon(new ImageIcon("D://课件//照片视频//U1Project//QQpicture.jpg"));

        jlName.setFont(new java.awt.Font("微软雅黑", 1, 18));
        jlName.setForeground(new java.awt.Color(51, 153, 255));
        jlName.setText("用户名：");

        jlPassword.setFont(new java.awt.Font("微软雅黑", 1, 18));
        jlPassword.setForeground(new java.awt.Color(51, 153, 255));
        jlPassword.setText("密    码：");

        jtfName.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N

        jlRegister.setFont(new java.awt.Font("微软雅黑", 0, 14));
        jlRegister.setForeground(new java.awt.Color(51, 153, 255));
        jlRegister.setText("注册账号");
        jlRegister.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jlRegister.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlRegisterMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jlRegisterMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jlRegisterMouseExited(evt);
            }
        });

        jlSetpwd.setFont(new java.awt.Font("微软雅黑", 0, 14));
        jlSetpwd.setForeground(new java.awt.Color(51, 153, 255));
        jlSetpwd.setText("设置密码");
        jlSetpwd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlSetpwdMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jlSetpwdMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jlSetpwdMouseExited(evt);
            }
        });

        jpfPassword.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N

        javax.swing.GroupLayout jpCenterLayout = new javax.swing.GroupLayout(jpCenter);
        jpCenter.setLayout(jpCenterLayout);
        jpCenterLayout.setHorizontalGroup(
            jpCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpCenterLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlPicture, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jpCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jlName)
                    .addComponent(jlPassword))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpfPassword, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 112, Short.MAX_VALUE)
                    .addComponent(jtfName, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 112, Short.MAX_VALUE))
                .addGap(10, 10, 10)
                .addGroup(jpCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jlRegister, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jlSetpwd, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );
        jpCenterLayout.setVerticalGroup(
            jpCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpCenterLayout.createSequentialGroup()
                .addGroup(jpCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpCenterLayout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(jpCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jlRegister)
                            .addComponent(jlName)
                            .addComponent(jtfName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jpCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jpfPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jpCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jlSetpwd)
                                .addComponent(jlPassword))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpCenterLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jlPicture, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)))
                .addContainerGap())
        );

        getContentPane().add(jpCenter, java.awt.BorderLayout.CENTER);

        pack();
    }

    private void jbLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbLoginActionPerformed
        String name = jtfName.getText();
        if (name.equals("")) {
            JOptionPane.showMessageDialog(rootPane, "请输入用户名！");
        } else if (jpfPassword.getText().equals("")) {
          
            JOptionPane.showMessageDialog(rootPane, "请输入密码！");
        } else {
            boolean result = manage.hasPerson(name);
            if (result) {
                Main main = new Main(name);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(rootPane, "登录失败，该用户名未注册！", "错误", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void jbSetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbSetActionPerformed
        JOptionPane.showMessageDialog(rootPane, "登录界面图像设置");
        jfcPic.addChoosableFileFilter(new FileNameExtensionFilter("GIF图片文件", "gif", "GIF"));
        jfcPic.addChoosableFileFilter(new FileNameExtensionFilter("PNG图片文件", "png", "PNG"));
        jfcPic.addChoosableFileFilter(new FileNameExtensionFilter("JPEG图片文件", "jpg", "jpeg"));
        jfcPic.showOpenDialog(this);
        if (jfcPic.getSelectedFile() != null) {
            jlPicture.setIcon(new ImageIcon("" + jfcPic.getSelectedFile()));
        }
    }

    private void jlRegisterMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlRegisterMouseClicked
        Info info = new Info();
    }

    private void jlSetpwdMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlSetpwdMouseClicked
        JOptionPane.showInputDialog(rootPane, "请输入新设置的密码：");
    }

    private void jlRegisterMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlRegisterMouseEntered
        jlRegister.setFont(new java.awt.Font("微软雅黑", 1, 14));
        jlRegister.setForeground(new java.awt.Color(153, 0, 153));
    }

    private void jlRegisterMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlRegisterMouseExited
        jlRegister.setFont(new java.awt.Font("微软雅黑", 0, 14));
        jlRegister.setForeground(new java.awt.Color(51, 153, 255));
    }

    private void jlSetpwdMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlSetpwdMouseEntered
        jlSetpwd.setFont(new java.awt.Font("微软雅黑", 1, 14));
        jlSetpwd.setForeground(new java.awt.Color(153, 0, 153));
    }

    private void jlSetpwdMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlSetpwdMouseExited
        jlSetpwd.setFont(new java.awt.Font("微软雅黑", 0, 14));
        jlSetpwd.setForeground(new java.awt.Color(51, 153, 255));
    }


    public static void main(String args[]) {
        
        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception e) {
        }
        
        java.awt.EventQueue.invokeLater(new Runnable() {

            @Override
            public void run() {
                new Login().setVisible(true);
            }
        });
    }
    private javax.swing.JButton jbLogin;
    private javax.swing.JButton jbSet;
    private javax.swing.JLabel jlName;
    private javax.swing.JLabel jlPassword;
    private javax.swing.JLabel jlPicture;
    private javax.swing.JLabel jlRegister;
    private javax.swing.JLabel jlSetpwd;
    private javax.swing.JLabel jlTitle;
    private javax.swing.JLabel jlVersion1;
    private javax.swing.JLabel jlVersion2;
    private javax.swing.JPanel jpCenter;
    private javax.swing.JPanel jpNorth;
    private javax.swing.JPanel jpSouth;
    private javax.swing.JPasswordField jpfPassword;
    private javax.swing.JTextField jtfName;
}
