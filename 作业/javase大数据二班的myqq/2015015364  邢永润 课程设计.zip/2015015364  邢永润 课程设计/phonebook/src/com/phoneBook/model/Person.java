package com.phoneBook.model;

public class Person implements Comparable<Person>{

    private String name;
    private String sex;
    private String birthday;
    private String tele;
    private String cell;
    private String email;
    private String group;
    private String photo;

    public Person() {
        this.name = "";
        this.photo = "";
    }

    public Person(String name, String sex, String birthday, String group, String tele,
            String cell, String email, String photo) {
        this.name = name;
        this.sex = sex;
        this.birthday = birthday;
        this.photo = photo;
        this.tele = tele;
        this.cell = cell;
        this.email = email;
        this.group = group;
    }

    public String getBirthday() {return birthday;}

    public String getCell() {return cell;}

    public String getEmail() {return email;}

    public String getName() {return name;}

    public String getSex() {return sex;}

    public String getTele() {return tele;}

    public String getGroup() {return group;}

    public String getPhoto() {return photo;}

    public void setPerson(Person p) {
        this.name = p.getName();
        this.sex = p.getSex();
        this.birthday = p.getBirthday();
        this.tele = p.getTele();
        this.cell = p.getCell();
        this.email = p.getEmail();
        this.group = p.getGroup();
        this.photo = p.getPhoto();
    }

    @Override
    public int compareTo(Person person) {
        return this.name.compareTo(person.getName());
    }

    @Override
    public boolean equals(Object person) {
        return person instanceof Person ? compareTo((Person) person) == 0
                : false;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 79 * hash + (this.name != null ? this.name.hashCode() : 0);
        return hash;
    }
}
