package com.myqq.user.view;
import java.util.Date;

import com.myqq.entity.User;
import com.myqq.user.service.UserServiceImpl;

public class Test {
	public static void main(String[] args) {
		User u=new User();
		
		u.setNickName("2318461321");
		u.setPassword("123456789");
     	u.setGender("");
		u.setRegistTime(new Date());
		u.setIntroduce("");
    	u.setIp("127.0.0.1");
		
		UserServiceImpl userServiceImpl=new UserServiceImpl();
		boolean b=userServiceImpl.regist(u);
		if(b)
			System.out.println("注册成功");
		
		UserServiceImpl userServiceImpl1=new UserServiceImpl();
		User u1=userServiceImpl1.login(1, "123");
		System.out.println(u1.getNickName());
	}
	}




