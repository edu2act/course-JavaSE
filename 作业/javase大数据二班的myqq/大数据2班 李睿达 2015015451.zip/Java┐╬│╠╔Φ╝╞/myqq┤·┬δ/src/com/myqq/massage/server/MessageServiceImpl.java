package com.myqq.massage.server;

import com.myqq.entity.Message;
import com.myqq.massage.dao.MessageDaoImpl;

public class MessageServiceImpl {
	
	public int sendMessage(Message message){
		MessageDaoImpl messageDaoImpl=new MessageDaoImpl();
		return messageDaoImpl.saveMessage(message);
	}
}
