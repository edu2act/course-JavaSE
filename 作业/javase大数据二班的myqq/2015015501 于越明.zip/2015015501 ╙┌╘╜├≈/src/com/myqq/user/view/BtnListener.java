package com.myqq.user.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.myqq.entity.Users;
import com.myqq.user.service.UserServiceimpl;

public class BtnListener implements ActionListener{

	LoginFream loginFrame;
	public BtnListener(LoginFream loginFrame){
		this.loginFrame=loginFrame;
	}

	public void actionPerformed(ActionEvent e) {
		String qqNum=loginFrame.txtQqNum.getText();
		String password=new String(loginFrame.txtPassword.getPassword());
		UserServiceimpl userServiceImpl=new UserServiceimpl();
		Users u=userServiceImpl.login(Integer.parseInt(qqNum), password);
		if(u!=null){
			MainFrame mf=new MainFrame(u);
			loginFrame.dispose();
			loginFrame=null;
		}
	}


}
