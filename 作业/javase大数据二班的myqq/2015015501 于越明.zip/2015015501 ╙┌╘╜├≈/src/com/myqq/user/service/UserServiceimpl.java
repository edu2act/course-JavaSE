package com.myqq.user.service;

import java.util.List;

import com.myqq.entity.Users;
import com.myqq.user.dao.UserDaoImpl;
import com.myqq.util.IpUtil;

public class UserServiceimpl {
	
	public static boolean regist(Users u){
		UserDaoImpl userDaoImpl = new UserDaoImpl();
		return userDaoImpl.saveUser(u);
	}
	public Users login(int qqnum,String password){
		UserDaoImpl userDaoImpl = new UserDaoImpl();
		Users u = userDaoImpl.findByQqNumAndPassword(qqnum, password);
		if(u!=null){
			String ip=IpUtil.getLocalHostAddress();
			userDaoImpl.updateIp(qqnum, ip);
			u.setIp(ip);
			return u;
		}else{
			return null;
		}
	}
	public List<Users> listFriends(int qqNum){
		UserDaoImpl userDaoImpl = new UserDaoImpl();
		return userDaoImpl.findFriendByQqNum(qqNum);
	} 
	
	public Users listByQqNum(int qqNum){
		UserDaoImpl userDaoImpl=new UserDaoImpl();
		return userDaoImpl.getUser(qqNum);
	}
}
