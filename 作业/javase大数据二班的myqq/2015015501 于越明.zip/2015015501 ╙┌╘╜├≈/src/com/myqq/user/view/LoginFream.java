package com.myqq.user.view;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginFream extends JFrame{
	JLabel lblQqnum;//登录标签
	JLabel lblPassword;//密码标签
	public JTextField txtQqNum;//qq号码输入区
	public JPasswordField txtPassword;//qq密码输入区
	JButton btnLogin;//登录按钮
	JButton btnCancle;//取消按钮
	
	public LoginFream(){
		lblQqnum = new JLabel("QQ号：");
		lblPassword = new JLabel("密码：");
		txtQqNum = new JTextField();
		txtPassword = new JPasswordField();
		btnLogin = new JButton("登录");
		btnCancle = new JButton("取消");
		
		this.getContentPane().setLayout(null);//不使用系统设置的面板
		this.getContentPane().add(lblQqnum);
		lblQqnum.setBounds(25,25,160,25);//以窗体左上角为原点
		this.getContentPane().add(lblPassword);
		lblPassword.setBounds(25,55,160,25);
		this.getContentPane().add(txtQqNum);
		txtQqNum.setBounds(120,20,130,25);
		this.getContentPane().add(txtPassword);
		txtPassword.setBounds(120,55,130,25);
		this.getContentPane().add(btnLogin);
		btnLogin.setBounds(60,90,70,25);
		this.getContentPane().add(btnCancle);
		btnCancle.setBounds(130,90,70,25);
		
		btnLogin.addActionListener(new BtnListener(this));
		
		this.setTitle("QQ登录");
		this.setSize(300,200);
		this.setVisible(true);
		
//		this.setDefaultCloseOperation(EXIT_ON_CLOSE);//当窗体关闭时程序也终止
	}
}
