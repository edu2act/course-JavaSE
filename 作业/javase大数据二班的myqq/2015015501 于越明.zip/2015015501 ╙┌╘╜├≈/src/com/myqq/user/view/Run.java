package com.myqq.user.view;

import java.sql.Date;

import com.myqq.entity.Users;
import com.myqq.user.dao.UserDaoImpl;
import com.myqq.user.service.UserServiceimpl;

public class Run {
	public static void main(String[] args) {
	
		LoginFream loginFrame=new LoginFream();
		
	}
}
