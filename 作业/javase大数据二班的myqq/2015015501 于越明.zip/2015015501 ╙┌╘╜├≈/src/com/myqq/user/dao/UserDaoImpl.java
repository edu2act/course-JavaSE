package com.myqq.user.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.myqq.entity.Users;
import com.myqq.util.ConnectionUtil;

public class UserDaoImpl {
	public Users getUser(int qqNum){
		try{
			//获取数据库连接
			Connection con=ConnectionUtil.getCon();
			//创建statement
			PreparedStatement pstm=con.prepareStatement(
					"select * from users u where u.qqnum=?");
			//设置参数，针对？占位符
			pstm.setInt(1, qqNum);
			//执行sql语句
			ResultSet rs=pstm.executeQuery();
			Users u=null;
			while(rs.next()){
				u=new Users();
				u.setQqnum(rs.getInt(1));
				u.setNickName(rs.getString(2));
				u.setPassWord(rs.getString(3));
				u.setRegitstTime(rs.getDate(4));
				u.setGender(rs.getString(5));
				u.setIntroduce(rs.getString(6));
				u.setIp(rs.getString(7));
			}
			//关闭连接
			ConnectionUtil.closeCon(rs, pstm, con);
			return u;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	//新增用户信息
	public static boolean saveUser(Users u){//习惯命名：保存或者新增用save、add、insert
		try{
			//获取数据库连接
			Connection con=ConnectionUtil.getCon();
			//创建statement
			PreparedStatement pstm=con.prepareStatement(
					"insert into users(nickName,password,registTime,"
					+ "gender,introduce,ip) values(?,?,?,?,?,?)",
					Statement.RETURN_GENERATED_KEYS);
			//设置参数，针对？占位符
			pstm.setString(1, u.getNickName());
			pstm.setString(2, u.getPassWord());
			pstm.setString(3, u.getRegitstTime().toLocaleString());
			pstm.setString(4, u.getGender());
			pstm.setString(5, u.getIntroduce());
			pstm.setString(6, u.getIp());
			//执行sql语句
			int count=pstm.executeUpdate();
			ResultSet rs=pstm.getGeneratedKeys();
			if(rs.next())
				System.out.println(rs.getInt(1));
			//关闭连接
			ConnectionUtil.closeCon(rs, pstm, con);
			if(count>0)
				return true;
			else
				return false;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
	
	//按用户qq号和密码查询用户
	public static Users findByQqNumAndPassword(int num,String password){
		try {
			//2、获取数据库连接
			Connection con = ConnectionUtil.getCon();
			//3、创建statement
			PreparedStatement pstm = con.prepareStatement("select * from users u where u.qqnum=? and u.password=?");
			//设置参数，针对？占位符
			pstm.setInt(1, num);//索引从1开始
			pstm.setString(2,password );
			//执行sql语句
			Users u = null;
			ResultSet rs = pstm.executeQuery();//结果集，为二维表形式，是数据库表在内存中的映射，结果集默认只进（游标只向下一个移动）只读，但可修改
			while(rs.next()){
				u=new Users();
				u.setQqnum(rs.getInt(1));//取出字段
				u.setNickName(rs.getString(2));
				u.setPassWord(rs.getString(3));
				u.setRegitstTime(rs.getDate(4));
				u.setGender(rs.getString(5));
				u.setIntroduce(rs.getString(6));
				u.setIp(rs.getString(7));
			}
			//4.关闭连接
			ConnectionUtil.closeCon(rs,pstm,con);
			return u;
		} catch (Exception e) {
			return null;
		}
	}
	
	//通过QQ号查询用户
	public static List<Users> findFriendByQqNum(int qqNum){
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;//结果集主要用于查询
		
		try {
			List<Users> list = new ArrayList<Users>();
			con = ConnectionUtil.getCon();
			pstm = con.prepareStatement("select * from users u where u.qqnum<>?");
			pstm.setInt(1, qqNum);
			rs=pstm.executeQuery();
			while(rs.next()){
				Users u=new Users();
				u.setQqnum(rs.getInt(1));//取出字段,填到qqnum里
				u.setNickName(rs.getString(2));
				u.setPassWord(rs.getString(3));
				u.setRegitstTime(rs.getDate(4));
				u.setGender(rs.getString(5));
				u.setIntroduce(rs.getString(6));
				u.setIp(rs.getString(7));
				list.add(u);
			}
			return list;
		} catch (Exception e) {
			return null;
		}finally{
			ConnectionUtil.closeCon(rs, pstm, con);
		}
	}
	
	//更改用户密码
	public boolean updatePassword(int qqnum,String password){
		Connection con = null;
		PreparedStatement pstm = null;
		
		try {
			List<Users> list = new ArrayList<Users>();
			con = ConnectionUtil.getCon();
			pstm = con.prepareStatement("update users set password =? where qqNum=?");
			pstm.setString(1, password);
			pstm.setInt(2, qqnum);
			int count = pstm.executeUpdate();
			if(count>0){
				return true;
			}else{
				return false;
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return false;
		}finally{
			ConnectionUtil.closeCon(null, pstm, con);
		}
	}

	//更改IP
	public void updateIp(int qqNum,String ip){
		Connection con = null;
		PreparedStatement pstm = null;
		
		try {
			con = ConnectionUtil.getCon();
			pstm = con.prepareStatement("update users set ip =? where qqNum=?");
			pstm.setString(1, ip);
			pstm.setInt(2, qqNum);
			int count = pstm.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally{
			ConnectionUtil.closeCon(null, pstm, con);
		}
	}
}
