package com.myqq.message;

import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.Socket;

import com.myqq.entity.Message;
import com.myqq.util.SerializableUtil;

public class MassageSendThread implements Runnable{
	
	Message msg;
	String ip;
	public MassageSendThread(Message msg,String ip) {
		// TODO Auto-generated constructor stub
		this.msg=msg;
		this.ip=ip;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			Socket socket = new Socket(ip,8888);
			OutputStream os=socket.getOutputStream();
			try {
				os.write(SerializableUtil.serializableMessage(msg));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			os.close();
			socket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
