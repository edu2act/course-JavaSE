package my;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author IBM
 */
import javax.swing.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;

public class UserServerClient {
    JFrame frame;
    Command command;
    Socket socket;
    PrintWriter os;
    BufferedReader is;
    JTextArea ta;
    JScrollPane sp;

    public static void main(String args[]){
        new UserServerClient();
    }

    public UserServerClient(){
        frame=new JFrame("User Server Client");
        frame.setSize(450,500);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //frame.setLayout(new GridLayout(0,1));
        command=new Command();
        frame.getContentPane().add(command,"South");
        ta=new JTextArea();
        sp=new JScrollPane(ta);
        frame.getContentPane().add(sp,"Center");
        frame.validate();

        try{
            socket=new Socket("127.0.0.1",1999);
            os=new PrintWriter(socket.getOutputStream());
            is=new BufferedReader( new InputStreamReader(socket.getInputStream()));
            }catch(IOException e){
                System.out.println("Socket constructor Error:"+e);
            }
    }



class Command extends JPanel implements ActionListener{
    JLabel label1,label2;
    JTextField text1,text2;

    public Command(){
        label1=new JLabel("�û���");
        label2=new JLabel("����");
        text1=new JTextField(10);
        text2=new JTextField(10);
        add(label1);
        add(text1);
        add(label2);
        add(text2);

        String[] choice={"ע��","��¼","�뿪","�����û��б�"};
        JComboBox bo=new JComboBox(choice);
        bo.setEditable(false);
        bo.addActionListener(this);
        add(bo);
    }

    public void actionPerformed(ActionEvent e){
        String request="";
        JComboBox cb=(JComboBox)e.getSource();
        String selection=(String)cb.getSelectedItem();
        if (selection.equals("�����û��б�")){
            request="account list";
        }else if(selection.equals("ע��")){
            request="register:"+text1.getText()+":"+text2.getText();
        }else if(selection.equals("��¼")){
            request="login:"+text1.getText()+":"+text2.getText();
        }else if(selection.equals("�뿪")){
            request="logout:"+text1.getText();
        }
        System.out.println(request);
        os.println(request);
        os.flush();
        String response="init";
        try {
            response=is.readLine();
        }catch(IOException ie){
                System.out.println("get from server Error:"+ie);
        }
        ta.append(response+"\n");
    }

}
}