package my;
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import java.io.IOException;
import java.io.InputStreamReader;
//import java.io.PrintWriter;

///import javax.swing.JTextArea;

public class QQ {
protected static final InputStreamReader InputStreamReader = null;

public static void main(String args[]){
	JScrollPane myJScrollPane,myJScrollPane1;
	JLabel myJlabel,myJlabel1;
	//JFrame myJFrame;
	Frame f=new Frame("QQ");
	f.setLayout(new GridLayout(2,2));
	Button bw = new Button("����");
	Button bb = new Button("�˳�");
	JLabel a1=new JLabel("To");
	JComboBox	clist=new JComboBox(); 
	clist.addItem("������"); 
	clist.addItem("01"); 
	clist.addItem("02"); 
	clist.addItem("03"); 
	clist.addItem("04"); 
	clist.addItem("05"); 
	clist.addItem("06"); 
	Panel p1 = new Panel();
	Panel p2 = new Panel();
	Panel p3 = new Panel();
	Panel p4 = new Panel();
	f.add(p1,"1");
	f.add(p2,"2");
	f.add(p3,"3");
	f.add(p4,"4");
	Button b1 = new Button("����");
	Button b2 = new Button("����");
	Button b3 = new Button("�����¼");
	Button b4 = new Button("�����б�");
b1.setBounds(0, 400, 300, 100);
	p3.add(b1);
	b2.setBounds(100, 400, 300, 100);
	p3.add(b2);
	b4.setBounds(200, 400, 300, 100);
	p3.add(b4);
	b2.setBounds(300, 400, 300, 100);
	p3.add(b3);
	Icon mypic_icon=new ImageIcon("E:/33.jpg");
	myJlabel= new JLabel(mypic_icon);
	   myJScrollPane=new JScrollPane(myJlabel);
	   myJScrollPane.setLayout(new ScrollPaneLayout());
	 p2.add(myJScrollPane);
final TextArea t = new TextArea("ئ�� ",15,32);
final TextArea tr = new TextArea(" ",20,30);
p3.setBackground(Color.gray);
p3.add(t);

p3.add(a1);
p3.add(clist);
b1.addActionListener(new ActionListener(){
	public void actionPerformed(final ActionEvent arg0){
	Choice ColorChooser=new Choice();
	ColorChooser.add("����");
	ColorChooser.add("����");	
	ColorChooser.add("����");
	ColorChooser.setBounds(0, 400, 300, 100);
	//add(ColorChooser);
	}
});
///////////////////����///////////////////////////




//////////////////////////////////////////////////
bb.addActionListener(new ActionListener(){
		public void actionPerformed(final ActionEvent arg0){
			System.exit(0);
		}
	});
p1.add(tr);
tr.setEditable(false);
bw.addActionListener(new ActionListener(){
	public void actionPerformed(final ActionEvent arg0){
String s=t.getText();
tr.append(s+'\n');
t.setText(" ");
	}
});
Icon mypic_icon1=new ImageIcon("E:/22.jpg");
myJlabel1= new JLabel(mypic_icon1);
   myJScrollPane1=new JScrollPane(myJlabel1);
   myJScrollPane1.setLayout(new ScrollPaneLayout());
 p4.add(myJScrollPane1);	
	p3.add(bw);
	p3.add(bb);
	f.pack();
	f.setResizable(false);//���ô˴��岻�����û�������С
f.setSize(500,700);
f.setVisible(true);	
}
}
