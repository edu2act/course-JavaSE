package com.myQQ.user.view;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ForgetFrame extends JFrame{
	String pass;
	JLabel jl;
	public ForgetFrame(String pass){
		this.pass = pass;
		this.getContentPane().setLayout(null);
		jl = new JLabel("你的密码为：" + "\n" + pass);
		this.getContentPane().add(jl);
		jl.setBounds(50, 30, 100, 100);
		this.setSize(400,200);
		this.setVisible(true);
	}
	
	
}
