package com.myQQ.user.view;

import java.sql.Date;

import com.myQQ.entity.User;
import com.myQQ.user.dao.UserDaoImpl;

public class Run {

	public static void main(String[] args) {
		LoginFrame loginFrame=new LoginFrame();
//		new UserDaoImpl().saveUser(new User(0,"siji","0",new Date(System.currentTimeMillis()),"男","强无敌","0"));
//		new UserDaoImpl().saveUser(new User(2,"老毒物","2",new Date(System.currentTimeMillis()),"男","老毒物","2"));
//		new UserDaoImpl().saveUser(new User(1,"伸伸","1",new Date(System.currentTimeMillis()),"男","欧皇","1"));
	}
}
