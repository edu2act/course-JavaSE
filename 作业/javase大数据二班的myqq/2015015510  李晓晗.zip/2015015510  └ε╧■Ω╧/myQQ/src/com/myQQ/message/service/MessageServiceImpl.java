package com.myQQ.message.service;

import com.myQQ.entity.Message;
import com.myQQ.message.dao.MessageDaoImpl;

public class MessageServiceImpl {
	
	public int sendMessage(Message message){
		
		
		MessageDaoImpl messageDaoImpl=new MessageDaoImpl();
		return messageDaoImpl.saveMessage(message);
	}
}
