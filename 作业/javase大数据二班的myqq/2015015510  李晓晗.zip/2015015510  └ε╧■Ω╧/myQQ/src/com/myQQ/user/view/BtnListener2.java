package com.myQQ.user.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.myQQ.entity.User;
import com.myQQ.util.ConnectionUtil;

public class BtnListener2 implements ActionListener{
	private LoginFrame loginFrame;
	public BtnListener2(LoginFrame loginFrame) {
		// TODO Auto-generated constructor stub
		this.loginFrame = loginFrame;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		try{
			//获取数据库连接
			Connection con=ConnectionUtil.getCon();
			//创建statement
			PreparedStatement pstm=con.prepareStatement(
					"select password from users u where u.qqnum=?");
			//设置参数，针对？占位符
			pstm.setString(1, loginFrame.txtQqNum.getText());
			//执行sql语句
			ResultSet rs=pstm.executeQuery();
			if(rs.next()){
				new ForgetFrame(rs.getString(1));
			}
			//关闭连接
			ConnectionUtil.closeCon(rs, pstm, con);
		}catch(Exception e1){
			e1.printStackTrace();
		}	
	}
	
	
}
