package com.myQQ.user.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginFrame extends JFrame {
	
	JLabel lblQqNum;
	JLabel lblPassword;
	JTextField txtQqNum;
	JPasswordField txtPassword;
	JButton btnLogin;
	JButton btnCancel;
	JButton btnForget;
	
	public LoginFrame(){
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		lblQqNum=new JLabel("QQ号：");
		lblPassword=new JLabel("密码：");
		txtQqNum=new JTextField();
		txtPassword=new JPasswordField();
		btnLogin=new JButton("登录");
		btnCancel=new JButton("取消");
		btnForget=new JButton("忘记密码？");
		
		this.getContentPane().setLayout(null);
		this.getContentPane().add(lblQqNum);
		lblQqNum.setBounds(20, 20, 80, 20);
		this.getContentPane().add(lblPassword);
		lblPassword.setBounds(20, 50, 80, 20);
		this.getContentPane().add(txtQqNum);
		txtQqNum.setBounds(80, 20, 140, 20);
		this.getContentPane().add(txtPassword);
		txtPassword.setBounds(80, 50, 140, 20);
		this.getContentPane().add(btnLogin);
		btnLogin.setBounds(10, 100, 80, 20);
		this.getContentPane().add(btnCancel);
		btnCancel.setBounds(90, 100, 80, 20);
		this.getContentPane().add(btnForget);
		btnForget.setBounds(170, 100, 120, 20);
		btnLogin.addActionListener(new BtnListener(this));
		btnCancel.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
					System.exit(0);//程序退出，关闭掉Frame
			}
		});
		btnForget.addActionListener(new BtnListener2(this));
		
		
		this.setTitle("QQ登录");
		this.setSize(300,200);
		this.setVisible(true);
	}

}
