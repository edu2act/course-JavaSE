package com.myqq.user.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.myqq.entity.Users;
import com.myqq.jtreetest.src.jtreetest.MainFrame;
import com.myqq.jtreetest.src.jtreetest.Test;
import com.myqq.user.service.UserServiceImpl;

public class BtnListener implements ActionListener{

	LoginFrame loginFrame;
	public BtnListener(LoginFrame loginFrame){
		this.loginFrame = loginFrame;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String qqNum = loginFrame.txtQQNum.getText();
		String Password = new String(loginFrame.txtPassword.getPassword());
		int qqnum = 0;
		try {
			qqnum = Integer.parseInt(qqNum);
		} catch (Exception e2) {
			// TODO: handle exception
			loginFrame.txtQQNum.setText("����дQQ��");
			loginFrame.txtQQNum.select(0,loginFrame.txtQQNum.getText().length());//ȫѡ
		}
		UserServiceImpl us = new UserServiceImpl();
		Users u = us.Userlogin(qqnum,Password);
		if(u!=null){
			MainFrame mainFrame=new MainFrame(qqnum);
			loginFrame.setVisible(false);
		}
	}
	
}
