package com.myqq.user.service;

import java.util.List;

import com.myqq.entity.Users;
import com.myqq.user.dao.UserDaoImpl;

public class UserServiceImpl {

	//ע��
	public boolean regist(Users user){
		UserDaoImpl userDaoImpl = new UserDaoImpl();
		return userDaoImpl.saveUser(user);
	}
	
	public Users Userlogin(int qqNum,String password){
		UserDaoImpl userDaoImpl = new UserDaoImpl();
		return userDaoImpl.findByQqNumAndPassword(qqNum, password);
	}
	
	public List<Users> findFriendByQqNum(int qqNum){
		UserDaoImpl userDaoImpl = new UserDaoImpl();
		return userDaoImpl.findFriendByQqNum(qqNum);
	} 
	
	
}
