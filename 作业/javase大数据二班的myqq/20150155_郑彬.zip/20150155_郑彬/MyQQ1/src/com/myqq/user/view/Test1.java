package com.myqq.user.view;

import com.myqq.entity.Users;

public class Test1 {

	public static void main(String[] args) {
		Users user = new Users();
		
		LoginFrame lf = new LoginFrame();
		
		
	}
}
