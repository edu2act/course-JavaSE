﻿package com.myqq.jtreetest.src.jtreetest;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeSelectionModel;

import com.myqq.entity.Users;
import com.myqq.user.service.UserServiceImpl;
import com.myqq.user.view.LoginFrame;

public class MainFrame extends JFrame {
	JScrollPane userListPanel=null;
	JTree usersTree=null;
	DefaultTreeModel treeModel=null;
	DefaultMutableTreeNode rootNode=null;
	public MainFrame(int qqNum) {
		rootNode = new DefaultMutableTreeNode("我的好友");  
		treeModel = new DefaultTreeModel(rootNode); 
		usersTree=new JTree(treeModel);
		usersTree.getSelectionModel().setSelectionMode 
	     (TreeSelectionModel.SINGLE_TREE_SELECTION);  
		usersTree.setShowsRootHandles(true);
		userListPanel=new JScrollPane(usersTree);
		//构造好友信息
		UserServiceImpl usi = new UserServiceImpl();
		List<Users> list = usi.findFriendByQqNum(qqNum);
		int length = list.size();
		String qqNickname = null;
		for(int i=0;i<length;i++){		
			if(list.get(i).getQqnum() == qqNum){
				qqNickname = list.get(i).getNickName();
				i++;
			}
			DefaultMutableTreeNode node=new DefaultMutableTreeNode("好友"+i+list.get(i).getNickName());
			rootNode.add(node);
		}
		usersTree.addMouseListener(new TreeMouseListener(usersTree));
		
		this.getContentPane().add(userListPanel);
		this.setSize(200, 500);
		this.setVisible(true);
		this.setTitle(qqNickname);
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
}
