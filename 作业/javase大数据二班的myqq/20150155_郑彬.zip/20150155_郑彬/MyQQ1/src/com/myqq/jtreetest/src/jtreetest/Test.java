﻿package com.myqq.jtreetest.src.jtreetest;

public class Test {

//	public static void main(String[] args) {
//		MainFrame mainFrame=new MainFrame();
//
//	}

}
