package com.myqq.user.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import com.myqq.jtreetest.src.jtreetest.Test;

public class LoginFrame extends JFrame{
	
	JLabel lblQqNum;
	JLabel lblPassword;
	
	JTextField txtQQNum;
	JPasswordField txtPassword;
	
	JButton btnLogin;
	JButton btnCancle;
	
	
	public LoginFrame(){
		lblQqNum = new JLabel("QQ��");
		lblPassword = new JLabel("QQ����");
		
		txtQQNum = new JTextField();
		txtPassword = new JPasswordField();
		
		btnLogin = new JButton("��¼");
		btnCancle = new JButton("�˳�");
		
		this.getContentPane().setLayout(null);
		this.getContentPane().add(lblQqNum);
		lblQqNum.setBounds(50, 20, 160, 25);
		this.getContentPane().add(lblPassword);
		lblPassword.setBounds(50, 55, 160, 25);
		this.getContentPane().add(txtQQNum);
		txtQQNum.setBounds(120, 20, 120, 25);
		this.getContentPane().add(txtPassword);
		txtPassword.setBounds(120, 55, 120, 25);
		this.getContentPane().add(btnLogin);
		btnLogin.setBounds(60, 90, 70, 25);
		this.getContentPane().add(btnCancle);
		btnCancle.setBounds(160, 90, 70, 25);
		btnLogin.addActionListener(new BtnListener(this));
		btnCancle.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				 System.exit(0);
			}
		});
		
		this.setTitle("��¼");
		this.setSize(300,200);
		this.setVisible(true);
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}
	
	
}
