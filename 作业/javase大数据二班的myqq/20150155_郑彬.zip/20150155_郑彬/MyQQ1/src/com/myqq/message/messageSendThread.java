package com.myqq.message;
import com.myqq.util.SerializableUtil;

import java.io.OutputStream;
import java.net.Socket;

import com.myqq.entity.Message;

public class messageSendThread implements Runnable{
	
	Message message;
	private String ip;
	public messageSendThread(Message msg,String ip) {
		this.message = msg;
		this.ip = ip;
	}

	public void run(){
		try {
			Socket socket = new Socket(ip,8888);
			OutputStream os = socket.getOutputStream();
			os.write((SerializableUtil.serializableMessage(message)));
			os.close();
			socket.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
