package com.myqq.user.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.myqq.entity.Users;

public class UserDaoImpl {
	private static final String URL = "jdbc:mysql://localhost:3306/myqq1";			
	private static final String USERNAME = "root";                       
	private static final String PASSWORD = "1017040120";
	
	
	public boolean saveUser(Users user){
		try {
			//1������������
			Class.forName("com.mysql.jdbc.Driver");
			//2����ȡ���ݿ�����
			Connection con = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			//3������statement
			PreparedStatement pstm = con.prepareStatement("insert into Users(nickName,password,registTime,gender,introduce,ip) values(?,?,?,?,?,?)");
			//���ò���
			pstm.setString(1, user.getNickName());
			pstm.setString(2, user.getPassword());
			pstm.setString(3, user.getRegitstTime().toLocaleString());
			pstm.setString(4, user.getGender());
			pstm.setString(5, user.getIntroduce());
			pstm.setString(6, user.getIp());
			
			int count = pstm.executeUpdate();
			ResultSet rs=pstm.getGeneratedKeys();
			if(rs.next()){
				System.out.println(rs.getInt(1));
			}
			pstm.close();
			con.close();
			if (count > 0) {
				return true;
			}else{
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public Users findByQqNumAndPassword(int qqNum,String password){
		try{
		//1������������
		Class.forName("com.mysql.jdbc.Driver");
		//2����ȡ���ݿ�����
		Connection con = DriverManager.getConnection(URL,USERNAME,PASSWORD);
		//3������statement
		PreparedStatement pstm = con.prepareStatement("select * from Users where qqnum = ? and password = ?");
		
		pstm.setInt(1,qqNum);
		pstm.setString(2,password);
		
		ResultSet rs = pstm.executeQuery();
		Users user = null;
		while(rs.next()){
			user = new Users();
			int qqnum = rs.getInt(1);
			user.setQqnum(qqnum);
			user.setNickName(rs.getString(2));
			user.setPassword(rs.getString(3));
			user.setRegitstTime(rs.getDate(4));
			user.setGender(rs.getString(5));
			user.setIntroduce(rs.getString(6));
			user.setIp(rs.getString(7));
		}
		
		rs.close();
		pstm.close();
		con.close();
		if (user!=null) {
			return user;
		}else{
			return null;
		}
	} catch (Exception e) {
		e.printStackTrace();
		return null;
	}
	}
	
	public List<Users> findFriendByQqNum(int qqnum){
		Connection con;
		PreparedStatement pstm;
		ResultSet rs;
		try {
			List<Users> list = new ArrayList<Users>();
			con = com.myqq.util.Connection.getCon();
			pstm = con.prepareStatement("select * from Users u where u.qqnum <> ?");
			pstm.setInt(1,qqnum);
			rs = pstm.executeQuery();
			while(rs.next()){
				Users user = new Users();
				int qqNum = rs.getInt(1);
				user.setQqnum(qqNum);
				user.setNickName(rs.getString(2));
				user.setPassword(rs.getString(3));
				user.setRegitstTime(rs.getDate(4));
				user.setGender(rs.getString(5));
				user.setIntroduce(rs.getString(6));
				user.setIp(rs.getString(7));
				list.add(user);
			}
			if (rs!=null) {
				rs.close();
			}
			if (pstm!=null) {
				pstm.close();
			}
			if (con!=null) {
				con.close();
			}
			
			return list;
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
	}
	
	public boolean updatePassword(String password,int qqnum){
		Connection con;
		PreparedStatement pstm;
		
		try {
			List<Users> list = new ArrayList<Users>();
			con = com.myqq.util.Connection.getCon();
			pstm = con.prepareStatement("update Users set password = ? where qqnum = ?");
			pstm.setString(1,password);
			pstm.setInt(2, qqnum);
		return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
}
