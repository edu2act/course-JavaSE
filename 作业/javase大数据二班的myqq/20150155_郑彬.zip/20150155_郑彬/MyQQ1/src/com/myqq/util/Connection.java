package com.myqq.util;

import java.sql.*;


public class Connection {
	private static final String URL = "jdbc:mysql://localhost:3306/myqq1";			
	private static final String USERNAME = "root";                       
	private static final String PASSWORD = "1017040120";
	
	
	static{
		//1������������
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static java.sql.Connection getCon() throws SQLException{
		//2����ȡ���ݿ�����
		java.sql.Connection con = DriverManager.getConnection(URL,USERNAME,PASSWORD);
		return con;
	}
	
//	public static void closeCon(ResultSet rs,PreparedStatement pstm,Connection con){
//		try {
//			if (rs!=null) {
//				rs.close();
//			}
//			if (pstm!=null) {
//				pstm.close();
//			}
//			if (con!=null) {
//				con.close();
//			}
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
//	}
}
