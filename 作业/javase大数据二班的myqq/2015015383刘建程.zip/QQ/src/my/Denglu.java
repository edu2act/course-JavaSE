package my;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import my.QQ;
import my.QQ; 
public class Denglu extends JFrame{
	public static void main(final String args[]){
		final JFrame f=new JFrame("QQ��½����");
		///////////////////////////////////////////////////////////////////////
		
		Panel p1 = new Panel();
		p1.setBounds(0, 0, 300, 150);
		f.add(p1);
		p1.setBackground(Color.blue);
		Icon mypic_icon=new ImageIcon("E:/88.jpg");
		JLabel myJlabel= new JLabel(mypic_icon);
		JScrollPane   myJScrollPane=new JScrollPane(myJlabel);
		   myJScrollPane.setLayout(new ScrollPaneLayout());
		 p1.add(myJScrollPane);
		
		///////////////////////////////////////////////////////////////////////////
		Panel p2 = new Panel();
		p2.setBounds(0, 150, 300, 40);
		//p2.setBackground(Color.red);
		f.add(p2);
		final JLabel l = new JLabel("�˺�:"); 
		l.setBounds(0,150,40,40); 
		p2.add(l); 
		final JTextField	inputField=new JTextField(10);//��ʼ��������� ���ݡ�
		inputField.setBackground(Color.white);
		//inputField.setBounds(40,151,400,40); 
		p2.add(inputField);
		/////////////////////////////////////////////////////////////////////////
		Panel p3 = new Panel();
		p3.setBounds(0,190, 300, 40);
		//p3.setBackground(Color.gray);
		f.add(p3);
		JLabel la = new JLabel("���룺  "); 
		la.setBounds(0,190,40,40); 
		p3.add(la); 
		final JTextField	inputField2=new JTextField(10);//��ʼ��������� ���ݡ�
	//	inputField2.setBounds(40,190,400,40); 
		inputField2.setBackground(Color.white);
		p3.add(inputField2);
	///////////////////////////////////////////////////////////////////////////////////////	
		
		Panel p4 = new Panel();
		p4.setBounds(0, 230, 300, 40);
		//p4.setBackground(Color.yellow);
		f.add(p4);
		JLabel r1 = new JLabel("״̬��"); 
		r1.setBounds(0,230,40,40); 
		p4.add(r1);
		Choice mi=new  Choice();
		mi.add("����");
		mi.add("����");
		mi.add("æµ");
    mi.setBounds(40, 230, 40, 40);
    p4.add(mi);
	////////////////////////////////////////////////////////////////////////////////////////////////	
		Panel p5 = new Panel();
		p5.setBounds(0, 270, 300, 40);
		//p5.setBackground(Color.gray);
		f.add(p5);
		//setLayout(new GridLayout(2,1));
		Panel p7 = new Panel();
		p7.setBounds(0, 310, 300, 40);
		//p7.setBackground(Color.gray);
		f.add(p7);
		p5.add(new Checkbox("�Զ���½"));
		p7.add(new Checkbox("��ס����"));
		//////////////////////////////////////////////////////////////////////
		Panel p6 = new Panel();
		p6.setBounds(0, 350, 300, 40);
		//p6.setBackground(Color.blue);
		f.add(p6);
		JButton b1=new JButton("��ȫ��½");
		b1.setBounds(0, 360, 100, 100);
		p6.add(b1);
		b1.addActionListener(new ActionListener(){
			public void actionPerformed(final ActionEvent arg0){

				  String str=inputField.getText();  //�����������Կ���ַ��� 
				  String me=inputField2.getText();  //
				 if(str.equals("zhou")&&me.equals("123")){
					 QQ wm=new QQ(); 
					f.setVisible(false);	    
					 
					 
				 }
        	
			}
		});
		
		
		/////////////////////////////////////////////////////////////////////////////////////////////////
		Panel p8 = new Panel();
		p8.setBounds(0, 390, 300, 40);
		f.add(p8);
		/////////////////////////////////////////////////////////////
	f.setSize(300,600);
	f.setResizable(false);//���ô˴��岻�����û�������С
	f.setVisible(true);
	}
}
