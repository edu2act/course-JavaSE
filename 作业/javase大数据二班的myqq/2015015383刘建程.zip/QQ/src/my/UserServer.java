package my;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author IBM
 */
import javax.swing.*;
import java.net.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.text.*;

public class UserServer implements WindowListener{
    JFrame mainFrame;
    JTextArea ta;
    JScrollPane sp;
    ServerSocket serverSocket;
    boolean listening=true;

    UserList userList;  //�û�ע����Ϣ:account  password


    public UserServer(){
        mainFrame=new JFrame("UserServer  �������������");
        mainFrame.setSize(450,500);
        mainFrame.setVisible(true);
        mainFrame.addWindowListener(this);
        //mainFrame.setResizable(false);

        ta=new JTextArea();
        ta.setText("�����Ƿ�������Ӧ�ͻ��˵���Ϣ\n");
        ta.requestFocus();
        ta.setEditable(false);
        sp=new JScrollPane(ta);
        mainFrame.getContentPane().add(sp,"Center");

        mainFrame.validate();

        userList=new UserList();

    }

    public void go(){
        try{
            serverSocket=new ServerSocket(1999);
			}catch(IOException e) {
			   System.out.println("Could not listen	on port:1999.");
               System.exit(-1);
            }
        try{
            while(listening){
                new ServerThread(serverSocket.accept()).start();
            }
            serverSocket.close();
        }catch(IOException e) {
			   System.out.println("ServerScoket accept or close error");
               System.exit(-1);
            }
    }

    class ServerThread extends Thread{
        Socket socket;
        public ServerThread(Socket s){
            socket=s;

        }
        public void run(){
            String line;
            String info[];
            String response="from beginning";
            try{
                BufferedReader is=new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter os=new PrintWriter(socket.getOutputStream());
                while(true){
                line=is.readLine();
                System.out.println("receive from client: "+line);
                info=line.split(":");
                if (info[0].equals("register")){
                    response=userList.addUser(info[1], info[2]);
                }else if (info[0].equals("login")){
                    response=userList.login(info[1],info[2],socket.getInetAddress().toString());
                }else if (info[0].equals("logout")){
                    response=userList.logout(info[1]);
                }else if (info[0].equals("change password")){

                }else if (info[0].equals("account list")){
                    response=userList.getUserList();
                }
                os.println(response);
                os.flush();
                printInfo(" from "+socket.getInetAddress()+": "+line+"\n"+response);
                }
            }catch(IOException e){
                System.out.println("IO error in run(), maybe client quit!");
            }

        }

        public void printInfo(String str){
                String s="";
                Date date=new Date();
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String  currentTime= formatter.format(date);
                s+=currentTime+"\n"+str+"\n";
                ta.append(s);
        }
    }

    public void windowClosing(WindowEvent e){
        userList.saveUser();
        System.exit(0);
    }
	public void windowOpened(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowClosed(WindowEvent e){}
	public void windowActivated(WindowEvent e){}
	public void windowDeactivated(WindowEvent e){}

    public static void main(String args[]){
        new UserServer().go();
    }

}

class UserList{  //ע�ᡢ�޸����롢��¼
	private Hashtable user;//�û�ע����Ϣ:account  password
    private Hashtable onlineList;

	public UserList(){
		FileInputStream fis;
		ObjectInputStream ois;

        onlineList=new Hashtable();

        //�������򿪻��ߴ����û�ע����Ϣ�ļ�
		try{
			fis=new FileInputStream("user.ser");
			ois=new ObjectInputStream(fis);
			user=(Hashtable) ois.readObject();
		}catch(FileNotFoundException e){
			user=new Hashtable();
		}catch(IOException e){
        }catch(ClassNotFoundException e){
        }
	}
    synchronized String addUser(String account,String password){
        Enumeration e = user.keys();
        while (e.hasMoreElements()){
            String s=(String) e.nextElement();
            if (s.equals(account)) return("account exist");
        }
        user.put(account,password);
        return("register success");
    }

	void deleteUser(String account,String password){
		user.remove(account);
	}

	synchronized void changePassword(String account,String newPassword,String oldPassword){

    }
	synchronized String login(String account,String password,String IP){
        Enumeration e = user.keys();
        while (e.hasMoreElements()){
            String s=(String) e.nextElement();
            if (s.equals(account)) {
                String pass=(String) user.get(s);
                if (pass.equals(password))
                   {
                    onlineList.put(account,IP);
                    return("login success");
                   } else return("login fail");
            }
        }
        return("login fail");
    }

    synchronized String logout(String account){
        onlineList.remove(account);
        return("logout success");
    }

    synchronized String getUserList(){
        String online="online";
        Enumeration e = onlineList.keys();
        while (e.hasMoreElements()){
            String account=(String) e.nextElement();
            online+=":";
            online+=account;
            online+=":";
            String IP=(String) onlineList.get(account);
            online+=IP;
        }
        return (online);
    }

	synchronized void saveUser(){
		FileOutputStream fos;
		ObjectOutputStream oos;
		try{
            fos=new FileOutputStream("user.ser",false);
			oos=new ObjectOutputStream(fos);
			oos.writeObject(user);
		}catch(IOException e){}
}
}

