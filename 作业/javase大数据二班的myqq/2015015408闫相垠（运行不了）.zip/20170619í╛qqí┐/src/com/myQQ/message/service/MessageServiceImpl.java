package com.myQQ.message.service;

import com.myQQ.entity.Message;
import com.myQQ.message.dao.MessageDaolmpl;

public class MessageServiceImpl {
	
	public int sendMessage(Message message){
		MessageDaolmpl messageDaoImpl=new MessageDaolmpl();
		return messageDaoImpl.saveMessage(message);
	}
}
