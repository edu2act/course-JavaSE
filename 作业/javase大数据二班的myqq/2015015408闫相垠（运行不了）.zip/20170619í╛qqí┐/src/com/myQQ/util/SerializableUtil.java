package com.myQQ.util;

import com.myQQ.entity.Message;

public class SerializableUtil {

	public static byte[] serializableMessage(Message msg) {
		// TODO Auto-generated method stub
		return null;
	}

}
