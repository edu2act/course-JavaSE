package com.myQQ.util;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.mysql.jdbc.Connection;

public class ConnectionUtil {
	public static void getCon(){
		try{
			//��������
			Class.forName("com.mysql.jdbc.Driver");
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public static void closeCon(ResultSet rs, PreparedStatement pstm, Connection con) {
		// TODO Auto-generated method stub
		
	}


}	
