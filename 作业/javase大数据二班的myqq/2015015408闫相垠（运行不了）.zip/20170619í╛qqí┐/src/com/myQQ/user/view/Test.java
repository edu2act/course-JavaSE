package com.myQQ.user.view;

import java.sql.Date;

import com.myQQ.entity.Users;

public class Test {

	public static void main(String[] args) {
		Users u = new Users();
		u.setNickName("abc");
		u.setPassword("abc");
		u.setGender("��");
		u.setRegisterTime(new Date(0));
		u.setIntroduce("abc");
		u.setIp("123.1.2.3");
		
		
	}
