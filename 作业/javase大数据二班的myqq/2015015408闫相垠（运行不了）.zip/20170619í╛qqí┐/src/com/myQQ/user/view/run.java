package com.myQQ.user.view;

public class run {

	public static void main(String[] args) {
		LoginFrame loginFrame = new LoginFrame();

	}

}
