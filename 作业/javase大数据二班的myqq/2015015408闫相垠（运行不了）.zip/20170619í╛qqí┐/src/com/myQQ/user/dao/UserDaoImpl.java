package com.myQQ.user.dao;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.myQQ.entity.Users;
import com.myQQ.util.ConnectionUtil;
import com.mysql.jdbc.Connection;

public class UserDaoImpl {
	public boolean saveUser(Users a){
		try{
			//��������
			Class.forName("com.mysql.jdbc.Driver");
			//��ȡ���ݿ�����
			java.sql.Connection con =  DriverManager.getConnection("jdbc:mysql://localhost:3306/myqq1_db","root","");
			//����statement
			PreparedStatement pstm = con.prepareStatement("Insert into users(nickName,password,registerTime,gender,"
					+ "introduce,ip) values(?,?,?,?,?,?)");
			pstm.setString(1, a.getNickName());
			pstm.setString(2,a.getPassword());
			pstm.setString(3, a.getRegisterTime().toLocaleString());
			pstm.setString(4, a.getGender());
			pstm.setString(5, a.getIntroduce());
			pstm.setString(6, a.getIp());
			
			int count = pstm.executeUpdate();
			pstm.close();
			con.close();
			if(count > 0)
				return true;
			
			else
				return false;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		
	}
	
	public Users findByQqNumAndPassword(int qqNum,String password){
		try{
			//��������
			Class.forName("com.mysql.jdbc.Driver");
			//��ȡ���ݿ�����
			java.sql.Connection con =  DriverManager.getConnection("jdbc:mysql://localhost:3306/myqq1_db","root","");
			//����statement
			PreparedStatement pstm = con.prepareStatement("select * from users u where u.qqnum = ? and u.password = ?");
			pstm.setInt(1, qqNum);
			pstm.setString(2, password);
			
			ResultSet rs = pstm.executeQuery();
			Users u = null;
			while(rs.next()){
				u = new Users();
				u.setQqNum(rs.getInt(1));
				u.setNickName(rs.getString(2));
				u.setPassword(rs.getString(3));
				u.setRegisterTime(rs.getDate(4));
				u.setGender(rs.getString(5));
				u.setIntroduce(rs.getString(6));
				u.setIp(rs.getString(7));
			}
			
			int count = pstm.executeUpdate();
			pstm.close();
			con.close();
			if(count > 0)
				return u;
			
			else
				return null;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	
	public List<Users> findFriendByQqNum(int qqNum){
		Connection con;
		PreparedStatement pstm;
		ResultSet rs;
		List<Users> list = new ArrayList<Users>();
		try{
//			con = ConnectionUtil.getCon();
			java.sql.Connection con =  DriverManager.getConnection("jdbc:mysql://localhost:3306/myqq1_db","root","");
			pstm = con.prepareStatement("select * from users u where u.qqNum<>?");
			pstm.setInt(1, qqNum);
			rs = pstm.executeQuery();
			while(rs.next()){
				Users u = new Users();
				u.setQqNum(rs.getInt(1));
				u.setNickName(rs.getString(2));
				u.setPassword(rs.getString(3));
				u.setRegisterTime(rs.getDate(4));
				u.setGender(rs.getString(5));
				u.setIntroduce(rs.getString(6));
				u.setIp(rs.getString(7));
				list.add(u);
			}
			return list;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{ConnectionUtil.closeCon(rs,pstm,con);}
		
	}

	public boolean updatePassword(int qqNum,String password){
		Connection con;
		PreparedStatement pstm;
		ResultSet rs;
		
		try{
			List<Users> list = new ArrayList<Users>();
//			con = ConnectionUtil.getCon();
			java.sql.Connection con =  DriverManager.getConnection("jdbc:mysql://localhost:3306/myqq1_db","root","");
			pstm = con.prepareStatement("update users set password = ? where qqNum = ?");
			pstm.setString(1, password);
			pstm.setInt(2, qqNum);
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{ConnectionUtil.closeCon(null,pstm,con);}
	}
}
