package com.myQQ.user.dao;

import com.myQQ.entity.Users;

public class UserServiceImpl {
	public boolean regist(Users u){
		UserDaoImpl userDaoImpl = new UserDaoImpl();
		return userDaoImpl.saveUser(u);
	}
	
	public Users login(int qqNUm,int password){
		UserDaoImpl userDaoImpl = new UserDaoImpl();
		return 
	}
}
