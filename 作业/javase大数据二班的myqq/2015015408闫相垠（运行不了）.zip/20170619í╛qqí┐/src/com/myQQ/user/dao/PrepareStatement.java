package com.myQQ.user.dao;

public class PrepareStatement {

}
