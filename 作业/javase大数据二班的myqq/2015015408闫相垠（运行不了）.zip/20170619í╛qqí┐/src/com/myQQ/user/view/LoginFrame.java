package com.myQQ.user.view;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginFrame extends JFrame{

	JLabel lblQqNum;
	JLabel lblPassword;
	JTextField txtQqNum;
	JPasswordField txtPassword;
	JButton btnLogin;
	JButton btnCancle;
	
	
	
	public LoginFrame(){
		lblQqNum = new JLabel("QQ��:");
		lblPassword = new JLabel("����:");
		txtQqNum = new JTextField();
		txtPassword = new JPasswordField();
		btnLogin = new JButton("��½");
		btnCancle = new JButton("ȡ��");
		
		this.getContentPane().setLayout(null);
		this.getContentPane().add(lblQqNum);
		lblQqNum.setBounds(40, 20, 160, 25);
		this.getContentPane().add(lblPassword);
		lblPassword.setBounds(40, 55, 160, 25);
		this.getContentPane().add(txtQqNum);
		txtQqNum.setBounds(120, 20, 100, 25);
		this.getContentPane().add(txtPassword);
		txtPassword.setBounds(120, 55, 100, 25);
		this.getContentPane().add(btnLogin);
		btnLogin.setBounds(50,90,60,20);
		this.getContentPane().add(btnCancle);
		btnCancle.setBounds(120, 90, 60, 20);
		
		btnLogin.addActionListener(new Btnistener());
		
		this.setTitle("QQ��½");
		this.setSize(300,200);
		this.setVisible(true);
	}
}
