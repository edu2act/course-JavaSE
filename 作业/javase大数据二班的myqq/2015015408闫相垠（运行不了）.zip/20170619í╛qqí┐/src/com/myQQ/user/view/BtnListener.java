package com.myQQ.user.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BtnListener implements ActionListener{

	private LoginFrame loginFrame;

	public BtnListener(LoginFrame loginframe){
		this.loginFrame = loginframe;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

	
	
}
