package com.myqq.message.service;

import com.myqq.entity.Message;
import com.myqq.message.dao.MessageDaoUtil;

public class MessageServiceImpl {
	public int sendMessage(Message message) {
		MessageDaoUtil messageDaoUtil = new MessageDaoUtil();
		return messageDaoUtil.saveMessage(message);
	}
}
