package com.myQQ.user.view;

import java.util.List;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeSelectionModel;

import com.myQQ.entity.User;
import com.myQQ.message.service.ServerThread;
import com.myQQ.user.view.TreeMouseListener;

public class MainFrame extends JFrame {
	User myself;
	List<User>friends;
	JScrollPane userListPanel=null;
	JTree usersTree=null;
	DefaultTreeModel treeModel=null;
	DefaultMutableTreeNode rootNode=null;
	public MainFrame(){}
	
	public MainFrame(User U){
		myself=U;
		rootNode=new DefaultMutableTreeNode("");
		treeModel=new DefaultTreeModel(rootNode);
		usersTree=new JTree(treeModel);
		usersTree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
		usersTree.setShowsRootHandles(true);
		userListPanel=new JScrollPane(usersTree);
		
		com.myQQ.user.serivce.UserServiceImpl userServiceImpl=new com.myQQ.user.serivce.UserServiceImpl();
		friends=userServiceImpl.listFriends(myself.getQqnum());
		for(User friend : friends){		
			DefaultMutableTreeNode node=new DefaultMutableTreeNode(friend.getQqnum()+" "+friend.getNickname());
			rootNode.add(node);
		}
		usersTree.addMouseListener(new TreeMouseListener(usersTree, myself));
		
		this.getContentPane().add(userListPanel);
		this.setTitle(myself.getNickname());
		this.setSize(200, 500);
		this.setVisible(true);
		
		new Thread(new com.myQQ.message.service.ServerThread()).start();
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
}
