package com.myQQ.user.serivce;

import java.util.List;

import com.myQQ.entity.User;
import com.myQQ.user.dao.UserDaoImpl;


//ҵ���߼���
public class UserServiceImpl {

	public boolean regist(User u){
		UserDaoImpl userDaoImpl=new UserDaoImpl() ;
		
		return (userDaoImpl.saveUser(u));
	}
	
	public User login(int qqNum, String password){
		UserDaoImpl userDaoImpl=new UserDaoImpl();
		User u=userDaoImpl.findByQQNumAndPassword(qqNum, password);
		if(u!=null){
			String ip=com.myQQ.util.IpUtil.getLocalHostAddress();
			userDaoImpl.update(qqNum, ip);
			u.setIp(ip);
			return u;
		}else{
			return null;
		}
	}
	
	public List<User> listFriends(int qqNum){
		UserDaoImpl userDaoImpl=new UserDaoImpl();
		return userDaoImpl.findFriendsByQqNum(qqNum);
	}
	
	public User listByQqNum(int qqNum){
		UserDaoImpl userDaoImpl=new UserDaoImpl();
		return userDaoImpl.getUser(qqNum);
	}
	
}
