package com.myQQ.user.dao;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.myQQ.entity.User;
import com.myQQ.util.ConnectionUtil;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

//dao�����ݹ�����
public class UserDaoImpl {

	//
	public User getUser(int qqNum){
		try{
			java.sql.Connection con =ConnectionUtil.getCon();
			java.sql.PreparedStatement pstm=con.prepareStatement("select*from users u where u qqnum=?");
			pstm.setInt(1, qqNum);
			ResultSet rs=pstm.executeQuery();
			User u=null;
			while(rs.next()){
				u=new User();
				u.setQqnum(rs.getInt(1));
				u.setNickname(rs.getString(2));
				u.setPassword(rs.getString(3));
				u.setRegisterTime(rs.getDate(4));
				u.setGender(rs.getString(5));
				u.setIntroduce(rs.getString(6));
				u.setIp(rs.getString(7));
			}
			ConnectionUtil.closeCon(rs, pstm, con);
			return u;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	
	//saveUser��һ�ֹ��óƺ� Ӧ��ͳһ  ���û���Ϣ�������ݿ�
	public boolean saveUser(User u){
		try{
			//1 ��������   ��ȡ���ݿ�����
			java.sql.Connection con=ConnectionUtil.getCon();

			
			//2 ����statement
			java.sql.PreparedStatement pstm=con.prepareStatement("insert into users(nickname,password,registTime,gender,introduce,ip) values (?,?,?,?,?,?)");		
			//3 ���ò���     ��ԣ�ռλ��
			pstm.setString(1, u.getNickname());		//������һ��ʼ
			pstm.setString(2,u.getPassword());
			pstm.setString(3, u.getRegisterTime().toLocaleString());  	//ת�������ݿ�ʱ��
			pstm.setString(4, u.getGender());
			pstm.setString(5, u.getIntroduce());
			pstm.setString(6, u.getIp());
			pstm.executeUpdate();		//��jvm���͸����ݿ� ִ�к󷵻�jvm
			
			int count=pstm.executeUpdate();		//���ص������� ��  ����0�ɹ�
			//4�ر���������
			ResultSet rs=pstm.getGeneratedKeys();
			if(rs.next()){
				System.out.println(rs.getInt(1));
			}
			ConnectionUtil.closeCon(rs, pstm, con);
			if(count>0){
				return true;
			}
			else{
				return false;
			}
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		
	}

	//���ݲ�ѯ
	public User findByQQNumAndPassword(int qqNum,String password){
		try{
			//1 ��������   ��ȡ���ݿ�����
			java.sql.Connection con=ConnectionUtil.getCon();

			//2 ����statement
			java.sql.PreparedStatement pstm=con.prepareStatement("select * from users u where u.qqnum=? and u.password=?");		
			
			//4 ���ò���     ��ԣ�ռλ��
			pstm.setInt(1, qqNum);
			pstm.setString(2, password);
			
			pstm.executeQuery();//��ѯʹ��query  ����������update
			
			ResultSet rs=pstm.executeQuery();		//��ʼָ���һ��������λ��
			User u=null;
			while(rs.next()){
				u=new User();
				int qqnum=rs.getInt(1);
				u.setQqnum(rs.getInt(1));
				u.setNickname(rs.getString(2));
				u.setPassword(rs.getString(3));
				u.setRegisterTime(rs.getDate(4));
				u.setGender(rs.getString(5));
				u.setIntroduce(rs.getString(6));
				u.setIp(rs.getString(7));
				}
			
			//5 �ر���������
			ConnectionUtil.closeCon(rs, pstm, con);
				return u;	
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	
	//�������ݲ�ѯ
	public List<User> findFriendsByQqNum(int qqNum){
		Connection con=null;
		java.sql.PreparedStatement pstm=null;
		ResultSet rs=null;
		
		
		try{
			List<User> list=new ArrayList<User>();
			//2 ��ȡ���ݿ�����
			pstm=con.prepareStatement("select * from users u where u.qqNum<>?");
				pstm.setInt(1, qqNum);
			rs=pstm.executeQuery();
			User u=null;
			while(rs.next()){
				 u = new User();
				int qqnum=rs.getInt(1);
				u.setQqnum(rs.getInt(1));
				u.setNickname(rs.getString(2));
				u.setPassword(rs.getString(3));
				u.setRegisterTime(rs.getDate(4));
				u.setGender(rs.getString(5));
				u.setIntroduce(rs.getString(6));
				u.setIp(rs.getString(7));
				list.add(u);
				}
			return list;
			
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			ConnectionUtil.closeCon(rs, pstm, con);
		}
	}
	
	//�޸�����
	public boolean updatePassword(int qqNum,String password ){
		java.sql.Connection con=null;
		java.sql.PreparedStatement pstm=null;
		try{
			List <User> list = new ArrayList<User>();
			//2 ��ȡ���ݿ�����
			con=ConnectionUtil.getCon();
			 pstm=con.prepareStatement("update users set password=? where qqNum=?");
			pstm.setString(1, password);
			pstm.setInt(2, qqNum);
			int count=pstm.executeUpdate();
			if(count>0){
			return true;
			}
			else{
				return false;
			}
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}finally{
			ConnectionUtil.closeCon(null, pstm, con);
		}
	}

	//����Ip
	public void update(int qqNum,String Ip){
		java.sql.Connection con=null;
		java.sql.PreparedStatement pstm=null;
		try{
			con=ConnectionUtil.getCon();
			pstm=con.prepareStatement("update users set ip=? where qqNum=?");
			pstm.setString(1, Ip);
			pstm.setInt(2, qqNum);
			pstm.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			ConnectionUtil.closeCon(null, pstm, con);
		}
	}
}
