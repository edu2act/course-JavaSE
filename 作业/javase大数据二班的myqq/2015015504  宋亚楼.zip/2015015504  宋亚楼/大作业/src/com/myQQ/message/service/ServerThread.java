package com.myQQ.message.service;

import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

import com.myQQ.entity.Message;
import com.myQQ.util.SerializableUtil;

public class ServerThread implements Runnable{

	public void run(){
		try{
			ServerSocket serverSocket=new ServerSocket(8888);
			while (true){
				Socket socket=serverSocket.accept();
				InputStream is=socket.getInputStream();
				byte cache[]=new byte[is.available()];
				is.read(cache);
				Message message=SerializableUtil.unSerializableMessage(cache);
				System.out.println(message.getSender());
				System.out.println(message.getContent());
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
