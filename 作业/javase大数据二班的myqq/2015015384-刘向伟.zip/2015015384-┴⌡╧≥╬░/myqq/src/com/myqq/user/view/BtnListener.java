package com.qq1.user.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import javax.swing.JFrame;

import com.qq1.entity.Users;
import com.qq1.message.service.ServerThread;
import com.qq1.user.dao.UserDaoImpl;
import com.qq1.user.service.UserServiceImpl;
import com.qq1.util.IPUtil;

//��½���߼���Ӱ���
public class BtnListener implements ActionListener{
	
	LoginFrame loginFrame;
	List<Users> us;              //���û��ĺ����б�
	
	public BtnListener(LoginFrame loginFrame){
		this.loginFrame=loginFrame;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String qqNum=loginFrame.txtQQNum.getText();
		String password=new String(loginFrame.txtPassword.getPassword());
		
		int qqnum=0;
		try{
			qqnum=Integer.parseInt(qqNum);
		}catch(Exception e1){
			loginFrame.txtQQNum.setText("������qq�ţ�");
		}
		Users u=null;
		try {
			u = UserServiceImpl.login(qqnum, password);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//����鲻����
		if(u!=null){
			//����������û��ĵ�½IP
			String ip=IPUtil.getAddress();
			u.setIp(ip);
			try {
				UserDaoImpl.updateIP(u.getQqNum(), ip);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			
			//Ѱ�Һ����б�
	        try {
				us=UserDaoImpl.foundFriends(u.getQqNum());
			} catch (Exception es) {
				// TODO Auto-generated catch block
				es.printStackTrace();
			}
			
			//�����б�����
			FriendsList f=new FriendsList(u, us);
	        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        
	        //ServerSocket��ʼ����
	        new Thread(new ServerThread(u,us)).start();
	        
	        //��½��ɺ󴰿ڹر�
	        loginFrame.dispose();
	        loginFrame=null;
		}else{
			loginFrame.txtQQNum.setText("qq�Ų����ڻ��������");
		}
		
	}
	
}
