package com.qq1.util;

import java.net.InetAddress;

public class IPUtil {
	public static String getAddress(){
		String hostName;
		try {
			InetAddress addr = InetAddress.getLocalHost();
			hostName = addr.getHostAddress();
		} catch (Exception ex) {
			hostName = "";
		}
		return hostName;
	}
}
