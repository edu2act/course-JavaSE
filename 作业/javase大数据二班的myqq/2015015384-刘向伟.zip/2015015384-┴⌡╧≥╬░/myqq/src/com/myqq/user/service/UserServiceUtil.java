package com.qq1.user.service;

import com.mysql.jdbc.Driver;

public class UserServiceUtil {
	static{
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
