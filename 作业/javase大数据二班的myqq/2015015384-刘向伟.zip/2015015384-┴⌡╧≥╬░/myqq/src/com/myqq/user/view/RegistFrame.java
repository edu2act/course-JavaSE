package com.qq1.user.view;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class RegistFrame extends JFrame{
	//��ǩ
	JLabel lblQQNum;
	JLabel lblPassword;
	JLabel lblNickName;
	JLabel lblGender;
	JLabel lblIntroduction;
	//�ı���
	JTextField txtQQNum;
	JPasswordField txtPassword;
	JTextField txtNickName;
	JTextField txtGender;
	JTextArea txtIntroduction;
	//��ť
	JButton btnRegist;
	
	public RegistFrame(){
		//�ؼ�
		lblQQNum=new JLabel("QQ�ţ�");
		lblPassword=new JLabel("QQ���룺");
		lblNickName=new JLabel("�ǳƣ�");
		lblGender=new JLabel("�Ա�");
		lblIntroduction=new JLabel("���˼�飺");
		
		txtQQNum=new JTextField();
		txtPassword=new JPasswordField();
		txtNickName=new JTextField();
		txtGender=new JTextField();
		txtIntroduction=new JTextArea();
		
		btnRegist=new JButton("ע��");
		//�ѿؼ�����ȥ
		//��Ҫ���ò���Ϊ��
		this.getContentPane().setLayout(null);
		//��ǩ
		this.getContentPane().add(lblQQNum);
		lblQQNum.setBounds(20,20,160,25);
				
		this.getContentPane().add(lblPassword);
		lblPassword.setBounds(20,65,160,25);
		
		this.getContentPane().add(lblNickName);
		lblNickName.setBounds(20,110,160,25);
		
		this.getContentPane().add(lblGender);
		lblGender.setBounds(20,155,160,25);
		
		this.getContentPane().add(lblIntroduction);
		lblIntroduction.setBounds(20,200,160,25);
		//�ı���
		this.getContentPane().add(txtQQNum);
		txtQQNum.setBounds(80,20,180,25);

		this.getContentPane().add(txtPassword);
		txtPassword.setBounds(80,65,180,25);
		
		this.getContentPane().add(txtGender);
		txtGender.setBounds(80,110,180,25);
		
		this.getContentPane().add(txtNickName);
		txtNickName.setBounds(80,155,180,25);
		
		this.getContentPane().add(txtIntroduction);
		txtIntroduction.setBounds(20,235,240,100);
		//��ť
		this.getContentPane().add(btnRegist);
		btnRegist.setBounds(100,350,80,25);
		
		this.setTitle("QQע��");
		this.setSize(300, 430);
		this.setVisible(true);
		
		//ע�ᰴť�¼�
		btnRegist.addActionListener(new Btn4Listener(this));
	}
}
