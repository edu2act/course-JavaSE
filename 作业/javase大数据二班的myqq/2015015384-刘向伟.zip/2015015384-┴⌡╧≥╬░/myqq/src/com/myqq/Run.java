package com.qq1;
/*
	ʵ�����еĹ���
*/
import com.qq1.user.view.LoginFrame;

public class Run {
	public static void main(String... args){
		System.setProperty("file.encoding", "utf-8");
		LoginFrame a=new LoginFrame();
		a.setDefaultCloseOperation(a.EXIT_ON_CLOSE);
	}
}
