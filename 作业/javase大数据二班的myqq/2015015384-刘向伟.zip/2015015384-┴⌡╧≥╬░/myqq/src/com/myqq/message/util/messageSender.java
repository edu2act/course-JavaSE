package com.qq1.message.util;
/*
	需求：建立聊天过程，接受发送消息
	
	分析：使用udp，tcp协议，打开输入，输出流，打开连接，实现发送和接受消息
*/
import com.qq1.entity.Message;
import com.qq1.util.SerializableUtil;

import java.io.IOException;
import java.io.OutputStream;
import java.net.*;

public class messageSender implements Runnable{
	String ip;
	Message msg;
	
	public messageSender(Message msg, String ip){
		this.msg=msg;
		this.ip=ip;
	}

	public void run() {
		try {
			Socket socket=new Socket(ip, 8888);
			OutputStream os=socket.getOutputStream();
			os.write(SerializableUtil.messageToByteArray(msg));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	
}
