package com.qq1.user.view;

import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

import com.qq1.entity.Users;
import com.qq1.message.service.ClientThread;
import com.qq1.message.service.ServerThread;
import com.qq1.message.view.ChatFrame;

public class TreeMouseListener implements MouseListener{
	JTree tree;
	List<Users> us;    //��Ҫ���ҵ��û�Ҫ����Ķ���
	Users u;           //�û�
	Users u2;		   //�û�Ҫ����Ķ���
	
	public TreeMouseListener(JTree tree, Users u, List<Users> us){
		this.us=us;
		this.tree = tree;
		this.u=u;
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		if (e.getModifiers() == InputEvent.BUTTON1_MASK && e.getClickCount() == 2) {
			int n = tree.getRowForLocation(e.getX(), e.getY());
			if (n < 0)
				return;
			TreePath selTree = tree.getPathForRow(n);
			DefaultMutableTreeNode selNode = (DefaultMutableTreeNode) selTree.getLastPathComponent();
			String[] a=selNode.getUserObject().toString().split(" ");
			if (selNode.isLeaf()) {
				//�Ӻ����б����ҵ��û�Ҫ����Ķ���
				for(Users uu:us){
					if(uu.getQqNum()==Integer.parseInt(a[1])){
						u2=uu; break;
					}
				}
				
				ChatFrame chatFrame=new ChatFrame(u,u2);
				//�����������˿ͻ����߳�
				new Thread(new ClientThread(chatFrame,u,u2,us)).start();
			}
		}

	}	
}
