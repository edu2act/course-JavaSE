package com.qq1.user.service;
/*
	���󣺽�������ע�ᣬ�����û�ע��
	
	����������ע�᷽��
*/
import java.sql.SQLException;
import java.text.ParseException;

import com.qq1.entity.Users;
import com.qq1.user.dao.UserDaoImpl;

public class UserServiceImpl {
	public boolean regist(Users u){
		UserDaoImpl UserDaoImpl1=new UserDaoImpl();
		try {
			return UserDaoImpl1.saveUser(u);
		} catch (ClassNotFoundException e){
			e.printStackTrace();
		}
		return false;
	}
	
	public static Users login(int qqNum, String password) throws ParseException{
	
		UserDaoImpl UserDaoImpl1=new UserDaoImpl();
		Users u=null;
		try {
			u=UserDaoImpl1.foundByQQNumAndPassword(qqNum, password);
		} catch (ClassNotFoundException e){
			e.printStackTrace();
		}
		if(u!=null){
			String ip=null;
			try {
				UserDaoImpl.updateIP(qqNum, ip);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			u.setIp(ip);
		}
		return u;
	}
}
