package com.qq1.user.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

import com.qq1.entity.Users;
import com.qq1.user.service.UserServiceImpl;
import com.qq1.util.IPUtil;

public class Btn4Listener implements ActionListener{
	RegistFrame registFrame;
	
	public Btn4Listener(RegistFrame registFrame){
		this.registFrame=registFrame;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Users u=new Users();
		u.setGender(registFrame.txtGender.getText());
		u.setIntroduction(registFrame.txtIntroduction.getText());
		u.setNickName(registFrame.txtNickName.getText());
		u.setPassword(String.valueOf(registFrame.txtPassword.getPassword()));
		u.setQqNum(Integer.parseInt(registFrame.txtQQNum.getText()));
		u.setRegistTime(new Date());
		u.setIp(IPUtil.getAddress());
		
		UserServiceImpl userServiceImpl=new UserServiceImpl();
		if(userServiceImpl.regist(u)){
			System.out.println("ע��ɹ���");
		}else{
			System.out.println("ע��ʧ�ܣ�");
		}
	}
}
