package com.qq1.message.util;
/*
	需求：建立聊天过程，接受发送消息
	
	分析：使用udp，tcp协议，打开输入，输出流，打开连接，实现发送和接受消息
*/
import com.qq1.entity.Message;

public class MessageFormater {
	public static String MessageFormat(Message message,String name){
		return message.getSendTime().toLocaleString()+"\n"+name+" :\n"+message.getContent()+"\n\n";
	}
}
