package ������;

public class Fapai {
	public static void main(String[] args) {
	Laoliu l =new Laoliu();
	l.t();
 }
}
