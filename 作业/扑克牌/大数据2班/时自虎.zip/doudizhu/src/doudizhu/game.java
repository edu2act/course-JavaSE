package doudizhu;

import java.util.Collection;
import java.util.LinkedList;
import java.util.Random;

public class game {

	public static void main(String[] args) {
		LinkedList flowers = new LinkedList();
		LinkedList nums = new LinkedList();
		LinkedList pokes = new LinkedList();
		Player player1=new Player();
		Player player2=new Player();
		Player player3=new Player();
		Player[] players = {player1,player2,player3};
		flowers.add("����");
		flowers.add("÷��");
		flowers.add("����");
		flowers.add("����");
		for (int i = 1; i < 14; i++) {
			nums.add(i);
		}
		
		for (int i = 0; i < 4; i++) {
			String color = (String) flowers.remove(0);
			for(int j = 0;j<13;j++){
				Puke p = new Puke();
				p.setColor(color);
				p.setNum(j+1);
				pokes.add(p);
//				System.out.print(p.getColor());
//				System.out.println(p.getNum());
			}
		}
		Puke m=new Puke();
		m.setColor("����");
		m.setNum(0);
		pokes.add(m);
		Puke n=new Puke();
		n.setColor("С��");
		n.setNum(0);
		pokes.add(n);
//		System.out.println(pokes.size());
		//���һ������
//		Puke p1 = new Puke();
//		for(int k=0;k<54;k++){	
//			p1=(Puke) pokes.remove();
//			System.out.print(p1.getColor());
//			System.out.println(p1.getNum());
//		}
		//���뷢�ƽ׶�
		for(int i=0;pokes.size()>3;i++){
			players[i%3].getList().add(pokes.remove());
		}
//		System.out.println(pokes.size());
		int r = new Random().nextInt(3);
		for(int i=0;i<3;i++){
			players[r%3].getList().add(pokes.remove());
		}
//		for(int i=0;i<3;i++){
//			System.out.println(players[i%3].getList().size());
//		}
//		System.out.println(pokes.size());

		System.out.println("���"+(r+1)+"��ѡΪ������");
		for(int i = 0;i<3;i++){
			System.out.println("���"+(i+1)+"�����ǣ�");
			while(players[i].getList().size()!=0){
				Puke p3 = new Puke();
				p3 = (Puke)players[i].getList().remove();
				System.out.println(p3.getColor()+p3.getNum());
			}
//			System.out.println(players[i].getList().size());
		}
				
//		for(int i = 0;i<20;i++){
//			Puke p3 = new Puke();
//			p3 =(Puke) player1.getList().remove(0);
//			System.out.print(p3.getColor());
//			System.out.println(p3.getNum());
//		}
//		System.out.println(player1.getList().size());
//		for(int i = 0;i<17;i++){
//			Puke p3 = new Puke();
//			p3 =(Puke) player2.getList().remove(0);
//			System.out.print(p3.getColor());
//			System.out.println(p3.getNum());
//		}
//		System.out.println(player2.getList().size());
//		for(int i = 0;i<17;i++){
//			Puke p3 = new Puke();
//			p3 =(Puke) player3.getList().remove(0);
//			System.out.print(p3.getColor());
//			System.out.println(p3.getNum());
//		}
//		System.out.println(player3.getList().size());
	}
}
