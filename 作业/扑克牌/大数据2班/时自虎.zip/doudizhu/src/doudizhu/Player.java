package doudizhu;

import java.util.LinkedList;

public class Player {
	private String name;
	private int levle;
	
	private LinkedList list=new LinkedList();//�洢�Լ����е���

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getLevle() {
		return levle;
	}

	public void setLevle(int levle) {
		this.levle = levle;
	}

	public LinkedList getList() {
		return list;
	}

	public void setList(LinkedList list) {
		this.list = list;
	}
}
