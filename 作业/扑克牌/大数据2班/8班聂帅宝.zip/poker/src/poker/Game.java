package poker;

import java.util.LinkedList;
import java.util.Random;

public class Game {

	public static void main(String[] args) {
		LinkedList list = new LinkedList();
		
		Plyer plyer1 = new Plyer();
		Plyer plyer2 = new Plyer();
		Plyer plyer3 = new Plyer();
		//�½�һ����
		newCard(list);
		
		//��ʾ�½�����
		showCard(list);
		System.out.println();
		//���ϴ��
		shuffleCard(list);
		//��ʾϴ�����
		showCard(list);
		System.out.println(list.size());
		System.out.println("���1������");
		showCard(plyer1.dealCard(list));
		System.out.println("���2������");
		showCard(plyer1.dealCard(list));
		System.out.println("���3������");
		showCard(plyer1.dealCard(list));
}

	public static LinkedList newCard(LinkedList list) {

		for (int i = 0; i < 52; i++) {
			Poker poker = new Poker();
			poker.setNumber(i % 13 + 1);
			switch (i % 4) {
			case 0:
				poker.setColor("spade");
				break;
			case 1:
				poker.setColor("club");
				break;
			case 2:
				poker.setColor("heart");
				break;
			case 3:
				poker.setColor("diamond");
				break;
			}
			list.add(poker);
		}
		Poker poker1 = new Poker();
		poker1.setColor("red joker");
		poker1.setNumber(14);
		list.add(poker1);
		Poker poker2 = new Poker();
		poker2.setColor("black joker");
		poker2.setNumber(14);
		list.add(poker2);
		return list;
	}

	public static LinkedList shuffleCard(LinkedList list) {
		Random r = new Random();
		for (int i = 0; i < 100; i++) {
			int n=r.nextInt(list.size());
			int m=r.nextInt(list.size());
			Poker poker1=(Poker)list.get(n);
			Poker poker2=(Poker)list.get(m);
			list.set(n, poker2);
			list.set(m, poker1);
		}

		return list;

	}

	public static void showCard(LinkedList list){
		for(int i = 0; i<list.size();i++){
			System.out.println(list.get(i));
			
		}
	}
}
