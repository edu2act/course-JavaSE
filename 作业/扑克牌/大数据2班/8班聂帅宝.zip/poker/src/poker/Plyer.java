package poker;

import java.util.LinkedList;

public class Plyer {
	private String name;
	private int level;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	 @SuppressWarnings("unchecked")
	public static LinkedList dealCard(LinkedList poker){
		LinkedList list = new LinkedList();
		for(int i=0;i<13;i++){
			list.add(poker.get(i));
			poker.remove(i);
			
		}
		return list;
		
	}
}
