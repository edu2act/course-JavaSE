package poker;

import java.util.ArrayList;
import java.util.Collections;

public class Poker {
	String color[]={"����","����","��Ƭ","÷��"};
	String num[]={"A","2","3","4","5","6","7","8","9","10","J","Q","K"};
	ArrayList arraylist = new ArrayList();
	int index = 0;
	
	
	public Poker() {}

	public void storagePoker(){
		for (int i = 0; i<color.length;i++){
			for(int j = 0; j<num.length;j++){
				arraylist.add(index, color[i].concat(num[j]));
				index++;
			}
		}
		arraylist.add(index, "����");
		arraylist.add(++index, "С��");
		Collections.shuffle(arraylist);
	}
	public ArrayList display(){
		return arraylist;
	}


	
}
