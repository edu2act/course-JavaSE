package ch22;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;


public class PlayCradText {

	public static void main(String[] args) {
		PlayCard pc = new PlayCard();
		pc.init();    //运行初始化方法加入扑克牌
		pc.shuffle();  //初始化后就洗牌
		
//		pc.show();//查看所有牌
		
//		HashMap<String,String> hm = new HashMap<String,String>();
//		hm.put("1", "1");
//		hm.put("2", "2");
//		hm.put("3", "3");
		
//		hm.remove("2");//根据键删除键值对
//		hm.put("3","66" );
		
		ArrayList list1 = new ArrayList();
		ArrayList list2 = new ArrayList();
		ArrayList list3 = new ArrayList();
		
		System.out.println("玩家一的牌:");
		for (int i = 0; i < 18; i++) {
			list1.add(pc.alist.get(i));
			System.out.print(pc.alist.get(i)+"\t");
		}
		System.out.println("\n"+"玩家二的牌:");
		for (int i = 18; i < 36; i++) {
			list2.add(pc.alist.get(i));
			System.out.print(pc.alist.get(i)+"\t");
		}
		System.out.println("\n"+"玩家三的牌:");
		for (int i = 36; i < 54; i++) {
			list3.add(pc.alist.get(i));
			System.out.print(pc.alist.get(i)+"\t");
		}
		
		list1.
		
//		for(String key : hm.keySet()){
//			System.out.println(hm.get(key));
//		}
	}

}
