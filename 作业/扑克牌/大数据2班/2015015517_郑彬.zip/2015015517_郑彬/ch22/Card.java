package ch22;

public class Card {
	private String face;
	private int score;
	public String getFace() {
		return face;
	}
	public void setFace(String face) {
		this.face = face;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public Card() {
		super();
	}
	public Card(String face, int score) {
		this.face = face;
		this.score = score;
	}
	public void show(){
		System.out.println("牌面:"+face+"分值:"+score);
	}
}

