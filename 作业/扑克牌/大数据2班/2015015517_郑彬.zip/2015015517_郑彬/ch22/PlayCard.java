package ch22;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Set;

public class PlayCard {
	HashMap<String,Card> hm = new HashMap<String,Card>();
	ArrayList<String> alist = new ArrayList<String>();//保存键的集合
	//定义init方法初始化hm
	public void init(){
		hm.put("黑桃A",new Card("黑桃A",1));
		for(int i = 2;i <= 10;i++){
			hm.put("黑桃"+i,new Card("黑桃"+i,i));
		}
		hm.put("黑桃J",new Card("黑桃J",11));
		hm.put("黑桃Q",new Card("黑桃Q",12));
		hm.put("黑桃K",new Card("黑桃K",13));
		
		hm.put("红桃A",new Card("红桃A",1));
		for(int i = 2;i <= 10;i++){
			hm.put("红桃"+i,new Card("红桃"+i,i));
		}
		hm.put("红桃J",new Card("红桃J",11));
		hm.put("红桃Q",new Card("红桃Q",12));
		hm.put("红桃K",new Card("红桃K",13));
		
		hm.put("方片A",new Card("方片A",1));
		for(int i = 2;i <= 10;i++){
			hm.put("方片"+i,new Card("方片"+i,i));
		}
		hm.put("方片J",new Card("方片J",11));
		hm.put("方片Q",new Card("方片Q",12));
		hm.put("方片K",new Card("方片K",13));
		
		hm.put("梅花A",new Card("梅花A",1));
		for(int i = 2;i <= 10;i++){
			hm.put("梅花"+i,new Card("梅花"+i,i));
		}
		hm.put("梅花J",new Card("梅花J",11));
		hm.put("梅花Q",new Card("梅花Q",12));
		hm.put("梅花K",new Card("梅花K",13));
		
		hm.put("小王", new Card("小王",20));
		hm.put("大王", new Card("大王",30));
		
		
		Set<String> set = hm.keySet();
		alist.clear();   					//每次开始清空ArrayList
		alist.addAll(set); 					//无序集合转换成有序集合
	}
	
	//定义洗牌
	public void shuffle(){
		Collections.shuffle(alist);  //随机洗牌
	}
	public void show(){
		//Set<String> set = hm.keySet();
		for(String key : alist){
			Card card  = hm.get(key);//根据键获取值
			card.show();
		}
	}
}
