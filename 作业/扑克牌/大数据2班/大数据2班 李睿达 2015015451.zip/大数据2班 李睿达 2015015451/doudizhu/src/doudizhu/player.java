/**
 * 
 */
package doudizhu;

import java.util.LinkedHashSet;
import java.util.LinkedList;

/**
 * @author Administrator
 *
 */
public class  player {

	/**
	 * 
	 */
	public String name;
	public int level;
	public LinkedList list=new LinkedList();
	
}
