package doudizhu;

import java.util.Iterator;

import doudizhu.player;

public class test {

	public test() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       game game=new game();
       player p1=new player();
       player p2=new player();
       player p3=new player();
       System.out.println("获得54张牌：");
       game.chushipukepai();
      p1.name="player1";
      p2.name="player2";
      p3.name="player3";
      
       game.dasanpukepai(p1,p2,p3);
       
     
       
	}
	}
	
