/**
 * 
 */
package doudizhu;

import java.awt.List;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;

import doudizhu.player;



/**
 * @author Administrator
 *
 */
public class game {
	
     public   LinkedList list=new LinkedList();
     
     public void chushipukepai(){
    	 
         for(int n=1;n<14;n++){
        	 while(n>0 && n<11){
    	    list.add("红桃"+n);
    	    break;
        	 }
        	 while(n>10 && n<12){
    	    list.add("红桃j");
    	    break;
    	    }
        	 while(n>11 && n<13){
         	    list.add("红桃Q");
         	    break;
         	    }
        	 while(n>12 && n<14){
          	    list.add("红桃K");
          	    break;
          	    }

         }
         for(int n=1;n<14;n++){
        	 while(n>0 && n<11){
    	    list.add("方片"+n);
    	    break;
        	 }
        	 while(n>10 && n<12){
    	    list.add("方片j");
    	    break;
    	    }
        	 while(n>11 && n<13){
         	    list.add("方片Q");
         	    break;
         	    }
        	 while(n>12 && n<14){
          	    list.add("方片K");
          	    break;
          	    }

         }
         for(int n=1;n<14;n++){
        	 while(n>0 && n<11){
    	    list.add("黑桃"+n);
    	    break;
        	 }
        	 while(n>10 && n<12){
    	    list.add("黑桃j");
    	    break;
    	    }
        	 while(n>11 && n<13){
         	    list.add("黑桃Q");
         	    break;
         	    }
        	 while(n>12 && n<14){
          	    list.add("黑桃K");
          	    break;
          	    }

         }
         for(int n=1;n<14;n++){
        	 while(n>0 && n<11){
    	    list.add("梅花"+n);
    	    break;
        	 }
        	 while(n>10 && n<12){
    	    list.add("梅花j");
    	    break;
    	    }
        	 while(n>11 && n<13){
         	    list.add("梅花Q");
         	    break;
         	    }
        	 while(n>12 && n<14){
          	    list.add("梅花K");
          	    break;
          	    }

         }
    	 
    	 list.add("小王 ");
    	 list.add("大王 ");
    	 Iterator j=(Iterator) list.iterator();
	     while(j.hasNext()){
	    	 Object obj=j.next();
	    	 System.out.println("初始化获得："+obj);
	    	  }
     }
     public void  dasanpukepai(player p1,player p2, player p3){
    	int i= list.size();
    	Random r=new Random();
    	 boolean[] bool = new boolean[i];  
         
         int k =0;  
    	for(int j=0;j<i+1;j++){
    		do{
    		//如果产生的数相同继续循环
    		 k=r.nextInt(i);
    		}while(bool[k]); 
    		bool[k] =true;
    			
    			if(j<18){
    			
    				p1.list.add(list.get(k));
    				if(j==17){
    			System.out.println(p1.name+"拿的牌是"+p1.list);}}
    			
    			else if(j>17&&j<36){
    				
        				p2.list.add(list.get(k));
        					if(j==35){
        			System.out.println(p2.name+"拿的牌是"+p2.list);}}
    	
    			else if(j>35&&j<54){
    				
            				p3.list.add(list.get(k));
            				
            				if(j==53){
                    			System.out.println(p3.name+"拿的牌是"+p3.list);}
    			}
    			
    	}
    			}
    			
    			
    				
    	
    			
     
     
     
	/**
	 * 
	 */
	public game() {
		// TODO Auto-generated constructor stub
	}

}
