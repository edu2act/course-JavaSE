
package demo;  
  
import java.util.ArrayList;  
import java.util.Collections;  
import java.util.HashMap;  
import java.util.TreeSet;  
  
public class Demo10 {  
	
	
    public static void main(String[] args) {  
        HashMap<Integer,String> hm = new HashMap<Integer,String>();   
        //定义HashMap变量存储每张排的编号以及牌型  
        ArrayList<Integer> array = new ArrayList<Integer>();  
        //定义ArrayList变量存储排的编号  
        String[] colors = {"♤","♥","♣","♢"};   
        //定义数组存储排的花色  
        String[] numbers = {"A","2","3","4","5","6","7","8","9","10","J","Q","K"};  
        //定义数组存储牌值  
        int index = 0;    
        //定义编号  
        for(String number : numbers){    
            //遍历排值数组  
            for(String color : colors){   
                //遍历花色  
                hm.put(index, color.concat(number));  
                //将花色与牌值拼接，并将编号与拼接后的结果存储到hm中  
                array.add(index);   
                //将编号存储到array中  
                index++;
            }  
        }
        /*将小王和大王存储到hm中 */  
        hm.put(index, "小王");    
        array.add(index);  
        index++;  
        hm.put(index, "大王");  
        array.add(index);  
        Collections.shuffle(array);    
        //调用Collections集合的shuffle()方法，将array中存储的编号顺序打乱
       
        /*定义四个TreeSet集合的变量用于存储底牌编号以及三个玩家的牌的编号 */  
        TreeSet<Integer> playerOne = new TreeSet<Integer>();  
        TreeSet<Integer> playerTwo = new TreeSet<Integer>();  
        TreeSet<Integer> playerThree = new TreeSet<Integer>();   
        TreeSet<Integer> dipai = new TreeSet<Integer>(); 
        //遍历编号的集合，实现发牌  
        for(int x = 0; x < array.size(); x++){  
            if(x >= array.size() - 3){  
                dipai.add(array.get(x));  
                }else if( x % 3 == 0){  
                    playerOne.add(array.get(x));  
                    }else if(x % 3 == 1){  
                        playerTwo.add(array.get(x));  
                        }else if(x % 3 == 2){  
                            playerThree.add(array.get(x));}  
            }  
        
        lookPoker("底牌",dipai,hm);  
        lookPoker("张三",playerOne,hm);  
        lookPoker("李四",playerTwo,hm);  
        lookPoker("王五",playerThree,hm);  
        }  
    /*遍历每个玩家的牌以及底牌*/  
    public static void lookPoker(String name,TreeSet<Integer> ts,HashMap<Integer,String> hm){  
        System.out.print(name+":\t");    
        //打印玩家名称  
        for(Integer key : ts){    
            //遍历玩家TreeSet集合，获得玩家的牌的编号  
            String value = hm.get(key);  
            //根据玩家牌编号获取具体的牌值  
            System.out.print(value+"  ");  
            //打印  
            }  
        System.out.println();  
        }  
    } 

