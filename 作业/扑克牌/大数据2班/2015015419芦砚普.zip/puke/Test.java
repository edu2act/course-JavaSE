package puke;

public class Test {
	public static void main(String[] args) {
		Game g = new Game();
		g.init();
	}
}
