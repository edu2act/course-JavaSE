package poker;

import java.util.ArrayList;
import java.util.LinkedHashSet;

public class Fapoker {

	public Fapoker() {}
	
	LinkedHashSet player1 = new LinkedHashSet();
	LinkedHashSet player2 = new LinkedHashSet();
	LinkedHashSet player3 = new LinkedHashSet();
	LinkedHashSet dipai = new LinkedHashSet();
	
	public void sendPoker(Poker poker){
		for(int i = 0;i<poker.display().size();i++){
			if(i>=poker.display().size()-3){
				dipai.add(poker.display().get(i));
			}else if(i%3==0){
				player1.add(poker.display().get(i));
			}else if(i%3==1){
				player2.add(poker.display().get(i));
			}else if(i%3==2){
				player3.add(poker.display().get(i));
			}
			
		}
	}
	public void displays(){
		System.out.println("player1���ƣ�"+player1+","+dipai);
		System.out.println("player2���ƣ�"+player2);
		System.out.println("player3���ƣ�"+player3);
	}
}