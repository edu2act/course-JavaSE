package poker;

public class Test {

	public static void main(String[] args) {
		Poker poker =  new Poker();
		poker.storagePoker();
		poker.display();
		Fapoker fapoker = new Fapoker();
		fapoker.sendPoker(poker);
		fapoker.displays();
		
	}

}
