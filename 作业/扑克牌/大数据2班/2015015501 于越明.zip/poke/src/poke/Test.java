package poke;

import java.util.LinkedList;

public class Test {

	public static void main(String[] args) {
		Player player1 = new Player();
		Player player2 = new Player();
		Player player3 = new Player();
		Player[] players={player1,player2,player3};
		Game g = new Game();
		g.initPoke();
		g.display(players);
		g.show(players);
	}

}
