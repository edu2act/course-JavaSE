package poke;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Random;

public class Game {// 实例化初始54张牌
	private LinkedList<Poke> list = new LinkedList<Poke>();
	String[] colors = { "梅花", "黑桃", "方片", "红桃" };
	String[] numbers = { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" };
	//初始化一副牌
	public void initPoke() {
		for (int i = 0; i < 13; i++) {
			for (int j = 0; j < 4; j++) {
				Poke poke = new Poke(numbers[i], colors[j]);
				list.add(poke);
			}
		}
		list.add(new Poke("0", "大王"));
		list.add(new Poke("0", "小王"));
	}

	//发牌
	public void display(Player players[]){
		Random ra=new Random();
		Poke poke1;
		int i=0;
		int j=54;
		while(list.size()>3){
			poke1=list.remove(ra.nextInt(j));
			players[i%3].getList().add(poke1);
			i++;
			j--;
		}
		for(int k=0;k<3;k++){
			poke1=list.remove(0);
			players[0].getList().add(poke1);
		}
	}
	//显示牌
	public void show(Player players[]){
		for(int k=0;k<3;k++){
			System.out.println(players[k].getList());
		}
	}
}
