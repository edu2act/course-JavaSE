package poke;

import java.util.LinkedList;

public class Player {
	private String name;
	private int level;
	private LinkedList list = new LinkedList();
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public LinkedList getList() {
		return list;
	}
	public void setList(LinkedList list) {
		this.list = list;
	}
}
