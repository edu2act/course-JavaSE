package poke;

public class Poke {
	private String color; 
	private String number;
	public Poke(String color, String numbers) {
		super();
		this.color = color;
		this.number = numbers;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
    public String toString() {  
        return "{" + color + "," + number + "}";  
    }
}
