
package puke;

import java.util.ArrayList;
import java.util.Collections;

public class Play {
	private ArrayList<Pai> list= new ArrayList<Pai>();
	public void init(){
		for(int i=1;i<14;i++){
			Pai p = new Pai();
			p.setColor("红桃");
			p.setNumber(i);
			list.add(p);
		}
		for(int i=1;i<14;i++){
			Pai p = new Pai();
			p.setColor("黑桃");
			p.setNumber(i);
			list.add(p);
		}
		for(int i=1;i<14;i++){
			Pai p = new Pai();
			p.setColor("方块");
			p.setNumber(i);
			list.add(p);
		}
		for(int i=1;i<14;i++){
			Pai p = new Pai();
			p.setColor("草花");
			p.setNumber(i);
			list.add(p);
		}
		Pai big = new Pai();
		big.setColor("大王");
		Pai small = new Pai();
		small.setColor("小王");
		list.add(big);
		list.add(small);
		Collections.shuffle(list);
		Player p1 = new Player();
		Player p2 = new Player();
		Player p3 = new Player();
		p1.setLevel(1);
		p2.setLevel(2);
		p3.setLevel(2);
		for(int i=0;i<17;i++){
			p2.li.add(list.get(i));
		}
		for(int i=17;i<34;i++){
			p3.li.add(list.get(i));
		}
		for(int i=34;i<54;i++){
			p1.li.add(list.get(i));
		}
		System.out.println("p1的牌为");
		for(int i=0;i<p1.li.size();i++){
			System.out.println(p1.getCard().get(i).getColor()+'\t'+p1.getCard().get(i).getNumber());
		}
		System.out.println("p2的牌为");
		for(int i=0;i<p2.li.size();i++){
			System.out.println(p2.getCard().get(i).getColor()+'\t'+p2.getCard().get(i).getNumber());
		}
		System.out.println("p3的牌为");
		for(int i=0;i<p3.li.size();i++){
			System.out.println(p3.getCard().get(i).getColor()+'\t'+p3.getCard().get(i).getNumber());
		}
	}
}
