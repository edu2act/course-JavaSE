package puke;
public class Main {
	public static void main(String[] args) {
		
			Play p = new Play();
			p.init();
		

	}

}
