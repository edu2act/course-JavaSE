package puke;

import java.util.LinkedList;

public class Player {
	private String name;
	private int level;
	public LinkedList Plist=new LinkedList();
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public LinkedList getList() {
		return Plist;
	}
	public void setList(LinkedList list) {
		this.Plist = Plist;
	}
	
}
