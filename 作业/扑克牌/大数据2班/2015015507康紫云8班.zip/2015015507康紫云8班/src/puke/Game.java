package puke;

import java.util.LinkedList;
import java.util.Random;

public class Game {
	public void initPuke(){
		String[]co={"红桃","方片","黑桃","梅花"};
		String[]king={"大王","小王"};
		String []num={"A","2","3","4","5","6","7","8","9","10","J","Q","K"};
		for(int i=0;i<13;i++)
		{
			for(int j=0;j<4;j++){
				Glist.add(co[j]+num[i]);
			}
		}
		Glist.add(king[0]);
		Glist.add(king[1]);
	}
	private LinkedList Glist = new LinkedList();
	public void dispatchPuke(Player p1,Player p2,Player p3){
		for(int i=0;i<17;i++){
		Random ran1=new Random();
		int n=ran1.nextInt(54-i);
		p1.Plist.add(Glist.get(n));
		Glist.remove(n);
		}
		for(int i=0;i<17;i++){
		System.out.println(p1.getName()+"的牌为"+p1.Plist.get(i));
		}
		
		for(int i=0;i<17;i++){
		Random ran2=new Random();
		int n2=ran2.nextInt(37-i);
		p2.Plist.add(Glist.get(n2));
		Glist.remove(n2);
		}
		for(int i=0;i<17;i++){
		System.out.println(p2.getName()+"的牌为"+p2.Plist.get(i));
		}
		
		for(int i=0;i<17;i++){
		Random ran3=new Random();
		int n3=ran3.nextInt(20-i);
		p3.Plist.add(Glist.get(n3));
		Glist.remove(n3);
		}
		for(int i=0;i<17;i++){
		System.out.println(p3.getName()+"的牌为"+p3.Plist.get(i));
		}
	}
}

