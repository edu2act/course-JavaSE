package puke;

import java.util.Random;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Game g= new Game();
		g.initPuke();
		Player p1=new Player();
		Player p2=new Player(); 
		Player p3=new Player();
		p1.setName("小王");
		p2.setName("小张");
		p3.setName("丽丽");
		g.dispatchPuke(p1,p2,p3);
	}
}
