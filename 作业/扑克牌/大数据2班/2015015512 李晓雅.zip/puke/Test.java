package puke;

public class Test {

	public static void main(String[] args) {
		Player players1 = new Player();
		Player players2 = new Player();
		Player players3 = new Player();
		Player[] players = { players1, players2, players3 };

		Game g = new Game();
		g.initPuke();
		g.dispatchPuke(players);
		g.show(players);

	}

}
