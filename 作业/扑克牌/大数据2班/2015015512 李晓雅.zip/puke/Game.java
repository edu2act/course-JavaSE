package puke;

import java.util.LinkedList;
import java.util.Random;

public class Game {
	private LinkedList<puke> list = new LinkedList<puke>();
	private String[] num = { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" };
	private String[] color = { "����", "����", "÷��", "����" };

	public void initPuke() {// ������
		puke puke1;
		for (int j = 0; j < 13; j++) {
			for (int k = 0; k < 4; k++) {
				puke1 = new puke(num[j], color[k]);
				list.add(puke1);
			}
		}
		list.add(new puke("0", "����"));
		list.add(new puke("0", "С��"));
	}

	public void dispatchPuke(Player players[]) {// ����
		Random ra = new Random();
		puke puke1;
		int i = 0;
		int j = 54;
		while (list.size() > 3) {
			puke1 = list.remove(ra.nextInt(j));
			players[i % 3].getList().add(puke1);
			i++;
			j--;
		}
		for (int k = 0; k < 3; k++) {
			puke1 = list.remove(0);
			players[0].getList().add(puke1);
		}
	}

	public void show(Player players[]) {
		for (int k = 0; k < 3; k++) {
			System.out.println(players[k].getList());
		}
	}
}
