package card_game;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.TreeSet;

public class Games {
	public static void main(String[] args){
		HashMap<Integer,String> hm = new HashMap<Integer,String>();
		ArrayList<Integer> al = new ArrayList<Integer>();
		String[] colors={"����","����","÷��","��Ƭ"};
		String[] numbers={"3","4","5","6","7","8","9","10","J","Q","K","A","2"};
		int count=0;
		for (String str1 : colors){
			for(String str2 : numbers){
				String s=str1=str2;
				hm.put(count,s);
				al.add(count);
				count++;
			}
			hm.put(count, "С��");
			al.add(count);
			count++;
			hm.put(count, "����");
			al.add(count);
			Collections.shuffle(al);
			TreeSet<Integer> dipai=new TreeSet<Integer>();
			TreeSet<Integer> zhangsan=new TreeSet<Integer>();
			TreeSet<Integer> lisi=new TreeSet<Integer>();
			TreeSet<Integer> wangwu=new TreeSet<Integer>();
			for(int i=0;i<al.size();i++){
				if(i>al.size()-4)
					dipai.add(al.get(i));
				else if(i%3==0)
					zhangsan.add(al.get(i));
				else if(i%3==1)
					lisi.add(al.get(i));
				else if(i%3==2)
					wangwu.add(al.get(i));
			}
			LookCards("����",zhangsan,hm);
			LookCards("����",lisi,hm);
			LookCards("����",wangwu,hm);
			LookCards("����",dipai,hm);
		}
	}

	private static void LookCards(String name, TreeSet<Integer> ts, HashMap<Integer, String> hm) {
		// TODO Auto-generated method stub
		System.out.print(name+"����:");
		for(Integer it:ts){
			System.out.print(hm.get(it)+" ");
		}
		System.out.println();
	}
}
