package List;

public class Puke {
	private String Color;
	private String Number;
	
	public Puke(String color, String number) {
		Color = color;
		Number = number;
	}
	public String getColor() {
		return Color;
	}
	public void setColor(String color) {
		Color = color;
	}
	public String getNumber() {
		return Number;
	}
	public void setNumber(String number) {
		Number = number;
	}
	
}
