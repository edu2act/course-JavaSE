package List;

import java.util.Collections;
import java.util.LinkedList;

public class Game {
	private LinkedList<Puke> PukeList;
	private int count=0;
	public Game() {
		PukeList = new LinkedList<Puke>();//一副扑克牌
		System.out.println("-------------------游戏开始-----------------");
	}
	public void BuildPukeList() {//创建一副牌
		
		String [] color ={"红桃","黑桃","梅花","方片"};
		String [] number = {"A","2","3","4","5","6","7","8","9","10","J","Q","K"};
		for(int i=0;i<color.length;i++) {
			for(int j=0;j<number.length;j++) {
				PukeList.add(new Puke(color[i],number[j]));
			}
		} 
		PukeList.add(new Puke("smallboss","small"));//插入小王
		PukeList.add(new Puke("bigboss","big"));//插入大王
	
	} 
	public void ShufflePuke() {
		System.out.println("-------------------开始洗牌-------------------");
		 Collections.shuffle(PukeList);
		 System.out.println("-------------------洗牌成功-------------------");
	}
	public void SendPuke(Player p) {//发牌
		p.addpuke(PukeList.removeFirst());
		count++;
	}
	public int count() {
		return count;
	}
}
