package List;

import java.util.LinkedList;

public class Player {
	private LinkedList<Puke> HandPuke;
	private String Name;
	private static int nextId=1;
	public Player() {
		Name = "player"+nextId;
		nextId++;
		HandPuke = new LinkedList<Puke>();
	}
	public Player(String name) {
		Name = name;
		HandPuke = new LinkedList<Puke>();
		System.out.println(Name+"登陆成功");
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Puke getpuke(int index) {
		
		return HandPuke.get(index);
	}
	public int getpukenumber() {
		return HandPuke.size();
	}
	public void addpuke(Puke p) {
		HandPuke.add(p);
	}
	
}
