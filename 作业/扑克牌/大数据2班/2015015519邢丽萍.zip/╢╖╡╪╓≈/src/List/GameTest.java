package List;

public class GameTest {

	public static void main(String[] args) {
		// TODO 自动生成的方法存根
		Game game = new Game();
		System.out.println("                        玩家载入中。。。");
		
		Player play1 = new Player("张涛");
		Player play2 = new Player("杨子强");
		Player play3 = new Player("陈佳峰");
		System.out.println();
 		game.BuildPukeList();//创建一副牌
 		System.out.println();
		game.ShufflePuke();//洗牌
		System.out.println("-------------------开始发牌-------------------");
		for(int i=0;i<17;i++) {
			game.SendPuke(play1);
			game.SendPuke(play2);
			game.SendPuke(play3);
		}
		System.out.println("-------------------发牌完成-------------------");
		System.out.println(play1.getName()+"手牌为");
		for(int i=0;i<play1.getpukenumber();i++) {
			if(play1.getpuke(i).getColor()=="smallboss") {
				System.out.println("小王");
			} else if(play1.getpuke(i).getColor()=="bigboss"){
				System.out.println("大王");
			}else {
				System.out.println(play1.getpuke(i).getColor()+play1.getpuke(i).getNumber());
			}	
		}
		System.out.println();
		System.out.println(play2.getName()+"手牌为");
		for(int i=0;i<play2.getpukenumber();i++) {
			if(play2.getpuke(i).getColor()=="smallboss") {
				System.out.println("小王");
			} else if(play2.getpuke(i).getColor()=="bigboss"){
				System.out.println("大王");
			}else {
				System.out.println(play2.getpuke(i).getColor()+play2.getpuke(i).getNumber());
			}	
		}
		System.out.println();
		System.out.println(play3.getName()+"手牌为");
		for(int i=0;i<play3.getpukenumber();i++) {
			if(play3.getpuke(i).getColor()=="smallboss") {
				System.out.println("小王");
			} else if(play3.getpuke(i).getColor()=="bigboss"){
				System.out.println("大王");
			}else {
				System.out.println(play3.getpuke(i).getColor()+play3.getpuke(i).getNumber());
			}	
		}
		System.out.println("-------------------抢地主阶段-------------------");
		
	}

}
