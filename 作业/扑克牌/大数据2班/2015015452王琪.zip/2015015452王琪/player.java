package card;

import java.util.*;

public class player {

	private String name;
	private int level;
	public LinkedList<icard> li = new LinkedList();
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public LinkedList<icard> getCard(){
		return li;
	}
	
}
