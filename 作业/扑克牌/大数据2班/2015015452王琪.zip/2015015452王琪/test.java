package card;

public class test {

	public static void main(String[] args) {
		game g = new game();
		g.init();
	}
	
}
