package puke;

import java.util.LinkedList;
import java.util.HashMap;
import java.util.Random;

public class Game {

	private LinkedList<Puke> list = new LinkedList<Puke>();
	String[] colors = { "梅花", "黑桃", "方块", "红桃" };
	String[] numbers = { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" };
	
	public void initPuke(){//初始化一副扑克牌
		for (int i = 0; i < 13; i++) {
			for (int j = 0; j < 4; j++) {
				Puke puke = new Puke(numbers[i], colors[j]);
				list.add(puke);
			}
		}
		list.add(new Puke("0", "大王"));
		list.add(new Puke("0", "小王"));
	}
	
	public void dispatchPuke(Player players[]){//发牌
		Random ra=new Random();
		Puke puke1;
		int i=0;
		int j=54;
		while(list.size()>3){
			puke1=list.remove(ra.nextInt(j));
			players[i%3].getList().add(puke1);
			i++;
			j--;
		}
		for(int k=0;k<3;k++){
			puke1=list.remove(0);
			players[0].getList().add(puke1);
		}
	}
	
	//显示牌
		public void show(Player players[]){
			for(int k=0;k<3;k++){
				System.out.println(players[k].getList());
			}
		}
}
