package demo;

public class Demo6 {
	public static void main(String[]args){
			Fish fish=new Fish("鱼");
			Dog dog=new Dog("狗");
			Fog fog=new Fog("青蛙");
			Person person=new Person();
			Food food =new Food();
			fish.eatFish(food);
			person.feed(fish, food);
			dog.eatDog(food);
			person.feed(dog, food);
			fog.eatFog(food);
			person.feed(fog, food);
		}
	}
	class Animal{
		public Animal(){
			
		}
		public Animal(String a){
			name=a;
		}
		public void eat(Food f){
		}
		public String name;
	}
	class Fish extends Animal{
		public Fish(String name){
			super.name=name;
		}
		public void eatFish(Food f){
			f.name="虾";
		}
	}
	class Dog extends Animal{
		public Dog(String name){
			super.name=name;
		}
		public void eatDog(Food f){
			f.name="肉";
		}
	}
	class Fog extends Animal{
		public Fog(String name){
			super.name=name;
		}
		public void eatFog(Food f){
			f.name="虫";
		}
	}
	class Food{
		public Food(){
			
		}
		public Food(String name){
			this.name=name;
		}
		public String name;
	}
	class Person{
		public void feed(Fish a,Food b){
			System.out.println(a.name+"吃"+b.name);
		}
		public void feed(Dog a,Food b){
			System.out.println(a.name+"吃"+b.name);
		}
		public void feed(Fog a,Food b){
			System.out.println(a.name+"吃"+b.name);
		}
	
	}
