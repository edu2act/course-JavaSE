package src;

public class TerAnimal extends Animal {
	public void jiao(){ 
		System.out.println("陆生动物都会叫");
		}
	//陆生动物都会跑
	public void pao(){
	System.out.println("陆生动物都会跑");
	}


}
