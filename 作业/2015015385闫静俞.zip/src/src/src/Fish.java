package src;

public class Fish extends AquAnimal{
public String name;
public Fish(){}
public Fish(String name){
 this.name = name;
}
//鱼会游泳
public void swim(){
System.out.println("鱼的姓名叫："+ this.name+"\n"+"游泳的时候是："+"鱼快游，鱼快游，鱼快游！！！"+"\n");
}
}
