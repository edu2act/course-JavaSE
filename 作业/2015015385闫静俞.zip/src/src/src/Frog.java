package src;

class Frog extends Animal implements Aqu,Ter{
public String name;
public Frog(){}
public Frog(String name){
 this.name = name;
}
//青蛙会游泳
public void swim(){
System.out.println("青蛙的姓名叫："+ this.name+"\n"+"游泳的时候是："+"青蛙游，青蛙游，青蛙游！！！"+"\n");
}
//青蛙会呱呱汪地叫
public void jiao(){
System.out.println("青蛙的姓名叫："+ this.name+"\n"+"叫的时候是："+"呱呱呱！！！"+"\n");
}
//青蛙也会跑
public void pao(){
System.out.println("青蛙的姓名叫："+ this.name+"\n"+"跑的时候是："+"青蛙跑，青蛙跑，青蛙跑！！！"+"\n");
}
}
