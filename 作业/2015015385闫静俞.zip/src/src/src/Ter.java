package src;

interface Ter{
public abstract void jiao();
public abstract void pao();
}
