package src;

public class Animal {
	
		public String name;
		public void swim(){}
		public void jiao(){}
		public void pao(){}
		

}
