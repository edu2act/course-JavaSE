package src;

public class Dog extends TerAnimal{ 
	
		public String name;
		public Dog(){}
		public Dog(String name){
		this.name = name;
		}
		//狗会汪汪汪地叫
		public void jiao(){
		System.out.println("狗的姓名叫："+ this.name+"\n"+"叫的时候是："+"汪汪汪!!!"+"\n");
		}
		//狗会跑
		public void pao(){
		System.out.println("狗的姓名叫："+ this.name+"\n"+"跑的时候是："+"快跑，快跑，快跑！！！"+"\n");
		}
		


}
