package src;



public class Test{
	public static void main(String[] args){
		Animal a = new Animal();
		//测试狗
		a = new Dog("二哈");
		a.jiao();
		a.pao();
		//分割符
		System.out.println("\n"+"---------------"+"\n");
		//测试鱼
		a = new Fish("尼莫");
		a.swim();
		//分割符
		System.out.println("\n"+"---------------"+"\n");
		//测试青蛙
		a = new Frog("兰戈");
		a.jiao();
		a.pao();
		a.swim();
		System.out.println("\n"+"---------------"+"\n");
	}
}
