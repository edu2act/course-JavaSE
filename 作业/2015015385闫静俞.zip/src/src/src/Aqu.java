package src;

public interface Aqu{
public abstract void swim();
}
