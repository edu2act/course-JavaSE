package src;

public class AquAnimal extends Animal {
	//水生动物都会游泳
	public void swim(){
	System.out.println("水生动物都会游泳");
	}
	


}
