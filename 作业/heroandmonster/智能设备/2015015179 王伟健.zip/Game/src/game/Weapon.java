package game;

public interface Weapon {
	int addNum=100;
	public int addAttackNum();
}


