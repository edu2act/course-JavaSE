package game;

public class Knife implements Weapon{
	@Override
	public int addAttackNum() {
	
		return addNum;
	}

}