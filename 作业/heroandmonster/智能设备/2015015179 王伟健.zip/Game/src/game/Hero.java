package game;

import java.util.Random;

public class Hero extends Person{
	public void attack(Person p){
		if(p.bloodCount>0){
			int down = new Random().nextInt(this.attackNum);
			p.bloodCount = p.bloodCount - down;
			System.out.println(p.name+"的血量还有"+p.bloodCount);
		} else{
			System.out.println("白骨精被杀死了！");
		}
	}
	public void attack(Person p,Knife k){
		if(p.bloodCount>0){
			int down=new Random().nextInt(this.attackNum);
			down+=k.addAttackNum();
			p.bloodCount=p.bloodCount -down;
			System.out.println(p.name+"的血量还有"+p.bloodCount);
		}else{
			System.out.println("白骨精被杀死了！");
		}
	}
}
