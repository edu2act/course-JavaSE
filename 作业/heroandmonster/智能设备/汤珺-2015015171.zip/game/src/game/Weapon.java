package game;

public abstract class Weapon {
		public abstract int addAttackNum();
}
