package game;

public  class Angel extends Person{
		public void reviveHero(Person p){
			if(p.bloodCount<=0){
				p.bloodCount=500;
			}
			System.out.println("奥特曼复活");
		}

		@Override
		public void attack(Person p) {
			// TODO Auto-generated method stub
			
		}
}
