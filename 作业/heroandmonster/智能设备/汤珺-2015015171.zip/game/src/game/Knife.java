package game;

public   class Knife extends Weapon{
			int addNum=10;
			public int addAttackNum( ){
				return addNum;
			};
			
}
