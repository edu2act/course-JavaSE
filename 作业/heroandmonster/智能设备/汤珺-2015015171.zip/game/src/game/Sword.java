package game;

public class Sword extends Weapon{
			int addNum=200;
			public int addAttackNum( ){
				return addNum;
			};
}
