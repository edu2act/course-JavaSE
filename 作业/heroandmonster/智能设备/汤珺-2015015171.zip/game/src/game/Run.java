package game;

public class Run {
	
	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		System.out.println("奥特曼打小怪兽");
		Hero hero=new Hero();
		Angel angel=new Angel();
		hero.name="奥特曼";
		hero.bloodCount=500;
		hero.level=1;
		hero.attackNum=100;
		
		Monster monster=new Monster();
		monster.name="哥斯拉";
		monster.attackNum=80;
		monster.bloodCount=700;
		monster.level=20;
		Weapon k= new Knife();
		Weapon m=new Sword();
		
		while(true){

			hero.attack(monster,k);
			
			if(monster.bloodCount<=0){
				System.out.println("您赢了");
				break;
			}
			
			monster.attack(hero);
			hero.addBlood(hero);
			hero.attack(monster, m);
			monster.attack(hero);
			if(hero.bloodCount<=0){
				System.out.println("您输了");
				break;
			}
		   angel.reviveHero(hero);
			
			try 
			{ 
			Thread.currentThread().sleep(1000);//毫秒 
			} 
			catch(Exception e){
				
			}
			
		}
		

	}

}
