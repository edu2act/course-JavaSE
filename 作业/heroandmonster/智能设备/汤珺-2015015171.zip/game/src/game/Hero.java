package game;

import java.util.Random;

public class Hero extends Person {
		public void attack (Person p){
			if(p.bloodCount>0){
				int down=new Random().nextInt(this.attackNum);
				p.bloodCount=p.bloodCount-down;
				System.out.println(p.name+"被攻击了"+down+"还剩下"+bloodCount);
			}
			
		}
		public void addBlood(Person p){
			if(p.bloodCount<=50){
				p.bloodCount=p.bloodCount+200;
				System.out.println(p.name+"加血"+p.name+"血量剩余"+p.bloodCount);
			}
		}
		public void attack(Person p, Weapon k){
			if(p.bloodCount>0){
				int down=new Random().nextInt(this.attackNum+ k.addAttackNum());
				p.bloodCount=p.bloodCount-down;
				System.out.println(p.name+"被攻击了"+down+"还剩下"+p.bloodCount);
			}
		}
		}

