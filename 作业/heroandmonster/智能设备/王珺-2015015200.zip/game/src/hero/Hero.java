package hero;

import java.util.Random;

public class Hero extends Person {

	public void attack(Person p) {
		if(p.bloodCount > 0) {
			int down = new Random().nextInt(this.attackNum);
			p.bloodCount = p.bloodCount - down;
			if(down >= 50) {
				this.bloodCount += 10;
			}
			System.out.print(p.name + "被攻击了" + down + "还剩下" + p.bloodCount);
			//若攻击怪兽的血量大于50，则捡到宝诶，血量增加
			System.out.print(this.name + "捡到宝物，血量增加了10" + "   ");
		}
	}

	public void attack(Person p, Weapon w) {
		if(p.bloodCount > 0) {
			int down = new Random().nextInt(this.attackNum + w.addAttackNum());
			p.bloodCount = p.bloodCount - down;
			System.out.print(p.name + "被攻击了" + down + "还剩下" + p.bloodCount + "   ");
			if(down >= 50) {
				int add = new Random().nextInt(50);
				this.bloodCount += add;
				//若攻击怪兽的血量大于50，则捡到宝诶，血量增加
				System.out.println(this.name + "捡到宝物，血量增加了" + add);
				
			}
			
			
		}
	}
}