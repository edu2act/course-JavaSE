package hero;

public class Knife extends Weapon {

	
	int attackNum = 10;
	
	@Override
	public int addAttackNum() {
		
		return attackNum;
	}

}