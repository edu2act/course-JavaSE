package hero;

public abstract class Person {

	public String name;
	public int attackNum;
	public int  bloodCount;
	public int level;
	
	public abstract void attack(Person p);
	
}
