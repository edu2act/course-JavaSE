package hero;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//定义超人
				Hero hero = new Hero();
				hero.name = "超人";
				hero.attackNum = 150;
				hero.bloodCount = 1000;
				hero.level = 1;
				
				//定义武器-小刀
				Weapon k = new Knife();
				
				//定义怪兽
				Monster monster = new Monster();
				monster.name = "哥斯拉";
				monster.attackNum = 100;
				monster.bloodCount = 2000;
				monster.level = 10;
				
				//互相攻击
				while(true) {
					
					//攻击怪兽
					hero.attack(monster, k);
					
					
					if(monster.bloodCount <= 0) {
						System.out.println("您赢了");
						break;
					}
					
					//攻击超人
					monster.attack(hero);
					
					
					if(hero.bloodCount <= 0) {
						System.out.println("您输了");
						break;
					}
					
					
				}
				
		
	}

}
