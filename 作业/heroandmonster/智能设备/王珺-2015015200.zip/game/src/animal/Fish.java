package animal;

public class Fish extends Animal implements Aquatic {
	
	//构造方法
	public Fish() {
		System.out.println("一条鱼");
	}
	
	//实现接口中的area方法
	public void area(){
		System.out.println("水生动物");
	}
	
	//重写父类eat方法
	public void eat(){
		System.out.println("食物：小鱼");
	}
	//重载eat方法
	public void eat(String a){
		System.out.println(a +"  " + "食物：鱼食");
	}
}
