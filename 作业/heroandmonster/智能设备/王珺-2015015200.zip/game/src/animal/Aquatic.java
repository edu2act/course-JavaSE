package animal;


//水生动物
interface Aquatic {

	public void area();
	
}
