package animal;

//陆生动物
interface Terrestrial {
	
	public abstract void voice();
	public abstract void fur();

}
