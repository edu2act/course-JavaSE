package animal;

public class Frog extends Animal implements Amphibbious {

	//构造方法
	public Frog(){
		System.out.println("一只青蛙");
	}
	
	//实现接口skin方法
	public void skin() {
		System.out.println("皮肤粗糙");
	}
	
	//实现父类
	public void eat(){
		System.out.println("食物：飞虫");
	}
	
}
