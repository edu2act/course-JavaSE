package animal;


//两栖动物
interface Amphibbious {

	public abstract void skin();
	
}
