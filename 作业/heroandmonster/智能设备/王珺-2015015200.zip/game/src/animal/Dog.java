package animal;

public class Dog extends Animal implements Terrestrial {
	
	//构造方法
	public Dog(){
		System.out.println("一条狗");
	}
	
	//实现接口方法
	public void voice() {
		System.out.println("声音：汪汪汪");
	}
	public void fur() {
		System.out.println("身上有毛");
	}
	
	//实现父类方法
	public void eat(){
		System.out.println("食物:骨头");
	}

}
