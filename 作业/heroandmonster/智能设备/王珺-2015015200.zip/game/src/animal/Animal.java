package animal;

public class Animal {
	
	private String name;
	private String species;
	private int age;
	
	//构造方法
	public Animal() {}
	public Animal(String name,String species) {
		this.name = name;
		this.species = species;
	}
	
	//name
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	
	//species
	public void setSpecies(String species) {
		this.species = species;
	}
	public String getSpecies() {
		return species;
	}
	
	//age
	public void setAge(int age) {
		this.age = age;
	}
	public int getAge() {
		return age;
	}

	//吃
	public void eat(){
		System.out.println("食物：肉");
	}
	
	//运动
	public void sport(String s) {
		System.out.println("行动方式：" + s);
	}
	
	//输出
	public void display() {
		System.out.println("名字：" + name 
				           + "   品种：" + species
				           + "    年龄" + age);
	}
	
}
