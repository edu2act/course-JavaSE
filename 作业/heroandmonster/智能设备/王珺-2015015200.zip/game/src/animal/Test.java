package animal;

public class Test {

	public static void main(String[] args) {
		
		Dog dog = new Dog();
		Fish fish = new Fish();
		Frog frog = new Frog();
		System.out.println();
		
		dog.setName("豆豆");
		dog.setSpecies("哈士奇");
		dog.setAge(3);
		dog.display();
		dog.voice();
		dog.fur();
		dog.eat();
		System.out.println();
		
		fish.setName("小鱼儿");
		fish.setSpecies("金鱼");
		fish.setAge(1);
		fish.display();
		fish.sport("swing");
		fish.area();
		fish.eat();
		fish.eat("家养小鱼");
		System.out.println();
		
		frog.setName("娃娃");
		frog.setSpecies("青蛙");
		frog.setAge(2);
		frog.display();
		frog.sport("jump");
		frog.skin();
		frog.eat();
		
		

	}

}
