package prof;

public class manger {

	public static void main(String[] args) {
		hero a = new hero();
		a.name="Ӣ��";
		a.baseAttack=300;
		a.bloodCount=2000;
		monster b = new monster();
		b.name="С����";
		b.baseAttack=400;
		b.bloodCount=1500;
		while(a.bloodCount>=0 && b.bloodCount>=0){
			a.attack(b);
			if(b.bloodCount<=0)
				break;
			b.attack(a);
			if(a.bloodCount<=0)
				break;
			
		}

	}

}
