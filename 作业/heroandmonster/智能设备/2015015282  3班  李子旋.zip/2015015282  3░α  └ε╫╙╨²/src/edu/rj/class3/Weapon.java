package edu.rj.class3;

public interface Weapon {
	public int addAttackNum();

}
