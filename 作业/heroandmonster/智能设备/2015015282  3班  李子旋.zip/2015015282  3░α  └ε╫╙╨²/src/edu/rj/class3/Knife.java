package edu.rj.class3;

public class Knife implements Weapon {
	int addNum = 10;

	public int addAttackNum() {
		return addNum;

	}

}
