package edu.rj.class3;

import java.util.Random;

public class Hero extends Person {

	public void attack(Person p) {
		if (p.bloodCount > 0) {
			int down = new Random().nextInt(this.attackNum);
			p.bloodCount = p.bloodCount - down;
			System.out.println(this.name+"攻击了"+p.name+"造成了"+down+"點傷害，"+p.name+"的生命值还剩"+p.bloodCount);
		}

	}

	public void attack (Person p, Weapon k){	
		if (p.bloodCount > 0) {
			int down = new Random().nextInt(this.attackNum);
			p.bloodCount = p.bloodCount - (down+k.addAttackNum());
			System.out.println(this.name+"攻击了"+p.name+"造成了"+down+"點傷害，"+p.name+"的生命值还剩"+p.bloodCount);
		}
	}
}
