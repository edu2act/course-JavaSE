package edu.rj.class3;

public class game {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hero hero = new Hero();
		hero.name = "WE";
		hero.attackNum = 100;
		hero.leval = 1;
		hero.bloodCount = 100;

		Manter manter = new Manter();
		manter.name = "哥斯拉";
		manter.attackNum = 10;
		manter.leval = 20;
		manter.bloodCount = 1000;

		Knife k = new Knife();
		while (true) {
			hero.attack(manter, k);

			if (manter.bloodCount <= 0) {
				System.out.println("你赢了!");
				break;
			}

			manter.attack(hero);

			if (hero.bloodCount <= 0) {
				System.out.println("你输了!");
				break;
			}

			try {
				Thread.sleep(1000);// 延缓
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
