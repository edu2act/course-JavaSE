package edu.rj.class3;

import java.util.Random;

public class Manter extends Person {

	public void attack(Person p) {
		if (p.bloodCount > 0) {
			int down = new Random().nextInt(this.attackNum);
			int skill = new Random().nextInt(4);
			if (skill == 1){
				p.bloodCount = p.bloodCount - 20;
				System.out.println(this.name+"發動了技能"+"造成了"+"20點傷害，"+p.name+"的生命值还剩"+p.bloodCount);
			}else{
				p.bloodCount = p.bloodCount - down;
				System.out.println(this.name+"攻击了"+p.name+"造成了"+down+"點傷害，"+p.name+"的生命值还剩"+p.bloodCount);
			}

		}

	}

}
