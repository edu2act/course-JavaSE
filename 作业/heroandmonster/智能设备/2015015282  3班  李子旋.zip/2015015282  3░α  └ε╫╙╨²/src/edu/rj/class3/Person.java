package edu.rj.class3;

public abstract class Person {
	public String name;
	public int bloodCount;
	public int leval;
	public int attackNum;
	
	public abstract void attack(Person p);
	
}
