package xiaoguaishou;

public class pao {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		yingxiong hero=new yingxiong();
		hero.name="英雄";
		hero.atkNum=100;
		hero.bloodC=100;
		hero.level=1;
		
		Weapon k=new knife();
		
		Monster monster = new Monster();
		monster.name = "怪兽";
		monster.bloodC=2000;
		monster.atkNum=20;
		monster.level=20;
		
		while(true){
			hero.attack(monster,k);
			monster.attack(hero);
			if(hero.bloodC <= 0){
				System.out.println("你输了");
				break;
			}
			if(monster.bloodC <= 0){
				System.out.println("你赢了");
				break;
			}
		}
		
		
	}

}
