package xiaoguaishou;

public abstract class xiaoguaishou {
	public String name;
	public int bloodC;
	public int level;
	public int atkNum;
	
	public abstract void attack(xiaoguaishou P);
}
