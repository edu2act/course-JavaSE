package xiaoguaishou;

public class knife implements Weapon {
	int addNum = 10;
	@Override
	public int addAttackNum(int addNum){
		return addNum;
	}



}
