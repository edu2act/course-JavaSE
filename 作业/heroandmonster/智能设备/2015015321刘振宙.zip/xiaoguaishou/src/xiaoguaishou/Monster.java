package xiaoguaishou;
import java.util.Random;

public class Monster extends xiaoguaishou {

	@Override
	public void attack(xiaoguaishou p) {
		// TODO Auto-generated method stub
		if(p.bloodC > 0) {
			int down = new Random().nextInt(this.atkNum);
			p.bloodC = p.bloodC - down;
			System.out.println(p.name+"被攻击了"+down+"还剩下"+p.bloodC);
		}
	}

}
