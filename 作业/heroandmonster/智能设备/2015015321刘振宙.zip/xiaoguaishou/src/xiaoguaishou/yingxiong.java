package xiaoguaishou;
import java.util.Random;

public class yingxiong extends xiaoguaishou {

	@Override
	public void attack(xiaoguaishou p) {
		if(p.bloodC > 0) {
			int down = new Random().nextInt(this.atkNum);
			p.bloodC = p.bloodC - down;
		}

	}
	public void attack(xiaoguaishou p,Weapon w) {
		if(p.bloodC > 0) {
			int down = new Random().nextInt(this.atkNum+w.addAttackNum(100));
			p.bloodC = p.bloodC - down;
			System.out.println(p.name+"被攻击了"+down+"还剩下"+p.bloodC);
		}
	}

}
