package xiaoguaishou;

public interface Weapon {
	public int addAttackNum(int addNum);
}
