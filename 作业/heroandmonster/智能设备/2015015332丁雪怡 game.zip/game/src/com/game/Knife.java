package com.game;

public class Knife extends Weapon{
	int addNum=30;
	public int addAttackNum(){
		return addNum;
	}

}
