package com.game;

import java.util.Random;

public class Moster extends Person{
	@Override
	public void attack(Person p) {
		// TODO Auto-generated method stub
		if(p.bloodCount>0){
			int down=new Random().nextInt(this.attackNum);
			p.bloodCount=p.bloodCount-down;
			System.out.println("英雄-"+down+"滴血");
		}
	}
}
