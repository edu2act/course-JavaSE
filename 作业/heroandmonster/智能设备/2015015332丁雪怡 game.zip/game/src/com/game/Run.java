package com.game;

public class Run {

	public static void main(String[] args) {
		Hero hero=new Hero();
		hero.name="超人";
		hero.attackNum=30;
		hero.bloodCount=1000;
		hero.level=1;
		Knife knife=new Knife();
		Moster moster=new Moster();
		moster.name="哥斯拉";
		moster.bloodCount=2000;
		moster.attackNum=5;
		moster.level=20;
		while(true){
			if(hero.bloodCount<=0){
				System.out.println("您输了，重来吧！");
				break;
			}
			if(moster.bloodCount<=0){
				System.out.println("您打赢了了，继续冒险吧！");
				break;
			}
			hero.attack(moster,knife);
			moster.attack(hero);
		}
	}

}
