package com.game;
import java.util.Random;

public class Hero extends Person{

	@Override
	public void attack(Person p) {
		if(p.bloodCount>0){
			int down=new Random().nextInt(this.attackNum);
			p.bloodCount=p.bloodCount-down;
			System.out.println("怪兽-"+down+"滴血");
		}
	}
	public void attack(Person p,Knife k){
		if(p.bloodCount>0){
			int down=new Random().nextInt(this.attackNum+k.addAttackNum());
			p.attackNum=p.attackNum+(10*down);
			p.bloodCount=p.bloodCount-p.attackNum;
			System.out.println("怪兽-"+down+"滴血");
		}
	}
}
