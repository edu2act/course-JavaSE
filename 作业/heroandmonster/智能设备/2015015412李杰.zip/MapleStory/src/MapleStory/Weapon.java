package MapleStory;

public class Weapon implements equipment {

	@Override
	
	public int addAttNum() {
		// TODO Auto-generated method stub
		return 20;
	}
	public int addDefNum() {
		// TODO Auto-generated method stub
		return 20;
	}
	

}
