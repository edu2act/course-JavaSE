  
public class Player {
	public static void Engage(){
		System.out.println("战斗开始");
	  
		new Player("悟空",200,50,10).Attack( new Player("妖怪",300,40,60));
	 

		System.out.println("战斗结束！");
	}
private String name;
private int hp;
private int damage;
private int armor;
public Player (String name,int hp,int damage,int armor){
	this.name=name;
	this.hp=hp;
	this.damage=damage;
	this.armor=armor;
}
public String GetName(){
	return this.name;
}
public void Attack(Player target){
	System.out.println(String.format("%1$s正在进攻%2$s",this.GetName(),target.GetName()));
	target.HurtFrom(this,this.damage);
}
public void CounterAttack(Player enemy){
	System.out.println(String.format("%1$s正在反击%2$s",this.GetName(),enemy.GetName()));
	this.Attack(enemy);
}
public void HurtFrom(Player enemy,int damage){
	int realdamage=damage-this.armor;
	this.hp=this.hp-realdamage;
	System.out.println(String.format("%1$s受到%2$s攻击，伤害%3$s,真实伤害%4$s,当前血量%5$s",this.GetName(),enemy.GetName(),damage,realdamage,this.hp));
	if(this.hp<0){
		System.out.println(String.format("%1$s已死亡",this.GetName()));
		return;
	}
	this.CounterAttack(enemy);
}
}
 



 
