package game;

public interface weapon {
	public  int addAttackNum(int addNum);
}
