package game;

public class run {

	public static void main(String[] args) {
		Littlezw hero=new Littlezw();
		hero.name="超级丹琦";
		hero.attackNum=200;
		hero.bloodCount=150;
		hero.level=1;
		
		guaishou monster=new guaishou();
		monster.name="怪兽子温";
		monster.bloodCount=2000;
		monster.attackNum=20;
		monster.level=20;
		
		Knife k = new Knife();
		
		while (true){
			hero.attack(monster,k);
			monster.attack(hero);
			
			if(hero.bloodCount<=0){
				System.out.println("你输了");
				break;
			}
			if(monster.bloodCount<=0){
				System.out.println("你赢了");
				break;
			}
		
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		
	}

}
