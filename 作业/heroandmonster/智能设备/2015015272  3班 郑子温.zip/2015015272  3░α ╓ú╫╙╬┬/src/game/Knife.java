package game;

public class Knife implements weapon{
	int addNum=800;
	public int addAttackNum(int addNum) {
		// TODO Auto-generated method stub
		return addNum;
	}


}
