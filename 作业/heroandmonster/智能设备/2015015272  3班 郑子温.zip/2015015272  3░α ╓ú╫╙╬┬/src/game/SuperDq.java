package game;

public abstract class SuperDq {
	public String name;
	public int bloodCount;
	public int level;
	public int attackNum;
	
	public abstract void attack (SuperDq p);
	
}
