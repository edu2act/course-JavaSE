package game;

import java.util.Random;

public class Littlezw extends SuperDq {

	public void attack (SuperDq p){
		if(p.bloodCount>0){
			int down = new Random().nextInt(this.attackNum);
			p.bloodCount=p.bloodCount-down;
			System.out.println(p.name+"被攻击了"+down+",生命值还剩"+p.bloodCount);
		}
	}
	public void attack (SuperDq p,Knife k){
		if(p.bloodCount>0){
			int down = new Random().nextInt(this.attackNum);
			p.bloodCount=p.bloodCount-down;
			System.out.println(p.name+"被攻击了"+down+",生命值还剩"+p.bloodCount);
		}
	}
}
