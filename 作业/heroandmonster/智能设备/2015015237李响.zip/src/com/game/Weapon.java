package com.game;

public interface Weapon {
	
	public int addAttackNum();

}
