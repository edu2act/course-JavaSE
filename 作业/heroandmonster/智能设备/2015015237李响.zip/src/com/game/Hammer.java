package com.game;

public class Hammer implements Weapon{
	
	int addNum=99;
	public int addAttackNum(){
		return addNum;
	}

}
