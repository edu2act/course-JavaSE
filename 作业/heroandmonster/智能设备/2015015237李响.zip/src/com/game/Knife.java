package com.game;

public class Knife implements Weapon {
	
	int addNum=100;
	public int addAttackNum(){
		return addNum;
	}

}
