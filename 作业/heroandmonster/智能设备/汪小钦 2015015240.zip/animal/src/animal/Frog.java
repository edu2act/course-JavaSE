package animal;

public class Frog extends Animal implements LandAnimals,WaterAnimals {
	public Frog(){
		System.out.println("青蛙是动物");
	}
	@Override
	public void waterAnimals() {
		// TODO Auto-generated method stub
		System.out.println("青蛙是水生动物");
	}

	@Override
	public void landAnimals() {
		// TODO Auto-generated method stub
		System.out.println("青蛙是陆生动物");
	}

	@Override
	void sayHello() {
		// TODO Auto-generated method stub
		System.out.println("青蛙会“呱呱”叫。");
	}

	@Override
	void sayHello(int statevar) {
		// TODO Auto-generated method stub
		this.setState(statevar);
		if(this.state==1){
			System.out.println("青蛙会发出“呱呱”叫声");
		}else{
			if(this.state==0){
				System.out.println("青蛙会在雨后天气发出“哇哇”的叫声。");
			}
		}
	}

}
