package animal;

public class AnimalTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("----Dog----");
		Dog dog=new Dog();
		dog.landAnimals();
		dog.sayHello();
		dog.sayHello(1);
		dog.sayHello(0);
		System.out.println("----Cat----");
		Cat cat=new Cat();
		cat.landAnimals();
		cat.sayHello();
		cat.sayHello(1);
		cat.sayHello(0);
		System.out.println("----Frog----");
		Frog frog=new Frog();
		frog.landAnimals();
		frog.sayHello();
		frog.sayHello(1);
		frog.sayHello(0);
		
	}

}
