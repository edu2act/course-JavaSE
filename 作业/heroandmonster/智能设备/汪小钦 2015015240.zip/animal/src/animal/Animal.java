package animal;
//定义陆生接口
interface LandAnimals{
	void landAnimals();
}
//定义水生接口
interface WaterAnimals{
	void waterAnimals();
}
abstract class Animal{
	int  state=1;
	public void setState(int n){
		state=n;
	}
	public int getState(){
		return state;
	}
	abstract void sayHello();
	abstract void sayHello(int statevar);
}