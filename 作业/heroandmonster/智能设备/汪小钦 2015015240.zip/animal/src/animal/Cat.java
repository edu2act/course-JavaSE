package animal;

public class Cat extends Animal implements LandAnimals{
	public  Cat(){
		System.out.println("猫是动物。");
	}
	public void landAnimals(){
		System.out.println("猫是陆生动物。");
	}
	@Override
	public void sayHello() {
		// TODO Auto-generated method stub
		System.out.println("猫会“喵喵”叫");
	}
	@Override
	public void sayHello(int statevar) {
		// TODO Auto-generated method stub
		this.setState(statevar);
		if(this.state==1){
			System.out.println("猫见到熟悉人会摇头排尾");
		}else{
			if(this.state==0){
				System.out.println("猫见到陌生人会“喵喵”叫");
			}
		}
		
	}
}
