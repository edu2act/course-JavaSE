package game;

public interface Wepon {

	public int addAttackNum();
}