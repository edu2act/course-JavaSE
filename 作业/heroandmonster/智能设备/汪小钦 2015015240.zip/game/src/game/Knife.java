package game;
//Knife
public class Knife implements Wepon {
	
	int addNum=10;
	public int addAttackNum(){
		return addNum;
	}

	

}
