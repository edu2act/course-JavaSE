package game;
//Run
public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hero hero=new Hero();
		hero.name="奥特曼";
		hero.attackNum=100;
		hero.bloodCount=200;
		hero.level=10;
		Wepon k=new Knife();
		Monster monster=new Monster();
		monster.name="小怪兽";
		monster.bloodCount=600;
		monster.attackNum=20;
		monster.level=20;
		
		
		
		while(true){
			hero.attack(monster,k);
			monster.attack(hero);
			if(hero.bloodCount<=0){
				System.out.println("Game Over!");
				break;
			}
			if(monster.bloodCount<=0){
				System.out.println("晋级成功，继续冒险!");
				break;
			}
			try{
				Thread .sleep(1500);
			}catch(Exception e){
				
			}
			
		}
		
	}

}

