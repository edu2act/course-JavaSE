package game;

import java.util.Random;
//hero
public class Hero extends Person {
	
	public void attack(Person p){
		if(p.bloodCount>0){
			int down=new Random().nextInt(this.attackNum);
			p.bloodCount=p.bloodCount-down;
			System.out.println(p.name+"被打掉"+down+",还剩下"+p.bloodCount);

		}
	}
	public void attack(Person p,Wepon w){
		if(p.bloodCount>0){
			int down=new Random().nextInt(this.attackNum+w.addAttackNum());
			p.bloodCount=p.bloodCount-down;
			System.out.println(p.name+"被打掉"+down+",还剩下"+p.bloodCount);
		}
	}
}
		

