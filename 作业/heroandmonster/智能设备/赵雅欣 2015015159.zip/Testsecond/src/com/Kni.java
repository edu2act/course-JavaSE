package com;

public abstract class Kni  {
	public abstract int addAttackNum ();

	
}

