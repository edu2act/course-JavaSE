package test1;
/*
 * 工具类接口
 * 用于各种工具的继承
 */
public abstract class  gongju {
	public abstract int addAttackNum();
}
