package test1;
/*
 * 继承自person类
 * 完成了attack方法的定义
 */
import java.util.Random;

public class hero extends person {
	public hero(){
	}
	public hero(String a,int b,int c,int d){
		name=a;
		bloodCount=b;
		level=c;
		attackNum=d;
	}
	public void attack(person p,gongju a){
		if(p.bloodCount>0){
			int down=new Random().nextInt(this.attackNum+a.addAttackNum());
			p.bloodCount=p.bloodCount-down;
			System.out.println("英雄打了怪兽一下，掉血量是："+down+"    怪兽还剩血量为："+p.bloodCount);
		}
			
	
	}
	
}
