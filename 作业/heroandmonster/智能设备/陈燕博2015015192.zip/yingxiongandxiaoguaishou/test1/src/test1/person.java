package test1;
/*用于英雄类和怪兽的继承
 * 定义了姓名，血量，级别和打击的掉血量
 * 定义了打击的功能
 */
public abstract class person {
	public String name;
	public int bloodCount;
	public int level;
	public int attackNum;
	public abstract void attack(person p,gongju a);
}
