package test1;
/*
 * 继承自person类
 * 完成了对attack方法的定义
 */
import java.util.Random;

public class moster extends person {
	public moster(){
	}
	public moster(String a,int b,int c,int d){
		name=a;
		bloodCount=b;
		level=c;
		attackNum=d;
	}
	public void attack(person p,gongju a){
		if(p.bloodCount>0){
			int down=new Random().nextInt(this.attackNum+a.addAttackNum());
			p.bloodCount=p.bloodCount-down;
			System.out.println("怪兽打了英雄一下，掉血量是："+down+"   英雄还剩血量为："+p.bloodCount);
		}
	
	}
}
