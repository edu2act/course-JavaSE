package test1;
/*
 * 用于测试该游戏
 */
public class test {

	public static void main(String[] args) {
		
		hero superman=new hero("superman",100,1,10);
		moster monster=new moster("monster",150,5,22);
		knife xiaoDao=new knife();
		handgun handGun=new handgun();
		while(true){
			superman.attack(monster,handGun);
			monster.attack(superman,xiaoDao);
			if(monster.bloodCount<0||superman.bloodCount<0){
				break;
			}
			
		}
		if(monster.bloodCount>0){
			System.out.println("你输了，重新挑战吧");
		}else{
			System.out.println("你赢了，继续冒险吧");
		}
	}

}
