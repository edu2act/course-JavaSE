package test1;
/*
 * 手枪类
 * 继承自工具类
 */
public class handgun extends gongju{
	int a=20;
	public int addAttackNum(){
		return a;
	}
}
