package test1;
/*
 * 小刀类，继承自工具类
 */
public  class  knife extends gongju{
	int a=10;
	public int addAttackNum(){
		return a;
	}
}
