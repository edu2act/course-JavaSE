
public class Run {

	public static void main(String[] args) throws InterruptedException {
		Knife k=new Knife();
		Hero hero = new Hero();
		hero.name = "英雄";
		hero.bloodCount = 100;
		hero.level = 1;
		hero.attackNum = 50;

		Monster monster = new Monster();
		monster.name = "怪兽";
		monster.bloodCount = 500;
		monster.level = 1;
		monster.attackNum = 10;

		while (true) {
			Thread.sleep(1000);
			hero.attack(monster,k);
			monster.attack(hero);
			if (hero.bloodCount <= 0) {
				System.out.println("怪兽赢了");
				break;
			}
			if (monster.bloodCount <= 0) {
				System.out.println("英雄赢了");
				break;
			}
		}

	}

}
