
public class Knife implements Wuqi {
	
	public int addAttackNum() {
		return addNum;
	}

}
