package zoo;
//定义蛤蟆类 继承动物类  实现陆生 水生两个接口
public class Frog extends Animals implements EarthLife, WaterLife {

	//重写接口中的行为
	public void warm() {
		// TODO Auto-generated method stub
		System.out.println(this.name+"像鱼一样游");
	}

	//重写接口中的行为
	public void run() {
		// TODO Auto-generated method stub
		System.out.println(this.name+"像狗一样奔跑");
	}

	//重写父类中的行为
	public void shout() {
		// TODO Auto-generated method stub
		System.out.println(this.name+"说呱呱呱");
	}

}
