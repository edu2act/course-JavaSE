package zoo;
/*
 * 测试
 * 
 * */
public class Test {
	public static void main(String[] args){
		Dog a = new Dog();//实例化对象狗
		a.name ="旺财";
		Fish b = new Fish();//实例化对象鱼
		b.name ="尼莫";
		Frog c= new Frog();//实例化对象蛤蟆
		c.name  = "长大的小蝌蚪";
		a.run();
		a.shout();
		b.shout();
		b.warm();
		c.run();
		c.shout();
		c.warm();
		
	}
}
