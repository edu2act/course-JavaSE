package zoo;
//定义狗类  继承抽象类动物 实现接口陆生
public class Dog extends Animals implements EarthLife {
	
	
	//重写接口中的行为
	public void run() {
		// TODO Auto-generated method stub
		System.out.println(this.name+"正在跑");

	}

	//重写父类中的行为
	public void shout() {
		// TODO Auto-generated method stub
		System.out.println(this.name+"说汪汪汪");
	}

}
