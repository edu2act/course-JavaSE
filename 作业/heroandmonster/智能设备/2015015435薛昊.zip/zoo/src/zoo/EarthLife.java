package zoo;
//定义接口陆生动物
public interface EarthLife {
	void run();
}
