package zoo;
//定义鱼类  继承抽象类动物 实现接口水生
public class Fish extends Animals implements WaterLife {

	//重写接口中的行为
	public void warm() {
		// TODO Auto-generated method stub
		System.out.println(this.name+"正在游");
	}
	//重写父类中的行为
	public void shout() {
		// TODO Auto-generated method stub
		System.out.println(this.name+"说“你傻呀，我是一条鱼，不会叫”");
	}

}
