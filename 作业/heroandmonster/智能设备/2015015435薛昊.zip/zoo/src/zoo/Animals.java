package zoo;
//定义抽象类 Animals 抽象行为 shout
public abstract class Animals {
	public String name;
	public abstract void shout();
}
