package zoo;
//定义接口 水生动物
public interface WaterLife {
	void warm();
}
