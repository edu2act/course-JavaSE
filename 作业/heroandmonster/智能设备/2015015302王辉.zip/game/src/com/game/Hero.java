package com.game;

import java.util.Random;

public class Hero extends Preson {

	public void attack(Preson p) {
		if(p.bloodCount > 0) {
			int down = new Random().nextInt(this.attackNum);
			p.bloodCount = p.bloodCount - down;
		}
	}
	public void attack(Preson p,Knife k) {
		if(p.bloodCount > 0) {
			int down = new Random().nextInt(this.attackNum + k.addAttackNum(k.addNum));
			p.bloodCount = p.bloodCount - down;
		}
	}
}
