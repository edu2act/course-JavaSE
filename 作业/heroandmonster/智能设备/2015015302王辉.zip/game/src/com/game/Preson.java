package com.game;

public abstract class Preson {

	public String name;
	public int bloodCount;
	public int level;
	public int attackNum;
	
	public abstract void attack(Preson p);
}
