package com.game;

public class Knife implements weapon{
	int addNum = 10;

	public int addAttackNum(int addNum) {
		return addNum;
	}
}