package com.game;

public class Run {

	public static void main(String[] args) {
		
		Hero hero = new Hero();
		hero.name = "超人";
		hero.attackNum = 100;
		hero.bloodCount = 100;
		hero.level = 1;
		
		Monster monster = new Monster();
		monster.name = "怪兽";
		monster.attackNum = 20;
		monster.bloodCount = 500;
		monster.level = 10;
		
		while (hero.bloodCount > 0 && monster.bloodCount > 0) {
			hero.attack(monster);
			if (monster.bloodCount >=0) {
				System.out.println("怪兽剩余血量：" + monster.bloodCount);
			} else {
				System.out.println("怪兽剩余血量：0，怪兽被击毙");
			}
			if(monster.bloodCount > 0) {
				monster.attack(hero);
				if (hero.bloodCount >= 0) {
					System.out.println("英雄剩余血量：" + hero.bloodCount);
				} else {
					System.out.println("英雄剩余血量：0，英雄被击毙");
				}
			}
		}
	}

}
