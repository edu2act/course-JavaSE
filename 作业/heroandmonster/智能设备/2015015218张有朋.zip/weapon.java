package com.game;

public interface weapon {
	public int addAttack();
}
