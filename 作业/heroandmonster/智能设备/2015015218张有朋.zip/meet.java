package com.game;

public class meet {

	public static void main(String[] args) {
		hero p = new hero("ez",100,100,45);
		monster m =new monster("提莫",200,100,20);
		sword s = new sword();
		while(true){
			p.attack(m,s);
			m.attack(p);
			if(p.bloodCount<=0){
				System.out.println("game over!");
				break;
			}
			if(m.bloodCount<=0){
				System.out.println("you win!");
				break;
			}
		}
		

	}

}
