package com.game;

import java.util.Random;

public class monster extends person {
	monster(String n, int b, int l, int a) {
		super(n, b, l, a);
		// TODO 自动生成的构造函数存根
	}

	public void attack(person p){
		if(p.bloodCount > 0){
			int down = new Random().nextInt(this.attackNum);
			p.bloodCount = p.bloodCount - down;
		}
	}
	 
	public void attack(monster m){
		if(m.bloodCount > 0){
			int down = new Random().nextInt(this.attackNum);
			m.bloodCount = m.bloodCount - down;
		}
	}
}
