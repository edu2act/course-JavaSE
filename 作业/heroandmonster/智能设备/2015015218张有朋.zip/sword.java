package com.game;

public class sword implements weapon {
	public int addAttack(){
		int addNum = 5;
		return addNum;
	}
}
