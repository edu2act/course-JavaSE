package com.game;

public abstract class person {
	public String name;
	public int bloodCount;
	public int level;
	public int attackNum;
	person(String n,int b,int l,int a){
		this.name = n;
		this.bloodCount = b;
		this.level = l;
		this.attackNum =a;
	}
	public abstract void attack(person p);
	
}
