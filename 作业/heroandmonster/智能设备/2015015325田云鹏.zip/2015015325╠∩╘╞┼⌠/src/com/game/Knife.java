package com.game;

public class Knife implements Weapon {
	int addNum = 10;
	@Override
	public int addAttackNum(int addNum){
		return addNum;
	}



}