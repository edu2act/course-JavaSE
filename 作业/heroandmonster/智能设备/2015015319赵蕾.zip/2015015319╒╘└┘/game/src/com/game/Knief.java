package com.game;

public class Knief extends Weapon{
	public int addAttackNum(int addNum) {
		return addNum;
	}
}
