package com.game;

import java.util.Random;

public class Hero extends person {
	public void attack(person p) {
		if(p.bloodCount>0) {
			int down = new Random().nextInt(this.attackNum);
			p.bloodCount=p.bloodCount-down;
		}
		System.out.println(p.name+"攻击了："+p.attackNum+",剩余的血量："+p.bloodCount);
	}
	public void attack(person p,Weapon w) {
		if(p.bloodCount>0) {
			int down = new Random().nextInt(this.attackNum+w.addAttackNum(100));
			p.bloodCount=p.bloodCount-down;
		}
		System.out.println(p.name+"攻击了："+p.attackNum+",剩余的血量："+p.bloodCount);
	}
}
