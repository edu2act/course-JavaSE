package com.game;

public abstract class Weapon {
	
	public abstract int addAttackNum(int addNum);
	
}
