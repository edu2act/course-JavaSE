package text;

import java.util.Random;

public class Hero extends Person {
	
	public Hero() {
		super();
	}

	public void attack(Person p){
		if(p.hp>0){
			int down=new Random().nextInt(this.attackNum);
			p.hp = p.hp - down;
			if(p.hp<0){
				p.hp = 0;
			}
			System.out.println(name+"��"+p.name+"�����"+down+"���˺���"+name+"��ʣ��"+hp+"Ѫ,"+p.name+"��ʣ��"+p.hp+"Ѫ");
		}
	}
	
//	public void attack(Person p,Weapon w){
//		if(p.hp>0){
//			int down=new Random().nextInt(this.attackNum + w.addAttackNum());
//			p.hp = p.hp - down;
//		}
//	}
}
