package text;

public class Gun implements Weapon{
	public int addAttackNum(){
		return 10;
	}
}
