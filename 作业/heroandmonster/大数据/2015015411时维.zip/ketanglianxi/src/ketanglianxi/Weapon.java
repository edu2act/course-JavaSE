package ketanglianxi;

public interface Weapon {
public int addAttackNum();
}





