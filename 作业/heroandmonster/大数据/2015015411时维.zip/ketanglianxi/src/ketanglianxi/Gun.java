package ketanglianxi;

public class Gun {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
