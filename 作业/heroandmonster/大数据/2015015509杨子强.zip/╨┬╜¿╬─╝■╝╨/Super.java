package tramandozenmonster;

import java.util.Random;

public class Super extends Person  {

	Super(){}
	Super(String name){
		this.name = name;
	}
	Super(String name, int attackNum, int blood){
		this.name = name;
		this.attackNum =attackNum;
		this.blood = blood;
	}
	public void attack(Person p) {
		if(p.blood>0){
			int b= new Random().nextInt(this.attackNum);
			p.blood-=b;
			System.out.println(name+"���ڴ�"+p.name+","+name+"����"+p.name+ b+"Ѫ"+","+p.name+"ʣ��"+p.blood);
		}
	}
	
	public void attack(Person p, Weapons w){
		if(p.blood>0){
			int b= new Random().nextInt(this.attackNum+w.addattackNum());
			p.blood-=b;
			System.out.println(name+"���ڴ�"+p.name+","+name+"����"+p.name+ b+"Ѫ"+","+p.name+"ʣ��"+p.blood);
		}
	}



	
}
