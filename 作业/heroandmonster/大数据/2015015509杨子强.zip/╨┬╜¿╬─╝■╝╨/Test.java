package tramandozenmonster;


public class Test {

	public static void main(String[] args) {
		
		Super s = new Super("me",20,100);
		Monster m = new Monster("bo",15,100);
		while(true){
			s.attack(m);
			m.attack(s);
			if(m.blood<=0){
				System.out.println(s.name+"��ʤ");
				break;
			}
			if(s.blood<=0){
				System.out.println(m.name+"��ʤ");
				break;
			}
			
			
		}

	}

}

