package tramandozenmonster;

public interface Weapons {
	public abstract int addattackNum();
}
