package tramandozenmonster;

import java.util.Random;

public class Monster extends Person {

	Monster(){};
	Monster(String name){
		this.name = name;
	}
	Monster(String name, int attackNum, int blood){
		this.name = name;
		this.attackNum =attackNum;
		this.blood = blood;
	}
	@Override
	public void attack(Person p) {
		if(p.blood>0){
			int b = new Random().nextInt(this.attackNum);
			p.blood-=b;
			System.out.println(name+"���ڴ�"+p.name+","+name+"����"+p.name+ b+"Ѫ"+","+p.name+"ʣ��"+p.blood);
		}
		
	}
	
	
	

}
