package tramandozenmonster;

import java.util.Random;

public class Gun implements Weapons{

	@Override
	public int addattackNum() {
		
		return (new Random().nextInt(20)) ;
	}

}
