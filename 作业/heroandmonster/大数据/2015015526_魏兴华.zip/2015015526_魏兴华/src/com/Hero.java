package com;

import java.util.Random;

public class Hero extends Person{
	
	public void attack(Person p) {
		if(p.hp>0){
			int down = new Random().nextInt(this.attackNum);
			p.hp = p.hp - this.attackNum;
		}

	}
	
	public void attack(Person p,Weapon w) {
		if(p.hp>0){
			int down = new Random().nextInt(this.attackNum+w.addAttackNum());
			p.hp = p.hp - this.attackNum;
		}

	}

}
