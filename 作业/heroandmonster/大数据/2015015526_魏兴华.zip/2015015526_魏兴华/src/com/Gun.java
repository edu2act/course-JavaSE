package com;

public class Gun implements Weapon {

	@Override
	public int addAttackNum() {
		return 100;//攻击值
	}

}
