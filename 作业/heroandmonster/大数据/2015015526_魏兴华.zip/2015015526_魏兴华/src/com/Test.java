package com;

public class Test {

	public static void main(String[] args) {
		Hero h = new Hero();
		h.name = "奥特曼";
		h.level = 10;
		h.hp = 200;
		h.attackNum = 10;
		
		Weapon w = new Gun();
		
		Monster m = new Monster();
		m.name = "哥斯拉";
		m.level = 10;
		m.hp = 100;
		m.attackNum = 10;
		
		while((h.hp >= 0)&&(m.hp >= 0)){
			h.attack(m,w);
			m.attack(h);
			if(h.hp <= 0){
				System.out.println("您输了，重新来吧");
				break;
			}
			
			if(m.hp <= 0){
				System.out.println("您赢了，继续吧");
			}
		}
		
		
		
	}

}
