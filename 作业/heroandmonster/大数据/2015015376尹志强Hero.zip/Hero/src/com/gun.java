package com;
 class gun implements Weapon{
		public int addAttackNum(){
			int addattack=50;
			return addattack;
		}
	}
