package com;
import java.util.Random;
public class hero extends Person {
	public void attack (Person p){
		if(p.hp>0){
			int down=new Random().nextInt(this.attckNum);
			p.hp=p.hp-down;
		}
	}
	public void attack (Person p,Weapon g){//��������
		if(p.hp>0){
			int down=new Random().nextInt(this.attckNum+g.addAttackNum());
			p.hp=p.hp-down;
			System.out.println(p.name+"����������"+down+"Ѫ��");
		}
	}
}
