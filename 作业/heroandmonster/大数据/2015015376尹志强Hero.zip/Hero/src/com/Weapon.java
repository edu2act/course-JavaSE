package com;

public interface Weapon {
	public int addAttackNum();
}
