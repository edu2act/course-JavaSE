package text;

import java.util.Random;
/**
 * 
 * 
 * @author lenovo
 *
 */
public class Monster extends Person{
	public void attack(Person p){
		if(p.hp>0){
			int dom=new Random().nextInt(this.attackNum);
			p.hp=p.hp-dom;
			System.out.println("mmmm");
		}
	}
}
