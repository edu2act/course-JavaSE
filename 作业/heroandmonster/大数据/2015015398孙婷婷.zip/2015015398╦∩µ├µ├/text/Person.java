package text;

public abstract class Person {
	public String name;
	public int level;
	public int hp;
	public int attackNum;
	public abstract void attack(Person p);
	
}
