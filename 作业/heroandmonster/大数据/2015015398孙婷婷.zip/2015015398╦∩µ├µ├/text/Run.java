package text;

public class Run {
	public static void main(String[] args) throws InterruptedException{
		Hero h=new Hero();
		h.name="超人";
		h.hp=200;
		h.level=1;
		h.attackNum=20;
		Monster m = new Monster();
		m.name="哥斯拉";
		m.hp=300;
		m.level=10;
		m.attackNum=25;
		Weapon w=new Gun();
		
		
		while(true){
			h.attack(m);
			m.attack(h);
			if(h.hp<=0){
				System.out.println("vvvvv");
				break;
			}
			if(m.hp<=0){
				System.out.println("m111111mmmm");
				break;
			}
			
			Thread.sleep(3000);//休眠3秒
		}
	}
}
