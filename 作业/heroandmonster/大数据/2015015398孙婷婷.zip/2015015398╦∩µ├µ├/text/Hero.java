package text;

import java.util.Random;
/**
 * 
 * @author lenovo
 *
 */

public class Hero extends Person{
	public void attack(Person p){
		if(p.hp>0){
			int dom=new Random().nextInt(this.attackNum);
			p.hp=p.hp-dom;
		}
	}
	public void attack(Person p,Weapon w){
		if(p.hp>0){
			int dom=new Random().nextInt(this.attackNum+w.addAttackNum());
			p.hp=p.hp-dom;
			System.out.println("hhhh");
		}
	}
}
