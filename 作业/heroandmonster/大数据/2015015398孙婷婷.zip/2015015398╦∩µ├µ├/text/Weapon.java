package text;

public interface Weapon {
	public int addAttackNum();
}
