package text;

public class Gun implements Weapon{
	int addNum=30;
	public int addAttackNum(){
		return addNum;
	}
}
