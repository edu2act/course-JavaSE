package com.game;

public interface equip {
	public int adddefense();
}
