package MapleStory;

import java.util.Random;

public class people {
	
	public String name;
	public int HP;
	public int attNum;
	public int defNum;
	public int level;
	public int agile;
	
	public people(){}
	
	public people(String name){
		this.name = name;
	}
	
	public people(String name ,int HP ,int attNum ,int defNum ,int level,int agile){
		this.name = name;
		this.HP = HP;
		this.attNum = attNum;
		this.defNum = defNum;
		this.level = level;
		this.agile = agile;
	}
	
	public void attack(people p){
		if(p.HP>0){
			int hurt;
			hurt = new Random().nextInt(this.attNum);
			p.HP = p.HP - hurt;
		}
	}
	
	public void addLevel(people p){
		p.attNum = p.attNum + new Random().nextInt(10);
		p.defNum = p.defNum + new Random().nextInt(10);
		p.agile = p.agile + new Random().nextInt(10);
		p.level = p.level + 1;
	}
	
	public int getAgile() {
		return agile;
	}

	public void setAgile(int agile) {
		this.agile = agile;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getHP() {
		return HP;
	}

	public void setHP(int hP) {
		HP = hP;
	}

	public int getAttNum() {
		return attNum;
	}

	public void setAttNum(int attNum) {
		this.attNum = attNum;
	}

	public int getDefNum() {
		return defNum;
	}

	public void setDefNum(int defNum) {
		this.defNum = defNum;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}
	
	
}
