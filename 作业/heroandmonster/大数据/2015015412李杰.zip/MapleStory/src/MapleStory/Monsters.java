package MapleStory;

import java.util.Random;

public class Monsters extends people {
	
	public Monsters(){}
	
	public Monsters(String name){
		this.name = name;
	}
	
	public Monsters(String name,int HP,int attNum,int defNum,int level,int agile){
		this.name = name;
		this.HP = HP;
		this.attNum = attNum;
		this.defNum = defNum;
		this.level = level;
		this.agile = agile;
	}
	
	public void attack(people p){
		if(p.HP>0){
			int hurt;
			hurt = new Random().nextInt(this.attNum);
			if(hurt>p.defNum) {
				p.HP = p.HP - (hurt - p.defNum);
				System.out.println(p.name+"���������ܵ���"+(hurt - p.defNum)+"���˺�");
			} else {
				System.out.println("С��죺You still have lots more to work on !");
			}
		}
	}
	
}
