package MapleStory;

import java.util.Random;

public class Hero extends people {
	

	private int equip;
	
	public Hero(){}
	
	public Hero(int equip){
		this.equip = equip;
	}
	
	public Hero(String name,int HP,int attNum,int defNum,int level,int equip,int agile){
		this.name = name;
		this.HP = HP;
		this.attNum = attNum;
		this.defNum = defNum;
		this.level = level;
		this.equip = equip;
		this.agile = agile;
	}
	
	public void attack(people p){
		if(p.HP>0){
			int hurt;
			hurt = new Random().nextInt(this.attNum);
			if(hurt>p.defNum) {
				p.HP = p.HP - (hurt - p.defNum);
				System.out.println(p.name+"���������ܵ���"+(hurt - p.defNum)+"���˺�");
			} else {
				System.out.println("���޸���֮������Ϻ");
			}
		}
	}
	
	public void attack(people p,Weapon w) {
		if(p.HP>0){
			int hurt;
			hurt = new Random().nextInt(this.attNum+w.addAttNum());
			if(hurt>p.defNum) {
				p.HP = p.HP - (hurt - p.defNum);
				System.out.println(this.name+"��"+p.name+"�����"+(hurt - p.defNum)+"���˺�");
			} else {
				System.out.println("���޸���֮����BOSS");
			}
		}
	}




	public int getEquip() {
		return equip;
	}

	public void setEquip(int equip) {
		this.equip = equip;
	}
	
	
}
