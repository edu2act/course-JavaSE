package MapleStory;

public abstract interface equipment {
	
	public abstract int addAttNum();
	public abstract int addDefNum();
	
}
