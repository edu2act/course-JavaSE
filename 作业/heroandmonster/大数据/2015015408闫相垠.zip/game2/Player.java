package game2;

public class Player {
	private int hp;
	private int mp;
	private int atk;
	private int def;
	
	public Player(){}
	
	public Player(int a,int b,int c,int d){
		this.hp = a;
		this.mp = b;
		this.atk = c;
		this.def = d;
	}
	
	
	
	//��ͨ����
	public void normalAttack(Npc mon){
		int monHp = mon.getHp();
		int monDef = mon.getDef();
		if(monHp >= 0){
			int dam = this.atk - monDef;
			monHp = monHp - dam;
			System.out.println("��Թ��������"+dam+"���˺�");
		}
		mon.setHp(monHp);
	}
	
	//ħ������
	public void megaAttack(Npc mon){
		int monHp = mon.getHp();
		int dmg = this.atk*(int)(8+Math.random()*2)/10;
		if(this.mp - 5 <= 0){
			System.out.println("����ֵ����");
		}
		else{
			this.setMp(mp-5);
			monHp -= dmg;
			System.out.println("��Թ��������"+dmg+"���˺�");
		}
		mon.setHp(monHp);
	}
	
	//�ظ���ʼֵ
	public void heal(int a,int b){
		this.setHp(a);
		this.setMp(b);
		System.out.println("���״̬�ָ���");
	}
	
	//����
	public void levelUp(int a){
			
	}
	
	public int getHp() {
		return hp;
	}
	public void setHp(int hp) {
		this.hp = hp;
	}
	public int getMp() {
		return mp;
	}
	public void setMp(int mp) {
		this.mp = mp;
	}
	public int getAtk() {
		return atk;
	}
	public void setAtk(int atk) {
		this.atk = atk;
	}
	public int getDef() {
		return def;
	}
	public void setDef(int def) {
		this.def = def;
	}

}
