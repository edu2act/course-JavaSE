package game2;		

public class Npc {
	private int hp;
	private int atk;
	private int def;
	public Npc(){}
	
	public Npc(int a,int b,int c){
		this.hp = a;
		this.atk = b;
		this.def = c;
	}
	
	
	
	public int getHp() {
		return hp;
	}
	public void setHp(int hp) {
		this.hp = hp;
	}
	public int getAtk() {
		return atk;
	}
	public void setAtk(int atk) {
		this.atk = atk;
	}
	public int getDef() {
		return def;
	}
	public void setDef(int def) {
		this.def = def;
	}
	
	//��ͨ����
	public void normalAttack(Player pla){
		int plaHp = pla.getHp();
		int plaDef = pla.getDef();
		if(plaHp >= 0){
			int dam = this.atk - plaDef;
			plaHp = plaHp - dam;
			System.out.println("���޶��������"+dam+"���˺�");
		}
		pla.setHp(plaHp);
	}
}
