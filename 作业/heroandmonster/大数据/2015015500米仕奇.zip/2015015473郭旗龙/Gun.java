package com;

public class Gun implements Weapon {

	/* (non-Javadoc)
	 * @see com.Weapon#addAttack()
	 */
	@Override
	public int addAttack() {
		// TODO Auto-generated method stub
		return 40;
	}

	/* (non-Javadoc)
	 * @see com.Weapon#addPower()
	 */
	@Override
	public int addPower() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}
