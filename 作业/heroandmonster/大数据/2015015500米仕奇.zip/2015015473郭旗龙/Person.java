package com;
public abstract class Person {
	String name;
	int leval;//等级
	int hp;//生命值
	int attckNum;//攻击力
	void attack(Person p){
		
	}
	public void person(){}

	public void set(String name, int hp, int attckNum){
	this.name = name;
	this.hp = hp;
	this.attckNum = attckNum;
	}

	public String getName(){
	return name;
	}

	public int getHp(){
	return hp;
	}

	public int getNum(){
	return attckNum;
	}
	
	

}
