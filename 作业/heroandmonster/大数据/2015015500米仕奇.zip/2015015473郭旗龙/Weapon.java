package com;

public interface Weapon {
	public int addAttack();
	public int addPower();	
}
