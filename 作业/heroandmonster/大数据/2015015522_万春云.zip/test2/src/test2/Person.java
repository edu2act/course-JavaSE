package test2;

public abstract class Person {
	public String name;
	public int attackNum;
	public int blood;

	public abstract void attack(Person person);
}