
public class Weapon {
	private String weaponName;//��������
	private int wAtk;//��������
	private int wThunderAtk;//�׵繥��
	private int wFireAtk;//���湥��
	private int wFceAtk;//��˪����
	private int cAtkPre;//����
	
	
	
	public int getcAtkPre() {
		return cAtkPre;
	}
	public void setcAtkPre(int cAtkPre) {
		this.cAtkPre = cAtkPre;
	}
	public int getwAtk() {
		return wAtk;
	}
	public void setwAtk(int wAtk) {
		this.wAtk = wAtk;
	}
	public int getwThunderAtk() {
		return wThunderAtk;
	}
	public void setwThunderAtk(int wThunderAtk) {
		this.wThunderAtk = wThunderAtk;
	}
	public int getwFireAtk() {
		return wFireAtk;
	}
	public void setwFireAtk(int wFireAtk) {
		this.wFireAtk = wFireAtk;
	}
	public int getwFceAtk() {
		return wFceAtk;
	}
	public void setwFceAtk(int wFceAtk) {
		this.wFceAtk = wFceAtk;
	}
	public String getWeaponName() {
		return weaponName;
	}
	public void setWeaponName(String weaponName) {
		this.weaponName = weaponName;
	}
	
	
	public void initWeapon(){
		this.setWeaponName(this.preWeaponName[(int)(Math.random()*preWeaponName.length)]+this.nextWeaponName[(int)(Math.random()*nextWeaponName.length)]);
		
	}
	


	private String[]preWeaponName={"���̵�","��Ѫ��","������","�޾�"};
	private String []nextWeaponName={"��","ذ��","����","�̽�"};
}
