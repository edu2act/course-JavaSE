import java.math.*;
public class Hero {
	private String name;
	private int Hp ;
	private int Atk;	//��������
	private int fireDef;	//���濹��
	private int fireAtk;	//���湥��
	private int thunderDef; //�׵翹��
	private int thunderAtk;//�׵繥��
	private int iceDef;//��˪����
	private int iceAtk;//��˪����
	

	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getHp() {
		return Hp;
	}
	public void setHp(int hp) {
		Hp = hp;
	}
	public int getAtk() {
		return Atk;
	}
	public void setAtk(int atk) {
		Atk = atk;
	}
	public int getFireDef() {
		return fireDef;
	}
	public void setFireDef(int fireDef) {
		this.fireDef = fireDef;
	}
	public int getFireAtk() {
		return fireAtk;
	}
	public void setFireAtk(int fireAtk) {
		this.fireAtk = fireAtk;
	}
	public int getThunderDef() {
		return thunderDef;
	}
	public void setThunderDef(int thunderDef) {
		this.thunderDef = thunderDef;
	}
	public int getThunderAtk() {
		return thunderAtk;
	}
	public void setThunderAtk(int thunderAtk) {
		this.thunderAtk = thunderAtk;
	}
	public int getIceDef() {
		return iceDef;
	}
	public void setIceDef(int iceDef) {
		this.iceDef = iceDef;
	}
	public int getIceAtk() {
		return iceAtk;
	}
	public void setIceAtk(int iceAtk) {
		this.iceAtk = iceAtk;
	}


	public void initHero(){
		this.Hp=1000;
		this.Atk=50;
		this.fireAtk=(int)(Math.random()*9)+1;
		this.fireDef=(int)(Math.random()*9)+1;
		this.iceAtk=(int)(Math.random()*9)+1;
		this.iceDef=(int)(Math.random()*9)+1;
		this.thunderAtk=(int)(Math.random()*9)+1;
		this.thunderDef=(int)(Math.random()*9)+1;
	}
	
	public void checkHero(){
		System.out.println("����ֵ  ������  ���湥��  ���濹��  ��˪����  ��˪����  �׵繥��  �׵翹��");		
		System.out.print(this.getHp()+"\t\t");		
		System.out.print(this.getAtk()+"\t\t");		
		System.out.print(this.getFireAtk()+"\t\t");	
		System.out.print(this.getFireDef()+"\t\t");	
		System.out.print(this.getIceAtk()+"\t\t");	
		System.out.print(this.getIceDef()+"\t\t");	
		System.out.print(this.getThunderAtk()+"\t\t");
		System.out.println(this.getThunderDef()+"\t\t");
	}
}
