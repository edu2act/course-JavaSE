import java.lang.reflect.Array;
import java.math.*;
public class Monster extends Hero{
	
	
	public void initHero(){
		String name=this.preName[(int)(Math.random()*preName.length)]+this.nextName[(int)(Math.random()*nextName.length)]+"��";
		this.setName(name);
		System.out.println(this.getName());
		this.setHp(1000);
		this.setAtk((int)(Math.random()*this.monsterMaxAtk));	
		this.setFireAtk((int)(Math.random()*9)+1);
		this.setFireDef((int)(Math.random()*9)+1);
		this.setIceAtk((int)(Math.random()*9)+1);
		this.setIceDef((int)(Math.random()*9)+1);
		this.setThunderAtk((int)(Math.random()*9)+1);
		this.setThunderDef((int)(Math.random()*9)+1);
	}
	
	public void checkHero(){
		System.out.println("         ����                ����ֵ  ������  ���湥��  ���濹��  ��˪����  ��˪����  �׵繥��  �׵翹��");	
		System.out.print(this.getName()+"\t\t");	
		System.out.print(this.getHp()+"\t\t");		
		System.out.print(this.getAtk()+"\t\t");		
		System.out.print(this.getFireAtk()+"\t\t");	
		System.out.print(this.getFireDef()+"\t\t");	
		System.out.print(this.getIceAtk()+"\t\t");	
		System.out.print(this.getIceDef()+"\t\t");	
		System.out.print(this.getThunderAtk()+"\t\t");
		System.out.println(this.getThunderDef()+"\t\t");
	}
	
	private int monsterMaxHp=1000;
	private int monsterMaxAtk=50;
	private String[]preName={"���͵�","ǿ����","���̵�","���ܵ�"};
	private String[]nextName={"��˪","����","�׵�","��ʴ"};
}
