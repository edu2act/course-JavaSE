package monster;

import java.util.Random;

public class Ultraman extends Person {
	public  void attack(Person p){
		if(p.blood>0){
			int down = new Random().nextInt(p.beatNum);
			p.blood = p.blood-down;
			System.out.println("奥特曼打了怪兽"+down+"怪兽还剩"+p.blood+"血");
			}
	} 
	public  void attack(Person p,Weapon w){
		if(p.blood>0){
			int down = new Random().nextInt(p.beatNum+w.addBeat());
			p.blood = p.blood-down;
			System.out.println("奥特曼打了怪兽"+down+"怪兽还剩"+p.blood+"血");
			}
	} 
	public void technique(Person p,Style s){
		if(p.blood >0){
			s.useStyle(p);
		}
	}
}
