package monster;

public abstract class Person {
	public String name;
	public int level;
	public int blood;
	public int beatNum;
	
	public abstract void attack(Person p);
	public abstract void technique(Person p,Style s);
}
