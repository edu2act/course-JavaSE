package monster;

public interface Weapon {
	public abstract int addBeat();
}
