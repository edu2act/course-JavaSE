package monster;

public class AddBlood implements  Style{
		public void useStyle(Person p){
			System.out.println(p.name+"我使用了加血的功能");
			p.blood+=50;
		}
}
