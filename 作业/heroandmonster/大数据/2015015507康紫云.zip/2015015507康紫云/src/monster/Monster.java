package monster;

import java.util.Random;

public class Monster extends Person{
	public  void attack(Person p){
		if(p.blood>0){
		int down = new Random().nextInt(p.beatNum);
		p.blood = p.blood-down;
		System.out.println("怪兽打了奥特曼"+down+"奥特曼还剩"+p.blood+"血");
		}
	}
	public void technique(Person p,Style s){
		if(p.blood >0){
			s.useStyle(p);
		}
	}
}
