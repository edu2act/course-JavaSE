package monster;

import java.util.Random;

public class Knife implements Weapon {
	public int addBeat(){
		return new Random().nextInt(10);
	}
}
