package monster;

public interface Style {
	public abstract void useStyle(Person p);
}
