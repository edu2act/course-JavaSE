package monster;

import monster.Gun;
import monster.Weapon;

public class Run {

	public static void main(String[] args) {
		Ultraman u=new Ultraman();
		u.name="超人";
		u.blood=200;
		u.beatNum=50;
		Monster m=new Monster();
		m.name="哥斯拉";
		m.blood=500;
		m.beatNum=20;
		Weapon w=new Gun();
		Style s=new AddBlood();
		int flag=0;
		while(true){
			flag++;
		u.attack(m,w);
		m.attack(u);
		if(flag==2){
			u.technique(u,s);
		}
		if(u.blood>0&&m.blood<0){
			System.out.println("超人赢了");
			break;
		}
		if(m.blood>0&&u.blood<0){
			break;
		}
		}
		
	}

}
