package text1;

import java.util.Random;

	public  class Godzilla extends person {
		public Godzilla(){}
		public Godzilla(String name,int hp,int attactnum){
			this.name=name;
			this.hp=hp;
			this.attactnum=attactnum;
		}
		public void attact(Object a){
			hero h = (hero)a;
			
			if(h.hp>0){
				int attact=new Random().nextInt(this.attactnum);
				h.hp=h.hp-attact;
				System.out.println(name+"�ڴ�"+h.name+". "+h.name+"����Ѫ����"+h.hp);
			}
		}
		

	}



