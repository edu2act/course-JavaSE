package text1;

public class weapon{
	public int war;
	public weapon(){}
	public weapon(int war){
		this.war=war;
	}
}
