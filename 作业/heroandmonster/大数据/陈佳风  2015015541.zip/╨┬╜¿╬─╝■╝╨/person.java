package text1;

public abstract class person{
	public String  name;
	public int hp;
	public int attactnum;
	public abstract void attact(Object a);
}

