package text1;
import java.util.Random;
public  class hero extends person {
	 public hero(){}
	 public hero(String name,int hp,int attactnum){
		this.name=name;
		this.hp=hp;
		this.attactnum=attactnum;
	}
	public void attact(Object a){
		Godzilla G=(Godzilla)a;
		if(G.hp>0){
			int attact=new Random().nextInt(this.attactnum);
			int ware=new Random().nextInt(10);
			G.hp=G.hp-attact-ware;
			System.out.println(name+"�ڿ���"+G.name+". "+"��������������ֵ"+ware+". "+G.name+"����Ѫ����"+G.hp);
		}
	}
	

}
