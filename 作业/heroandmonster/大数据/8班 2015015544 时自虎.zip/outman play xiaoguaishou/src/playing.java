
public class playing {
	public static void main(String[] args) {
		Outman o1 = new Outman("O1",10,100);
		Xgs x1 = new Xgs("X1",8,110);
	}
}