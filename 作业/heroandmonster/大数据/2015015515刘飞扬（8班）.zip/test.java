package renwu5;


public class test {
	public static void main(String[] args) {
		//name,level,HP,ATK,bloodVial,nowXP,needXP
		Hero A=new Hero("Arturia Pendragon",1,10000,1000,20,0,10000);
		Monster M=new Monster("Mordred",1,100000, 700,0,0,10000);
		Excalibur E=new Excalibur();
		Treason T=new Treason();
		while(true){
			if(A.getHP()>=0&&M.getHP()>=0){
				A.attack(M);
				M.attack(A);
				if(M.getHP()<=10000){
					A.attack(M);
					M.attack(A,T);
				}
				if(A.getHP()<=5000){
					A.attack(M,E);
					M.attack(A);
				}
				if(A.getHP()<=3000){
					A.recovery(A);
				}
				
			}
			if(A.getHP()<=0){
				System.out.println("Mordred���ѳɹ�");
				M.setGetXP(10000);
				M.levelup(M);
				break;
			}
			if(M.getHP()<=0){
				A.levelup(A);
				A.setGetXP(10000);
				System.out.println("Arturia Pendragon��һͳ���е�");
				break;
			}
			try {
				Thread.sleep(800);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
			
		
	}
}
