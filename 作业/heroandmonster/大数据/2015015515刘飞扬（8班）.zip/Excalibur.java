package renwu5;

public class Excalibur implements Arms{
	public Excalibur(){
		
	}
	public int addATK(){
		return 10000;
	}
}
