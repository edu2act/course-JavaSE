package renwu5;

public class Treason implements Arms{
	public Treason(){
		
	}
	public int addATK(){
		return 3000;
	}
}
