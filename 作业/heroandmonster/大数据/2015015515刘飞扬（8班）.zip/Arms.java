package renwu5;

public interface Arms{
	public int addATK();
}
