package pk;

import java.awt.datatransfer.StringSelection;
import java.util.Random;

public class pk {
	public static void main(String args[]) {
		hero hero = new hero();
		monster monster = new monster();
		while(true) {
				int damage;
				damage = new Random().nextInt(hero.getAtk() + hero.addAtk());
				monster.setHp(monster.getHp() - damage);
				if (monster.getHp() <= 0) {
					System.out.println("���ʤ��~");
					break;
				}
				damage = new Random().nextInt(monster.getAtk() + monster.addAtk());
				hero.setHp(hero.getHp() - damage);
				if (hero.getHp() <= 0) {
					System.out.println("�㹷����~");
					break;
				}
		}
	}
}
