package pk;

import java.util.Random;

public class monster extends other implements weapon{
	public monster() {
		setHp(100);
		setAtk(10);
	}

	public int addAtk() {
		return (new Random().nextInt(10));
	}
}
