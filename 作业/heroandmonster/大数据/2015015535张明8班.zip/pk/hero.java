package pk;
import java.util.*;;
public class hero extends other implements weapon{
	public hero() {
		setHp(100);
		setAtk(10);
	}

	public int addAtk() {
		return (new Random().nextInt(10));
	}
	
}
