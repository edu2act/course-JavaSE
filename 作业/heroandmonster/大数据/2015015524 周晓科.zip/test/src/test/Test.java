package test;

public class Test

{
	public static void main(String[] args)

	{
		Ultraman a = new Ultraman();
		a.name = "������";
		a.attack = 3;
		a.blood = 30;
		Monster m = new Monster();
		m.name = "С����";
		m.attack = 2;
		m.blood = 30;
		while (a.blood > 0 && m.blood > 0)

		{
			a.attack(m);
			if (m.blood <= 0)

			{
				break; 
			}
			m.attack(a);
			if (m.blood <= 0)

			{
				break;
			}

		}

	}
}