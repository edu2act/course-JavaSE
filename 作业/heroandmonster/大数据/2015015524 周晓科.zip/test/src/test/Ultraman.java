package test;

public class Ultraman

{
	public String name;
	public int attack;
	public int blood;

	public void attack(Monster a)

	{
		a.blood -= attack;
		System.out.println(name + "���ڹ���" + a.name + "," + a.name + "ʣ���Ѫ����" + a.blood);
		if (a.blood <= 0)

		{
			System.out.println(name + "ʤ����");
		}
	}
}


