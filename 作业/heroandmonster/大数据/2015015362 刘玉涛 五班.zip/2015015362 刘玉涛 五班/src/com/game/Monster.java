package com.game;

import java.util.Random;

public class Monster extends Person {

	@Override
	public void attack(Person p) {
		// TODO Auto-generated method stub
		if(p.boloodCount>0){
			int down = new Random().nextInt(this.attackNum);
			p.boloodCount = p.boloodCount-down;
			System.out.println(p.name+"被攻击了"+down+"剩余"+boloodCount);
		}
	}
	public void attack(Person p,equip c){
		if(p.boloodCount>0){
			int down = new Random().nextInt(this.attackNum-c.adddefense());
			p.boloodCount = p.boloodCount-down;
			System.out.println(p.name+"被攻击了"+down+"剩余"+boloodCount);
		}
	}

}
