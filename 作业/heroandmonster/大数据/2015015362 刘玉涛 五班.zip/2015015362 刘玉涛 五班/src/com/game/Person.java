package com.game;

public abstract class Person {
	public String name;
	public int boloodCount;
	public int level;
	public int attackNum;
	public int defense;
	
	public abstract void attack(Person p);
	
}
