package com.game;

public class clothes implements equip {

	int addNum = 150;
	public int adddefense() {	
		return addNum;	
	}

}
