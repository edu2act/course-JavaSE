package com.game;

import java.util.Random;

public class Hero extends Person{
	public void attack (Person p){
		if(p.boloodCount>0){
			int down = new Random().nextInt(this.attackNum);
			p.boloodCount = p.boloodCount-down;
			
		}
	}
	public void attack(Person p,Weapon w){
		if(p.boloodCount>0){
			int down = new Random().nextInt(this.attackNum+w.addAttackNum());
			p.boloodCount = p.boloodCount-down;
			System.out.println(p.name + "被攻击了" + down);
		}
	}
	

}
