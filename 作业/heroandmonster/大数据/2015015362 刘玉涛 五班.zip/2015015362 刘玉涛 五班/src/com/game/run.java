package com.game;

public class run {

	public static void main(String[] args) {
		Hero hero = new Hero();
		hero.name = "superman";
		hero.attackNum = 100;
		hero.boloodCount = 100;
		hero.level = 1;
		Weapon k = new Knife();
		equip c = new clothes();
		Monster monster = new Monster();
		monster.name = "gesila";
		monster.boloodCount = 2000;
		monster.attackNum = 200;
		monster.level = 20;
		
		while(true){
			hero.attack(monster,k);
			monster.attack(hero,c);
			if(hero.boloodCount<=0){
				System.out.println("大侠请重新来过");
				break;
			}
			if(monster.boloodCount<=0){
				System.out.println("继续干");
				break;
				
			}
			
		}
		
	}

}
