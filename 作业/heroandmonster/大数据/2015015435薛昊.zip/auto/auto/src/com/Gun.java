package com;
//枪类 提供武器接口
public class Gun implements Weapon {

	@Override
	public int addAttackNum() {
		return 100;//攻击值
	}

}
