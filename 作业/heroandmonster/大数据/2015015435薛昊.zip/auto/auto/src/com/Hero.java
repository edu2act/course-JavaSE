package com;
//子类英雄
import java.util.Random;//随机一个数

public class Hero extends Person{
	//英雄攻击  血量低于0死亡
	public void attack(Person p) {
		if(p.hp>0){
			int down = new Random().nextInt(this.attackNum);
			p.hp = p.hp - this.attackNum;
		}

	}
//英雄装备武器打打打
	public void attack(Person p,Weapon w) {
		if(p.hp>0){
			int down = new Random().nextInt(this.attackNum+w.addAttackNum());
			p.hp = p.hp - this.attackNum;
		}

	}

}
