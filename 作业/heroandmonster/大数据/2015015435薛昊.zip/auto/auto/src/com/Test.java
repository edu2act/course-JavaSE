package com;

public class Test {

	public static void main(String[] args) {
		Hero h = new Hero();
		h.name = "尼古拉斯赵四";
		h.level = 10;
		h.hp = 100;
		h.attackNum = 10;
		
		Weapon w = new Gun();
		
		Monster m = new Monster();
		m.name = "老王八";
		m.level = 10;
		m.hp = 200;
		m.attackNum = 10;
		
		while((h.hp >= 0)&&(m.hp >= 0)){
			h.attack(m,w);
			m.attack(h);
			if(h.hp <= 0){
				System.out.println(m.name+"击败了"+h.name);
				break;
			}
			
			if(m.hp <= 0){
				System.out.println(h.name+"击败了"+m.name);
			}
		}
		
		
		
	}

}
