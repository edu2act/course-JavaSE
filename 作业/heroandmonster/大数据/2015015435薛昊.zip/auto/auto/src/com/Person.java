package com;
//抽象类人
public abstract class Person {

	public String name;
	public int level;
	public int hp;
	public int attackNum;
//抽象行为攻击
	public abstract void attack(Person p);
	
	
}
