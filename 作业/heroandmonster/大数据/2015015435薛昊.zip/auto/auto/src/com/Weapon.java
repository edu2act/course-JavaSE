package com;
//接口 武器
public interface Weapon {

	public int addAttackNum();
}
