package games;

public class Ao {
	public String name;
	public int attacka;
	public int blood;
	public int level;

	public void attack(Master m)// 小怪兽的行为：小怪兽攻击奥特曼
	{
		m.blood -= attacka;
		level = level + 1;
		System.out.println(name + "正在暴打" + m.name + "," + m.name + "剩余" + m.blood + "滴血");
		System.out.println(name + "升级至" + level + "级");
		if (m.blood <= 0) {
			System.out.println(name + "又在最关键的时刻获得了胜利！");
		}
	}
}
