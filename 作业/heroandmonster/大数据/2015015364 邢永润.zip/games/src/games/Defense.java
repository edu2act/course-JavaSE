package games;

public class Defense {
	public int defense;

	public void defenses(Master m) {
		m.blood = m.blood + defense;
		System.out.println(m.name + "血量回复");

	}

}
