package games;

public class Skill {
	public int attacks;
	public int attackz;

	public void fskill(Master m) {
		m.blood = m.blood - attacks;
		System.out.println("奥特曼" + "发动了艾梅利姆光线" + m.name + "剩余" + m.blood + "滴血");
	}

	public void sskill(Master m) {
		m.blood = m.blood - attackz;
		System.out.println("奥特曼" + "发动了集束光线" + m.name + "剩余" + m.blood + "滴血");

	}
}
