package games;

public class Manger {

	public static void main(String[] args) throws Exception {
		Ao a = new Ao();
		a.name = "奥特曼";
		a.attacka = 5;
		a.blood = 190;
		a.level = 1;
		Master m = new Master();
		m.name = "哥斯拉";
		m.attackm = 5;
		m.blood = 150;
		m.level = 1;
		Skill s = new Skill();
		s.attacks = 10;
		s.attackz = 15;
		Defense d = new Defense();
		d.defense = 20;
		while (a.blood > 0 && m.blood > 0) {
			if (a.blood == 100) {
				s.fskill(m);

			}
			if (a.blood == 50) {
				s.sskill(m);
			}
			a.attack(m);
			if (a.blood <= 0) {
				break;
			}
			if (m.blood == 20) {
				d.defenses(m);
			}
			m.attack(a);
			if (m.blood <= 0) {
				break;
			}
			Thread.sleep(1000);
		}

	}

}
