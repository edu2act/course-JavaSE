package games;

public class Master {
	public String name;
	public int attackm;
	public int blood;
	public int level;

	public void attack(Ao a) {
		a.blood -= attackm;
		level = level + 1;
		System.out.println(name + "正在暴打" + a.name + "," + a.name + "剩余" + a.blood + "滴血");
		System.out.println(name + "升级至" + level + "级");

		if (a.blood <= 0) {
			System.out.println(name + "奇迹般的取得了胜利");
		}
	}
}
