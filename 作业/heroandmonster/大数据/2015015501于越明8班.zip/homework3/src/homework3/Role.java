package homework3;

public abstract class Role {
	public String name;
	public int level;
	public int hp;
	public int accackNum;

	public abstract void attack(Role r);
}
