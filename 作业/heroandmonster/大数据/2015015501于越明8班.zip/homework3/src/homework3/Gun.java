package homework3;

public class Gun implements Weapon {

	public int addAttNum() {
		return 10; // ����ֵ�ӳ�
	}

}
