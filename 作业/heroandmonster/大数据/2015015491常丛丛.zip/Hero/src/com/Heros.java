package com;

import java.util.Random;

public class Heros extends Person {
	public void attack(Person p) {

		// p.hp=p.hp-this.attckNum;
		int down = new Random().nextInt(this.getNum());
		p.hp = p.hp - down;
		if (p.hp > 0) {
			System.out.println(this.getName() + "你打了小怪兽：" + p.getName() + "一拳，小怪兽掉血，目前小怪兽还剩生命" + p.hp + "点");
		} else {
			System.out.println(this.getName() + "你打了小怪兽：" + p.getName() + "一拳，小怪兽掉血，小怪兽没有了生命");
		}
	}

	public void attack(Person m, Weapon Gun) {
		int down = new Random().nextInt(this.getNum() + Gun.addAttack());
		m.hp = m.hp - down;
		if (m.hp > 0) {
			System.out.println(this.getName() + "你打了小怪兽" + m.getName() + "一拳，小怪兽掉血，目前小怪兽还剩生命" + m.hp + "点");
		} else {
			System.out.println(this.getName() + "你打了小怪兽" + m.getName() + "一拳，小怪兽掉血严重，小怪兽没有了生命");
		}
	}
}
