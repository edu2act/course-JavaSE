package com;

import java.util.Scanner;

public class Main {

	public static void main(String[] args)throws InterruptedException {
		Heros h = new Heros();
		h.set("悟空", 100, 50);
		
		Monster boss = new Monster();
		boss.set("白骨精", 200, 40);
		
		System.out.println("输入1或2：（1为有武器，2没有武器,）");
		
		Scanner s = new Scanner(System.in);
		int sIn = s.nextInt();
		
		if(sIn == 1){
		while(true){
			
			Weapon g = new Gun();
			h.attack(boss,g);
			if(boss.hp <= 0){
				System.out.println("");
				System.out.println("悟空，你又打死人了，阿弥陀佛");
				return;
			}
			System.out.println("");
			Thread.sleep(1000);
			
			boss.attack(h);
			if(h.hp <= 0){
				System.out.println("");
				System.out.println("小妖精跑了，师傅被妖精捉走了，再去追");
				return;
			}
			System.out.println("");
			Thread.sleep(1000);
		}
		}
	
		if(sIn == 2){
			while(true){
			
				h.attack(boss);
				if(boss.hp <= 0){
					System.out.println("");
					System.out.println("悟空，你又打死人了，阿弥陀佛");
					return;
				}
				System.out.println("");
				Thread.sleep(1000);
				
				boss.attack(h);
				if(h.hp <= 0){
					System.out.println("");
					System.out.println("小妖精跑了，师傅被妖精捉走了，再去追，选择1你可以变大金箍棒。");
					return;
				}
				System.out.println("");
				Thread.sleep(1000);
			}
			}
		

	}

}
