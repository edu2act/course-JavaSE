package demo;

class Master{
	public int attackNum;
	private String name;
	private int hp;
	

	public void setName(String b){
		name=b;
	}
	public String getName(){
		return name;
	}
	public void setHp(int a){
		hp=a;
	}
	public int getHp(){
		return hp;
	}

	public void attack(Hero man){ 
		int x=(int)(Math.random()*10+1);
		man.setHp(man.getHp()-x);  
		System.out.println(man.getName()+"被"+getName()+"打了，剩余血量是"+man.getHp());  
		}  
}


class Hero{
	public int attackNum;
	private String name;
	private int hp;
	

	public void setName(String c){
		name=c;
	}
	public String getName(){
		return name;
	}
	public void setHp(int a){
		hp=a;
	} 
	public int getHp(){
		return hp;
	}

	public void attack(Master mas){  
		int x=(int)(Math.random()*10+1);
		mas.setHp(mas.getHp()-x);  
		System.out.println(mas.getName()+"被"+getName()+"打了，剩余血量是"+mas.getHp());  
		}   
}

public class demo4 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//实例化对象  
		Master mas=new Master();  
		Hero man=new Hero();  
		  
		//设置奥特曼和小怪兽的姓名属性  
		man.setName("英雄"); 
		
		mas.setName("小怪兽");  
		//设置奥特曼和小怪兽的血量属性  
		man.setHp(100);  
		mas.setHp(100);  
		
		while(man.getHp()>0&&mas.getHp()>0){  
			//分别调用打的方法  
			man.attack(mas);
			mas.attack(man);
			if(mas.getHp()<=0){  
				System.out.println(man.getName()+"赢了");  
			}  
			
			if(man.getHp()<=0){  
				System.out.println(mas.getName()+"赢了");  
			}
		}
	}
}
