package gameonclass;

public class gun implements weapon{
	static int gAttack=20;
}
