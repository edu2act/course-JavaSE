package gameonclass;

public interface weapon {
	int gAttack=0;
}
