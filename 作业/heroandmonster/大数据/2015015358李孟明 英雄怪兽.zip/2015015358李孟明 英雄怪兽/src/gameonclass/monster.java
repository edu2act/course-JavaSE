package gameonclass;

import java.util.Random;

public class monster extends Person {
	int down;
	@Override
	public void attack(Person p){
		if(p.hp>0)
		{
			t=c;
			down = new Random().nextInt(this.attckNum);
			p.hp=hp-down;
			c+=1;
		}
	}

}
