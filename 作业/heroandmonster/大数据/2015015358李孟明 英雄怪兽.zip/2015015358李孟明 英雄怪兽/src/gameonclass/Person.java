package gameonclass;

public abstract class Person {
	public String name;
	public int hp;
	public int attckNum;
	public int c;
	public int t;
	public abstract void attack(Person p);

	
}
