package gameonclass;

import java.util.Random;

public class Hero extends Person {
	
	int down;
	@Override
	public void attack(Person p){
		if(p.hp>0)
		{
			t=c;
			down = new Random().nextInt(this.attckNum)+gun.gAttack;
			p.hp=hp-down;
			c+=1;
		}
	}
}

	


	

