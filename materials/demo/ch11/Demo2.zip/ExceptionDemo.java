package net.onest;

public class ExceptionDemo {

	public static void main(String[] args) {
//		Integer i = Integer.valueOf("abc");
//		try {
//		    fun(0);
//		}catch(ArithmeticException e) {
//			e.printStackTrace();
//		}
		
//		Student stu = new Student();
//		
//		try {
//		    stu.setAge(202);
//		}catch (MyException e) {
//			e.printStackTrace();
//		}
		
		//����
		int a = 10, b = 20;
//		assert a > b;
		assert a > b : "a������b";
		System.out.println("����--------------");
	}
	
	public static void fun(int a) throws ArithmeticException{
		try {
		    int b = 100 / a;
		}catch(ArithmeticException e) {
			//�׳��쳣
			throw e;
		}
	}
}
