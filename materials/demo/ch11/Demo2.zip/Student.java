package net.onest;

public class Student {

	private int age;
	public void setAge(int age) throws MyException{
		if(age < 0 || age > 200) {
			//�׳��쳣
			throw new MyException(age);
		}else {
		    this.age = age;
		}
	}
}
