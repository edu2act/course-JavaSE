package net.onest;

public class MyException extends Exception {

	private int age;
	
	public MyException(int age) {
		this.age = age;
	}
	
	@Override
	public String getMessage() {
		return "���䳬����Ч��Χ:" + age;
	}
	
	@Override
	public void printStackTrace() {
		System.out.println(this.getClass().getName());
		super.printStackTrace();
	}
	
	@Override
	public String toString() {
		return getMessage();
	}
}
