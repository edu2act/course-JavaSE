package nwt.onest;

public class Student {

	private String name;
	private int age;
	static {
		System.out.println("����Student��");
	}
}
