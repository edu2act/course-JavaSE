package net.onest.homework;

/**
 * ͼ����
 * @author ��Ӧ��
 *
 */
public class Book extends Product{

	private String ISBN;
	private String author;
	

	public Book() {
	}

	public Book(String number, String name, String author) {
		super(number, name, 10);
		this.author = author;
	}
	
	public Book(String number, String name, String author, int count,
			String ISBN) {
		super(number, name, count);
		this.author = author;
		this.ISBN = ISBN;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}

	public String getISBN() {
		return ISBN;
	}

	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}

	@Override
	public String toString() {
		return getNumber() + " " + getName() + " "
				+ getCount() + " "
		        + author + " " + ISBN ;
	}
}
