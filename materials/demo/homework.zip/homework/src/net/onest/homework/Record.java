package net.onest.homework;

/**
 * ���ļ�¼��
 * @author ��Ӧ��
 *
 */
public class Record {

	private Member member;//������
	private Product product;//�����ĵ���Ʒ
	private String date;
	
	public Record(Member m, Product p, String date) {
		super();
		this.member = m;
		this.product = p;
		this.date = date;
	}
	public Member getMember() {
		return member;
	}
	public void setMember(Member m) {
		this.member = m;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product p) {
		this.product = p;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
}
