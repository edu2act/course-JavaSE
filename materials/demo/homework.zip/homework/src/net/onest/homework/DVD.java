package net.onest.homework;

/**
 * DVD��
 * @author ��Ӧ��
 *
 */
public class DVD extends Product{

	private String ISRC;

	public DVD(String number, String name, 
			int count, String iSRC) {
		super(number, name, count);
		ISRC = iSRC;
	}

	public String getISRC() {
		return ISRC;
	}

	public void setISRC(String iSRC) {
		ISRC = iSRC;
	}
	
	@Override
	public String toString() {
		return getNumber() + " " + getName() + " "
				+ getCount() + " "
				+ ISRC;
	}

}
