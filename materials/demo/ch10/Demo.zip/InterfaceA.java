
public interface InterfaceA {

	public void fun();
}
