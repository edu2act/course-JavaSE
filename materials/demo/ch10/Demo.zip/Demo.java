
public class Demo {
	
	public enum WeekDay{
		MONDAY,TUESDAY,WENSDAY,THURSDAY,FRIDAY;
	}

	public static void main(String[] args) {

//		WeekDay wd = WeekDay.MONDAY;
//		switch(wd) {
//		case MONDAY:
//			System.out.println("��һ");
//			break;
//		case TUESDAY:
//			System.out.println("�ܶ�");
//			break;
//		default:
//				break;
//		}
		
		Color c1 = Color.RED;
		Color c2 = Color.BLACK;
		System.out.println(c1.equals(c2));
		System.out.println(c1==c2);
//		System.out.println(Color.RED.getName());
//		System.out.println(c1.getId());
//		System.out.println(Color.GREEN);
//		Enum
		Color[] colors = Color.values();
		for(Color c : colors) {
			System.out.println(c.getDeclaringClass());
			System.out.println(c.getName());
			System.out.println(c.name());
			System.out.println(c.getId());
			System.out.println(c.ordinal());
		}
		
		
	}

}
