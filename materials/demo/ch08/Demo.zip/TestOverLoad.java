package net.onest;

public class TestOverLoad {

	public void fun(int x) {
		System.out.println("int");
	}
	
	public void fun(double d) {
		System.out.println("double");
	}
	
	public void fun(Short s) {
		System.out.println("Short");
	}
	
	public void fun(Double d) {
		System.out.println("Double");
	}
	
	public void fun(int x, int y) {
		System.out.println("int,int");
	}
	
	public void fun(short ...s) {
		System.out.println("short...");
	}
	
	public void fun(Short x, Short y) {
		System.out.println("Short,Short");
	}
	
	public void fun1(Object obj) {
		System.out.println("Object");
	}
}
