import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class NetWorkDemo {

	public static void main(String[] args) {

		try {
//			URL url = new URL("http://www.baidu.com");
//			URLConnection connection = url.openConnection();
//			InputStream is = connection.getInputStream();
//			byte[] buffer = new byte[1024];
//			int len=0;
//			StringBuffer stringBuffer = new StringBuffer();
//			while ((len = is.read(buffer)) != -1) {
//				stringBuffer.append(new String(buffer,0, len));
//			}
//			System.out.println(stringBuffer.toString());
//			System.out.println(url.getProtocol());
			
			//�����ļ�
			URL imageURL = new URL("http://wx3.sinaimg.cn/large/"
					+ "006nLajtly1fkegnmnwuxj30dw0dw408.jpg");
			URLConnection connection = imageURL.openConnection();
			InputStream is = connection.getInputStream();
			OutputStream os = new FileOutputStream("F:/test.jpg");
			byte[] buffer = new byte[1024];
			int len = 0;
			while((len = is.read(buffer)) != -1) {
				os.write(buffer, 0, len);
			}
			is.close();
			os.close();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

}
