package net.onest;

public enum Grade {
	a,b,c,d,e;
}
