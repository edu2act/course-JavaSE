package net.onest;

public class OuterClassB {

	private String outerStr;
	
	public void displayOuter(final int num) {
		final int i = 0; 
		class InnerClassB{
			public void displayInner() {
//				i++;
				System.out.println(i);
//				num++;
				System.out.println(num);
				System.out.println("�ֲ��ڲ��෽��");
			}
		}
		InnerClassB in = new InnerClassB();
		in.displayInner();
	}
	
}
