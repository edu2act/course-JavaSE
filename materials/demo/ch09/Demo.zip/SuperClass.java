package net.onest;

public abstract class SuperClass {

	public abstract void display();
}
