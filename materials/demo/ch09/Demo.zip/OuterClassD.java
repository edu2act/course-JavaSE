package net.onest;

public class OuterClassD {
	private static String str;
	
	private InterfaceA a = new InterfaceA() {
		
		@Override
		public void display() {
			// TODO Auto-generated method stub
			
		}
	};

	public static class InnerClassD{
		public static void display() {
			System.out.println("��̬�ڲ���");
		}
		public void innerFun() {
			str="aaa";
		}
	}
}
