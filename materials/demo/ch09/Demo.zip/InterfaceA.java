package net.onest;

public interface InterfaceA {
	public void display();
}
