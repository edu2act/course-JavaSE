import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.util.Arrays;

public class ReaderWriterDemo {

	public static void main(String[] args) {

		
		try {
			//�ļ��ַ�������
//			Reader reader = new FileReader("F:/a.txt");
//			//�����ַ�������
//			BufferedReader br = new BufferedReader(reader);
//			System.out.println(br.read());
//			char[] chars = new char[255];
//			int len = br.read(chars);
//			System.out.println(new String(chars, 0 , len));
//			reader.close();
//			br.close();
			
			//�ļ��ַ������
//			Writer writer = new FileWriter("F:/a.txt");
			//�����ַ������
//			BufferedWriter bw = new BufferedWriter(writer);
//			writer.append("��");
//			writer.write("Ӧ��");
//			writer.flush();
//			writer.close();
//			bw.append("��");
//			bw.write("��һ���й���");
//			bw.flush();
//			bw.close();
			
			//�ֽڵ��ַ���ת����
//			InputStream is = new FileInputStream("F:/a.txt");
//			InputStreamReader isr = new InputStreamReader(is);
//			BufferedReader br = new BufferedReader(isr);
//			char[] chars = new char[255];
//			int len = isr.read(chars);
//			System.out.println(new String(chars,0,len));
			
			
			//��������������
//			Student stu = new Student("001","����");
//			OutputStream os = new FileOutputStream("F:/a.txt");
//			ObjectOutputStream oos = new ObjectOutputStream(os);
//			oos.writeObject(stu);
//			oos.flush();
//			oos.close();
			
			InputStream is = new FileInputStream("F:/a.txt");
			ObjectInputStream ois = new ObjectInputStream(is);
			Student stu = (Student)ois.readObject();
			System.out.println(stu);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
