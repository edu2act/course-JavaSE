package net.onest;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

public class FileDemo {

	public static void main(String[] args) throws FileNotFoundException {
		//����Ŀ¼
		File dir = new File("D:/Java/test/a");
		if(!dir.exists()) {
			dir.mkdirs();
		}
		
		//�����ļ�
		File file = new File("D:/Java/a.txt");
		if(!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		//��ȡ·����Ŀ¼
		File parentDir = new File("D://");
		String[] child = parentDir.list();
		for(String ch : child) {
			File childFile = new File("D://" + ch);
			long time = childFile.lastModified();
			Date date = new Date(time);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy��MM��dd�� hh:mm:ss");
			System.out.println(ch + "�޸����ڣ�" + sdf.format(date));
			if(childFile.isDirectory()) {
				String[] strs = childFile.list();
				System.out.println(Arrays.toString(strs));
			}
		}
		
		//ɾ���ļ�
//		file.delete();
		
		//�����д�ļ�
		RandomAccessFile raf = new RandomAccessFile(file, "rw");//��д�ķ�ʽ��
		String str = "asdfgasdf";
		try {
			raf.write(str.getBytes());
			//�ƶ��ļ�ָ��
			raf.seek(0);
			byte[] buff = new byte[2];
			raf.read(buff);
			System.out.println(new String(buff));
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
