package net.onest;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class StreamDemo {

	public static void main(String[] args) throws IOException {
		FileInputStream is = null;
		OutputStream os = null;
		BufferedOutputStream bos=null;
		try {
			//�ļ��ֽ�������
//			is = new FileInputStream("F:/a.txt");
//			System.out.println(is.read());
//			byte[] buffer = new byte[4];
//			is.read(buffer);
//			System.out.println(new String(buffer));
//			is.read(buffer, 0, 2);
//			System.out.println(new String(buffer));
			
			//�����ֽ�������
//			BufferedInputStream bis = new BufferedInputStream(is);
//			bis.read();
//			bis.mark(2);
//			bis.read();
//			bis.read();
//			bis.reset();
//			System.out.println(bis.read());
			
			//�ֽ������
//			os = new FileOutputStream("F:/a.txt");
//			String str = "asdfghjkl";
//			os.write(str.getBytes());
			
			//�����ֽ������
//			bos = new BufferedOutputStream(os);
//			bos.write(str.getBytes());
//			//ˢ�»�����
//			bos.flush();
			
			//ʵ���ļ�����
			is = new FileInputStream("F:/a.jpg");
			BufferedInputStream bis = new BufferedInputStream(is);
			os = new FileOutputStream("E:/b.jpg");
			BufferedOutputStream bos1 = new BufferedOutputStream(os);
			byte[] buffer = new byte[255];
			int len = 0;
			while((len = bis.read(buffer) ) != -1) {
				bos1.write(buffer, 0, len);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			is.close();
			os.close();
//			bos.close();
		}
	}
}
