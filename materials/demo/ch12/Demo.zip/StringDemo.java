package net.onest;

import java.util.StringTokenizer;

public class StringDemo {

	public static void main(String[] args) {

		//�ַ���������
//		String str = "";
//		System.out.println(str.length());
//		String str1 = null;
//		System.out.println(str1.length());
		
		String s1 = "abc|def|sdf";
		StringBuffer str1 = new StringBuffer(s1);
//		s1 = s1 + "def";
//		String s2 = "abc";
//		String s1 = new String("abc");
//		String s2 = new String("abc");
//		System.out.println(s1.equals(s2));
//		String s2 = s1.concat("def");
//		System.out.println(s1.indexOf("abc",1));
//		System.out.println(s1.charAt(2));
//		String[] res = s1.split("\\|");
//		for(String s : res) {
//			System.out.println(s);
//		}
		
//		System.out.println(s1.replace('-', ','));
//		System.out.println(s1.substring(1,4));
		
		//�ַ���������
//		StringBuffer strBuffer = new StringBuffer();
//		for(int i = 0; i < 10; i++) {
//			strBuffer.append("abc");
//		}
//		System.out.println(strBuffer.reverse().toString());
		
		//�ַ���������
//		StringTokenizer st = new StringTokenizer(s1, "|");
//		while(st.hasMoreTokens()) {
//			System.out.println(st.nextToken());
//		}
	}

}
