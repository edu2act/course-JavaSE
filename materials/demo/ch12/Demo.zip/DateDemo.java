package net.onest;

import java.util.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
//import java.sql.Date;
import java.util.Calendar;
public class DateDemo {

	public static void main(String[] args) {

		// java.util.Date
//		Date d1 = new Date();
//		Date d2 = new Date(System.currentTimeMillis());
//		System.out.println(d2.getDate());
//		System.out.println(d2.getDay());
//		System.out.println(d2.toString());
		
		//java.sql.Date
//		Date d3 = Date.valueOf("2018-12-03");
//		System.out.println(d3.getDate());
		
		//������
//		Calendar cal = Calendar.getInstance();
//		System.out.println(cal.get(Calendar.HOUR));
//		System.out.println(cal.get(Calendar.MONTH));
//		System.out.println(cal.get(Calendar.DAY_OF_MONTH));
//		System.out.println(cal.get(Calendar.DAY_OF_WEEK));
//		
//		Calendar cal1 = Calendar.getInstance();
//		cal1.set(Calendar.YEAR, 2008);
//		cal1.set(Calendar.MONTH, 7);
//		cal1.set(Calendar.DATE, 8);
		
		//Calendar��Date��ת��
//		Calendar cal = Calendar.getInstance();
//		Date date = cal.getTime();
//		System.out.println(date.toString());
		
//		Date date = new Date(60*1000);
//		Calendar cal = Calendar.getInstance();
//		cal.setTime(date);
//		System.out.println(cal.toString());
		
		//���ڵĸ�ʽ��
		//������ת���ַ�������
//		DateFormat df = DateFormat.getDateInstance(DateFormat.LONG);
//		Date date = new Date();
//		String dateStr = df.format(date);
//		System.out.println(dateStr);
		
		//������ת���ַ�������
//		SimpleDateFormat adf = new SimpleDateFormat("yyyy��MM��dd�� hh:mm");
//		Date date = new Date();
//		String now = adf.format(date);
//		System.out.println(now);
		
		//�ַ���ת������
//		String dateStr = "2008-08-08";
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//		try {
//			Date date = sdf.parse(dateStr);
//			System.out.println(date.toString());
//		} catch (ParseException e) {
//			e.printStackTrace();
//		}
		
		//JDK8�е���������
//		Instant ins = Instant.now();
//		Instant ins1 = Instant.ofEpochSecond(60*60);
//		System.out.println(ins.toString());
		
//		LocalDate ld = LocalDate.now();
//		LocalDate chri = LocalDate.of(2018, 12, 25);
//		System.out.println(chri.toString());
//		LocalDate ldfirst = ld.with(TemporalAdjusters.lastDayOfMonth());
//		LocalDate firstSun = ld.with(TemporalAdjusters.firstInMonth(DayOfWeek.SUNDAY));
//		System.out.println(ldfirst.toString());
//		System.out.println(firstSun);
		
//		LocalDateTime ldt = LocalDateTime.of(2008,8,8,8,8);
//		LocalDate dd = ldt.toLocalDate();
//		System.out.println(dd.toString());
		
		//�����ڵĸ�ʽ��
//		String dateStr = "2018��12��20��";
//		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy��MM��dd��");
//		LocalDate date = LocalDate.parse(dateStr, dtf);
//		System.out.println(date.toString());
		
//		LocalDate date = LocalDate.now();
//		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy��MM��dd��");
//		String str = date.format(dtf);
//		System.out.println(str);
	}

}
