package net.onest;

public class Demo {

	public static void main(String[] args) {
//		Student s1 = new Student();
//		s1.setName("zhangsan").setAge(20);
//		System.gc();
		Teacher t1 = new Teacher();
		t1.setName("����");
		t1.think();
		
	}
}