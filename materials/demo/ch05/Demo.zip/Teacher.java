package net.onest;

public class Teacher extends Person{

	private String address;
	private String major;
	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public void teach() {
		System.out.println("�����Ͽ�");
	}
}
