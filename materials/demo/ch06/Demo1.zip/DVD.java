package net.onest;

public class DVD extends Product{

	private String ISRC;

	public String getISRC() {
		return ISRC;
	}

	public void setISRC(String iSRC) {
		ISRC = iSRC;
	}
	
	@Override
	public String toString() {
		return " DVD���ƣ�" + getName() + " DVD��ţ�" +
				getNumber() + " DVD�۸�" + getPrice() +
				"ISRC: " + ISRC;
	}
}
