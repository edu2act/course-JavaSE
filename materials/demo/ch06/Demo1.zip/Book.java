package net.onest;

public class Book extends Product{

	private String autor;
	private String publishDate;
	private String ISBN;
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public String getPublishDate() {
		return publishDate;
	}
	public void setPublishDate(String publishDate) {
		this.publishDate = publishDate;
	}
	public String getISBN() {
		return ISBN;
	}
	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return " ͼ�����ƣ�" + getName() + " ͼ���ţ�" +
				getNumber() + " ͼ��۸�" + getPrice() + 
				" ���ߣ�" + autor + " ISBN: "+ ISBN;
	}
}
