package net.onest;

public class ProductManagement {

	private Product[] products;
	private int max;
	private int current;
	
	public ProductManagement(ProductManagement p) {
		this.products = p.products;
		this.max = p.max;
		this.current = p.current;
	}
	
	public ProductManagement(int count) {
		products = new Product[count];
		max = count;
	}
	
	public void savaProduct(Product product) {
		if(current < max) {
			products[current] = product;
			current++;
		}else {
			System.out.println("��������");
		}
	}
	
	public void findProduct(String name) {
		for(int i = 0; i < current; i++) {
			if(products[i].getName().contains(name)) {
				System.out.println(products[i]);
			}
		}
	}
	
}
