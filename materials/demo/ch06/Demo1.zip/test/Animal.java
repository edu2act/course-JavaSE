package net.onest.test;

public abstract class Animal {

	private String color;
	
	public Animal() {
		System.out.println("Animal");
	}
	
	public void print() {
		System.out.println("print");
	}
	
	public abstract void shout();
}
