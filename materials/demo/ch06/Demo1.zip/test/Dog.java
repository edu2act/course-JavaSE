package net.onest.test;

public class Dog extends Animal{

	@Override
	public void shout() {
        System.out.println("����");		
	}
}
