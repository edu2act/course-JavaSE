package net.onest.test;

public class Cat extends Animal {

	@Override
	public void shout() {
		// TODO Auto-generated method stub
		System.out.println("����");
	}
}
