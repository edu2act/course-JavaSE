package net.onest;

public class Demo {

	public static void main(String[] args) {

		ProductManagement management = new ProductManagement(2000);
		Book book1 = new Book();
		book1.setName("Java���˼��");
		DVD  d1 = new DVD();
		d1.setName("�����Ӱ");
		
		management.savaProduct(book1);
		management.savaProduct(d1);
		
		management.findProduct("����");
		
		ProductManagement p = new ProductManagement(management);
		p.savaProduct(d1);
		p.findProduct("����");
		management.findProduct("����");
	}

}
