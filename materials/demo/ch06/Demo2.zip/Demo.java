package net.onest;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		Test.funStatic();
//		Test t1 = new Dog();
//		t1.funDefault();
//		Dog d1 = new Dog();
//		d1.funDefault();
		
//		Object obj = new Person();
////		obj = new String("abc");
//		Person p1 = (Person)obj;
		
		Person p2 = new Person();

		System.out.println(p2.getClass());
	}

}
