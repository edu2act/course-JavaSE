package net.onest;

public class Dog extends Animal implements Test{

	@Override
	public void shout() {
		System.out.println(HOUR);
		System.out.println("����");
	}

	@Override
	public void train() {
		System.out.println("������");
	}
	
	@Override
	public int compareTo(Object obj) {
		if(obj instanceof Dog) {
			Dog dog = (Dog)obj;
			if(this.getAge() > dog.getAge()) {
				return 1;
			}
			if(this.getAge() == dog.getAge()) {
				return 0;
			}
			if(this.getAge() < dog.getAge()) {
				return -1;
			}
		}
		
		return -2;
	}
	
	@Override
	public void funDefault() {
		System.out.println("��д��default����");
	}
}
