package net.onest;

public class Person implements MyComparable{

	private String name;
	private int age;
	private String gender;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	@Override
	public int compareTo(Object obj) {
		if(obj instanceof Person) {
			Person person = (Person)obj;
			if(this.getAge() > person.getAge()) {
				return 1;
			}
			if(this.getAge() == person.getAge()) {
				return 0;
			}
			if(this.getAge() < person.getAge()) {
				return -1;
			}
		}
		
		return -2;
	}
	
	@Override
	//ִ����������֮ǰ����
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		super.finalize();
		System.out.println("������Դ");
	}
	
}
