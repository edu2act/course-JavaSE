package net.onest;

public interface MyComparable {

	public int compareTo(Object obj);
}
