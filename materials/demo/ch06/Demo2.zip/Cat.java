package net.onest;

public class Cat extends Animal {

	@Override
	public void shout() {

		System.out.println("����");
	}

}
