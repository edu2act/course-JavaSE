package net.onest;

public class Circle {

	private double radius;
	
	public double getRadius() {
		return radius;
	}
	
	public void setRadius(double r) {
		radius = r;
	}
	
	public double caculatePerimeter() {
		return 3.14 * 2 * radius;
	}
	
	public double caculateArea() {
		return 3.14 * radius * radius;
	}
	
	public String toString() {
		double per = caculatePerimeter();
		double area = caculateArea();
		return "radius=" + radius + " �ܳ�=" + per + " ���=" + area;
	}	
}



