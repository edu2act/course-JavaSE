package net.onest;

public class Demo {

	public static void main(String[] args) {
		Circle c1 = new Circle();
		c1.setRadius(10.0);
		String res = c1.toString();
		System.out.println(res);
//		Circle c2 = new Circle();
//		c2.setRadius(15.0);
//		System.out.println(c1.caculatePerimeter());
//		System.out.println(c1.caculateArea());
	}
}
