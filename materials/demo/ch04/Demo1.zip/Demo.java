package net.onest;

public class Demo {

	public static void main(String[] args) {
		Student stu1 = new Student();
		//���ʶ������Ժͷ���
//		stu1.age = 20;
//		stu1.name = "zhangsan";
//		stu1.sex = "��";
//		stu1.study();
//		System.out.println(stu1.name);
//		System.out.println(stu1.age);
//		System.out.println(stu1.sex);
		Student stu2 = new Student();
//		stu2.name = "lisi";
//		stu2.age = -21;
//		stu2.sex = "Ů";
//		stu2.study();
		
		//��������
		Student[] stus = new Student[10];
//		System.out.println(stus[0]);
//		stus[0].age = 10;
//		stus[0] = new Student();
//		stus[0].age = 10;
//		stus[0].name = "wangwu";
//		stus[0].sex = "��";
//		stus[0].study();
		
//		Student stu3 = new Student();
//		stu3.age = 20;
//		
//		stus[1] = stu3;
		
		//ʵ�ַ�װ��
		Student stu4 = new Student();
		stu4.setName("����");
		stu4.setAge(21);
		stu4.setSex("��");
		System.out.println(stu4.getName());
	}
}
