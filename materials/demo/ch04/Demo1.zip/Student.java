package net.onest;

public class Student {

	private String name;
	private int age;
	private String sex;
	
	public String getName() {
		return name;
	}
	
	public void setName(String aName) {
		name = aName;
	}
	
	public int getAge() {
		return age;
	}
	
	public void setAge(int mAge) {
		if(mAge < 0) {
			System.out.println("���䲻��С��0");
		}else {
			age = mAge;
		}
	}
	
	public String getSex() {
		return sex;
	}
	
	public void setSex(String aSex) {
		sex = aSex;
	}
	
	public void study() {
		System.out.println("�Ұ�ѧϰ");
	}
	
}
