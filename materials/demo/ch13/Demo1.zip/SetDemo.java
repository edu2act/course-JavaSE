package net.onest;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String[] args) {
		List<String> list1 = new LinkedList<String>();
 		list1.add("NewYork");
 		list1.add("London");
 		list1.add("Beijing");
 		
		Set<String> set = new HashSet<String>();
		set.add("NewYork");
 		set.add("London");
 		set.add("Beijing");
		set.add("shanghai");
		set.add("NewYork");
//		set.remove("Beijing");
		System.out.println(set);
//		
//		Set<Book> bookSet = new HashSet<Book>();
//		Book book1 = new Book("001","JAVA","qqq");
//		Book book2 = new Book("001","JAVA","qqq");
//		bookSet.add(book1);
//		bookSet.add(book2);
//		System.out.println(bookSet);
//		
//		Iterator<String> it = set.iterator();
//		while (it.hasNext()) {
//			System.out.println(it.next());
//		}
		
		Set<String> treeSet = new TreeSet<String>();
		treeSet.add("NewYork");
		treeSet.add("London");
		treeSet.add("Beijing");
		treeSet.add("shanghai");
		treeSet.add("NewYork");
		System.out.println(treeSet.toString());
		
	}

}
