package net.onest;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class MapDemo {

	public static void main(String[] args) {

		Map<String, Book> bookMap = new HashMap<String, Book>();
		Book book = new Book("AAA","Java","zhangsan");
		Book book1 = new Book("CCC","Android","zhangsan");
		Book book2 = new Book("BBB","Java","zhangsan");
		bookMap.put(book.getNumber(), book);
		bookMap.put("001", book1);
		bookMap.put(book1.getNumber(), book1);
		bookMap.put(book2.getNumber(), book2);
//		bookMap.put(null, book1);
//		System.out.println(bookMap.get("001"));
//		System.out.println(bookMap.containsKey("001"));
//		book.setISBN("12345623523");
//		System.out.println(bookMap);
//		System.out.println(bookMap.keySet());
//		System.out.println(bookMap.values());
		
		//����������Map
		Iterator<Map.Entry<String, Book>> it = bookMap.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry<String, Book> item = it.next();
			if(item.getKey().equals("AAA")) {
				item.setValue(new Book("100","Java EE","lisi"));
				it.remove();
			}
//			System.out.println(item);
		}
		System.out.println(bookMap);
		
		System.out.println("Aa".hashCode());
		System.out.println("BB".hashCode());
	}

}
