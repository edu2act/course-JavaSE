package net.onest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class ListDemo {

	public static void main(String[] args) {

//		List<Integer> list = new ArrayList<Integer>();
//		list.add(10);
		
 		List<String> list1 = new ArrayList<String>();
//		List<String> list1 = new LinkedList<String>();
 		list1.add("NewYork");
 		list1.add("London");
 		list1.add("Beijing");
 		list1.set(2, "Shanghai");
// 		list1.add(null);
 		System.out.println(list1.toString());
 		
// 		Collections.sort(list1);
// 		System.out.println(list1.toString());
 		
// 		list1.remove("Beijing");
// 		list1.remove(0);
 		
// 		System.out.println(list1.get(1));
 		
 		//����List
// 		for(int i = 0; i < list1.size(); i++) {
// 			System.out.println(list1.get(i));
// 		}
// 		for(String s : list1) {
// 			System.out.println(s);
// 		}
 	
 		//������
 		Iterator<String> it = list1.iterator();
 		while(it.hasNext()) {
 			String str = it.next();
 			if(str.equals("Beijing")) {
 				it.remove();
 			}
 			System.out.println(str);
 		}
 		
// 		LinkedList<String> list2 = new LinkedList<String>();
// 		list2.add("NewYork");
// 		list2.add("London");
// 		list2.add("Beijing");
// 		
// 		list2.addFirst("Shanghai");
// 		list2.addLast("Shijiazhuang");
// 		System.out.println(list2.toString());
 	}
}
