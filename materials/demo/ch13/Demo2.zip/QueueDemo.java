package net.onest;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class QueueDemo {

	public static void main(String[] args) {
//		Stack stack = new Stack<>();
		Queue<String> queue = new LinkedList<String>();
		queue.add("NewYork");
		queue.offer("London");
		queue.add("Beijing");
		System.out.println(queue);
		System.out.println(queue.element());
		System.out.println(queue.poll());
		System.out.println(queue.peek());
	}
}
