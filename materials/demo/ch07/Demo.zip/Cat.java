package net.onest.pole;

public class Cat extends Animal{

	public void eat() {

		System.out.println("����");
	}
	
	public void fun() {
		
	}
}
