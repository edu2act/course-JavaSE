package net.onest.pole;

public class Demo {

	public static void main(String[] args) {
		Animal a = new Cat();
		a.setName("С��è");
//		a.fun();
		
//		a.eat();
//		a = new Dog();
//		a.eat();
//		Feeder f = new Feeder();
//		f.setName("С��");
//		Cat c = new Cat();
//		c.setName("С��è");
//		f.feed(c);
//		Dog d = new Dog();
//		d.setName("С��");
//		f.feed(d);
//		Rabbit r = new Rabbit();
//		r.setName("С����");
//		f.feed(r);
	}
}
