package net.onest.pole;

public class Rabbit extends Animal{

	@Override
	public void eat() {

		System.out.println("���ܲ�");
	}
}
