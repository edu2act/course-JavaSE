package net.onest.pole;

public class Dog extends Animal{

	public void eat() {

		System.out.println("�Թ�ͷ");
	}
}
