package net.onest.pole;

public class Feeder {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public void feed(Animal a) {
		System.out.print(name + "ι" + a.getName());
		a.eat();
	}
	
//	public void feed(Cat cat) {
//		System.out.print(name + "ι" + cat.getName());
//		cat.eat();
//	}
//	
//	public void feed(Dog dog) {
//		System.out.print(name + "ι" + dog.getName());
//		dog.eat();
//	}
//	
//	public void feed(Rabbit r) {
//		System.out.print(name + "ι" + r.getName());
//		r.eat();
//	}
	
}
