package net.onest;

public class Demo {

	public static void main(String[] args) {
//		Student stu1 = new Student();
//		System.out.println(stu1.getName());
//		Student stu2 = new Student();
//		System.out.println(stu1.getCount());
//		System.out.println(Student.getCount());
//		Student.count++;
//		System.out.println(Student.getCount());
//		Student stu3 = new Student();
//		Student stu4 = new Student();
		
//		CollStudent collStudent = new CollStudent();
//		System.out.println("-----------------------");
//		CollStudent collStudent1 = new CollStudent();
		
		System.out.println(Constant.URL);
	}

}
