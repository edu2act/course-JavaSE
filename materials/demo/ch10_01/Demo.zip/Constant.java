package net.onest;

public class Constant {

	public static final String  URL = "www.baidu.com";
	static {
		System.out.println("Constant�ľ�̬�����");
	}
}
